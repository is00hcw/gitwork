# 微信小程序商城
微信小程序商城，微信小程序微店，长期维护版本；

# 接口和后台
本商城采用的是 云接口和后台 ，注册账号，直接配置即可完成接口和后台的对接

[https://www.it120.cc/info/wxapp/314](https://www.it120.cc/info/wxapp/314)。

## 参与开发

更多项目请关注 [https://github.com/EastWorld](https://github.com/EastWorld)。

> 产品设计 & UI [@blackjeffer](https://github.com/orgs/EastWorld/people/blackjeffer)
>
> 小程序开发 [@jiulonggithub](https://github.com/orgs/EastWorld/people/jiulonggithub)
>
> 接口及后台支持 [@gooking](https://github.com/gooking)

期待您的加入~

开发问题欢迎加QQ群一起交流 ： 479413914

## 扫码体验

<img src="https://cdn.it120.cc/images/weappshop/screenshot/qrcode.jpg" width="200px">
<img src="https://cdn.it120.cc/images/weappshop/screenshot/qrcode2.jpg" width="200px">

## 软件截图

1.png

<img src="https://cdn.it120.cc/images/weappshop/screenshot/1.png" width="360px">



2.png


<img src="https://cdn.it120.cc/images/weappshop/screenshot/2.png" width="360px" style="display:block;">

3.png


<img src="https://cdn.it120.cc/images/weappshop/screenshot/3.png" width="360px" style="display:block;">

4.png

<img src="https://cdn.it120.cc/images/weappshop/screenshot/4.png" width="360px" style="display:block;">

5.png

<img src="https://cdn.it120.cc/images/weappshop/screenshot/5.png" width="360px" style="display:block;">

6.png

<img src="https://cdn.it120.cc/images/weappshop/screenshot/6.png" width="360px" style="display:block;">

7.png

<img src="https://cdn.it120.cc/images/weappshop/screenshot/7.png" width="360px" style="display:block;">
