package cc.wdcy.domain.shared;

/**
 * @author Shengzhao Li
 */

public interface Repository {
}