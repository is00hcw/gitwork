package com.helloscala.springbootscala.common;

/**
 * Created by yangbajing on 16-8-24.
 */
public class Constants {
    public static final String CHARSET = "UTF-8";
}
