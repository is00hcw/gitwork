package com.springboot.in.action

import org.springframework.boot.autoconfigure.SpringBootApplication

@SpringBootApplication
class AppConfig