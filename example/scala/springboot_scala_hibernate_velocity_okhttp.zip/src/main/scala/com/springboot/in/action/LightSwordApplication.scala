package com.springboot.in.action

import org.springframework.boot.SpringApplication

// http://my.oschina.net/universsky/blog/704446
object LightSwordApplication extends App {
  SpringApplication.run(classOf[AppConfig])
}