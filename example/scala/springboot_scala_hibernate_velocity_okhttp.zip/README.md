# LightSword

使用SpringBoot,Scala開發的自動化測試平台

## 书籍参考

### SpringBoot简明教程

https://www.gitbook.com/book/jxgxldl/spring-boot2016/details

### Scala

https://www.gitbook.com/@universsky/dashboard
