gatling-gradle
==============

using gradle to integrate gatling scripts 
