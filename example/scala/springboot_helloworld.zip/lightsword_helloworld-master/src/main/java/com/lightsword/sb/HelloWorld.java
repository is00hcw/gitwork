package com.lightsword.sb;

import org.springframework.boot.*;
import org.springframework.boot.autoconfigure.*;
import org.springframework.stereotype.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Value;  
import org.springframework.boot.context.embedded.EmbeddedServletContainerFactory;  
import org.springframework.boot.context.embedded.tomcat.TomcatEmbeddedServletContainerFactory;  
import org.springframework.context.annotation.Bean;  
import org.springframework.context.annotation.Configuration;  
  
/**
 * mvn spring-boot:run
 */

@Controller
@EnableAutoConfiguration
public class HelloWorld {

    @RequestMapping("/")
    @ResponseBody
    String home() {
        return "Hello World!";
    }

    public static void main(String[] args) throws Exception {
        SpringApplication.run(HelloWorld.class, args);
    }
    

    // @Value("${tomcatport:8090}")  
    // private int port;  
      
    // @Bean  
    // public EmbeddedServletContainerFactory servletContainer(){  
    //     return new TomcatEmbeddedServletContainerFactory(this.port);  
    // }  
}
