package com.lightsword.sb;

import org.springframework.boot.SpringApplication

object LightSwordApplication extends App {
  SpringApplication.run(classOf[AppConfig])
}