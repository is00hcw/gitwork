package com.lightsword.sb;

import org.springframework.boot.autoconfigure.SpringBootApplication

@SpringBootApplication
class AppConfig