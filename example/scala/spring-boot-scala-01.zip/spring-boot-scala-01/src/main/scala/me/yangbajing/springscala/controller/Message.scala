package me.yangbajing.springscala.controller

import scala.beans.BeanProperty

/**
  * Created by Yang Jing (yangbajing@gmail.com) on 2015-12-18.
  */
class Message {

  @BeanProperty
  var value: String = _

}
