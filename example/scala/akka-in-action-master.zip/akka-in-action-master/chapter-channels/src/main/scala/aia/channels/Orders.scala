package aia.channels

case class Order(customerId: String, productId: String, number: Int)
