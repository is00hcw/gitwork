akka-in-action
==============

[![Build Status](https://travis-ci.org/RayRoestenburg/akka-in-action.svg?branch=master)](https://travis-ci.org/RayRoestenburg/akka-in-action)

Accompanying source code for Akka in Action.
