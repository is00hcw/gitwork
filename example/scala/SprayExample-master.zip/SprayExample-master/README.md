SprayExample
============

The simple example of Spray based on Akka

Follow these steps to get started:

1.Git-clone this repository.

$ git clone git@github.com:agiledon/SprayExample.git

2.Change directory into your clone:

$ cd SprayExample

3.Launch SBT:

$ sbt

4.Compile everything:

> package

5.Start the application:

> re-start

6.Browse to http://localhost:8080

7.Stop the application:

> re-stop
