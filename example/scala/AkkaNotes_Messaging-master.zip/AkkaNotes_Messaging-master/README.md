AkkaNotes_Messaging
===================

Rudimentary Actor messaging showcase to be followed along with the `Akka Notes` series at http://rerun.me
