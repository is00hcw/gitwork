Simple Akka Remote example in Scala
===================================

This repository contains a simple example for akka remote. It shows how to create both remote and local actors in same
project.It also shows how different configurations are read and interpreted.