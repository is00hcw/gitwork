package com.baronzhang.android.coremodel.http.services;

/**
 * @author baronzhang (baron[dot]zhanglei[at]gmail[dot]com)
 *         2017/1/5
 */
public interface IMService {
}
