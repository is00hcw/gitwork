package com.baronzhang.android.coremodel.entities;

/**
 * @author baronzhang (baron[dot]zhanglei[at]gmail[dot]com)
 *         2017/1/12
 */
public class User {
}
