package com.baronzhang.android.coremodel.http;

/**
 * @author baronzhang (baron[dot]zhanglei[at]gmail[dot]com)
 *         2017/1/5
 */
public final class ApiConstants {
}
