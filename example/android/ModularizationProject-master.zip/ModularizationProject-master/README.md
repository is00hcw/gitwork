# Modularization Project

> Android 模块化示例项目

## 模块化项目设计方案

> 以下为模块化设计方案图

* 模块化设计图

![模块化设计图](https://github.com/BaronZ88/Blog/blob/master/%E6%9E%B6%E6%9E%84%E8%AE%BE%E8%AE%A1/%E5%AE%89%E5%B1%85%E5%AE%A2Android%E9%A1%B9%E7%9B%AE%E6%9E%B6%E6%9E%84%E6%BC%94%E8%BF%9B/modularization1.1.png)

* 整体方案设计图

![模块化设计图](https://github.com/BaronZ88/Blog/blob/master/%E6%9E%B6%E6%9E%84%E8%AE%BE%E8%AE%A1/%E5%AE%89%E5%B1%85%E5%AE%A2Android%E9%A1%B9%E7%9B%AE%E6%9E%B6%E6%9E%84%E6%BC%94%E8%BF%9B/modularization4.1.png)


