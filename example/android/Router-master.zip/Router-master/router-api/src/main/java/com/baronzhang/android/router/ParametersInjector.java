package com.baronzhang.android.router;

/**
 * @author baronzhang (baron[dot]zhanglei[at]gmail[dot]com)
 *         2017/3/15
 */
public interface ParametersInjector {

    ParametersInjector EMPTY = new ParametersInjector() {
    };
}
