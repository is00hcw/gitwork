package com.baronzhang.android.weather.view.widget;

/**
 * @author baronzhang (baron[dot]zhanglei[at]gmail[dot]com)
 *         16/3/21
 */
public interface OnRecyclerViewItemClickListener {

    void onRecyclerViewItemClick(int position);
}
