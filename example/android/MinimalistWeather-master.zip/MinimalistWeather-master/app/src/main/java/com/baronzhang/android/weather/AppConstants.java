package com.baronzhang.android.weather;

/**
 * @author baronzhang (baron[dot]zhanglei[at]gmail[dot]com)
 *         16/3/13
 */
public class AppConstants {

    public static final String DB_NAME_CITY = "city.db";
}
