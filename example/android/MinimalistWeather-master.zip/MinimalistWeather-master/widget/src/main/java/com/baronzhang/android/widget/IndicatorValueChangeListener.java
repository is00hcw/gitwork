package com.baronzhang.android.widget;

/**
 * Created by baron on 14-8-28.
 *
 * @author baronzhang (baron[dot]zhanglei[at]gmail[dot]com)
 */
public interface IndicatorValueChangeListener {

    void onChange(int currentIndicatorValue, String stateDescription, int indicatorTextColor);
}
