// (c)2016 Flipboard Inc, All Rights Reserved.

package com.rengwuxian.rxjavasamples.model;

public class FakeThing {
    public int id;
    public String name;
}
