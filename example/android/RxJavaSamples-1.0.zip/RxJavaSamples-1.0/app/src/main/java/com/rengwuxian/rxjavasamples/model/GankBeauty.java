// (c)2016 Flipboard Inc, All Rights Reserved.

package com.rengwuxian.rxjavasamples.model;

public class GankBeauty {
    public String createdAt;
    public String url;
}
