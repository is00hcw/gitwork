# wcl-droid-plugin-demo
使用DroidPlugin的示例

下载之后, 需要安装Submodule.
命令: 
```
git submodule update --init --recursive
```

[参考文章](http://www.jianshu.com/p/f1217cce93ef)
