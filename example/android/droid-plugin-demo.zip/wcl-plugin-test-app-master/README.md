# wcl-plugin-test-app
DroidPlugin的插件App, 和Demo互动.

[参考文章](http://www.jianshu.com/p/f1217cce93ef)
