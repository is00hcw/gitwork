# mypromise
Promise的简易实现

## 参考

* [JavaScript Promises](http://www.html5rocks.com/zh/tutorials/es6/promises/)
* [Implementing promise](https://www.promisejs.org/implementing/)
* [Promise原理解析与实现](http://bg.biedalian.com/2014/03/01/I-promise-I-resolve-v2.html)
* [细嗅Promise](https://github.com/barretlee/myPromise)
* [MDN Promise](https://developer.mozilla.org/zh-CN/docs/Web/JavaScript/Reference/Global_Objects/Promise)
* [How is a promise/defer library implemented?](http://stackoverflow.com/questions/17718673/how-is-a-promise-defer-library-implemented)
