import 'jquery'
import 'bootstrap'
import './app.ts'
require('bootstrap.min.css')
require('./style.css')
