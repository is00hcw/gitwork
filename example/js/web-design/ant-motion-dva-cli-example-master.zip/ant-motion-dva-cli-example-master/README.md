# ant-motion-dva-cli-example

[ant motion](https://motion.ant.design/) 的首页在 [dva-cli](https://github.com/dvajs/dva-cli)0.7.8 里运行的例子

请参照[documentation](https://github.com/ant-motion/ant-motion-dva-cli-example/blob/master/src/routes/Home/documentation.md)里的步骤。。
