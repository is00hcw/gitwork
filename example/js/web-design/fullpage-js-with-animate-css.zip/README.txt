A Pen created at CodePen.io. You can find this one at http://codepen.io/is00hcw/pen/Qgrzgy.

 A simple demo showing how you can create scroll-based animations by taking advantage of the fullPage.js and animation.css libraries.


By [George](http://codepen.io/georgemarts/).