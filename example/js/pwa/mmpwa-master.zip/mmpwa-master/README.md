# MMPWA

Minimal Multi-page PWA

For more details, pleace check out this article: [Upgrading Ele.me to Progressive Web App](https://medium.com/elemefe/upgrading-ele-me-to-progressive-web-app-2a446832e509)
