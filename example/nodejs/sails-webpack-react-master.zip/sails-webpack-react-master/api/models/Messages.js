module.exports = {
  attributes: {
      id: {
        type: 'string'
      },
      author: {
        type: 'string'
      },
      content: {
        type: 'string'
      },
      time: {
        type: 'string'
      },
      page: {
        type: 'integer'
      }
  }
}
