# sails+webpack+react

a [Sails](http://sailsjs.org) application
* git clone git@github.com:zhangfu-git/sails_webpack_react.cli.git
* cd sails_webpack_react.cli
* npm install
* sails lift
* npm run dev

>给自己备份一个用webpack+react+sails 的初始项目。
* 支持热加载和自动刷新。
* 支持es6语法

