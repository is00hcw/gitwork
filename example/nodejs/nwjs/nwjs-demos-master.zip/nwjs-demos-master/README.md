# nwjs-demos 《NW.js 入门指南》
Demos of [NW.js](http://nwjs.io/).


## How to run demos

### Install nw

Make sure you had installed mw:

```sh
npm install -g nw
```

### Run demo with nw

```sh
git clone https://github.com/waylau/nwjs-demos.git
cd nwjs-demos/demos/quick-start
npm start # or "nw ."
```

Let's start from [SUMMARY](SUMMARY.md)!

从[目录](SUMMARY.md)开始吧!