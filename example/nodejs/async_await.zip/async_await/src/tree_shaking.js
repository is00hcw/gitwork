import * as uu from './invoke.js';

console.log(uu.ddd);