export * from './invoke_base.js';

export function aaa() {
	console.log(1);
}

export function bbb() {
	console.log(2);
}

export default function ccc(){
	console.log(3);
}