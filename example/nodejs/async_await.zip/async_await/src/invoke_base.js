export function ddd() {
	console.log(4);
}