package cn.teaey.sprintboot.test;

/**
 * @author xiaofei.wxf(teaey)
 * @since 0.0.0
 */
public interface EchoService {
    String echo(String str);
}
