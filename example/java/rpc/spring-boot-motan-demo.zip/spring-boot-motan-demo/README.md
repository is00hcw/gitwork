# spring-boot-motan-demo

分别启动demo-server、demo-client(需要引入spring-boot-starter-motan)

浏览器输入 http://localhost:8080/say/34  即可看到结果

[其他参考](http://www.jianshu.com/notebooks/6195896/latest)
