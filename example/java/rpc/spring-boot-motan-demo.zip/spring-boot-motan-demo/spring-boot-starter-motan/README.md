# spring-boot-starter-motan

少一些属性，后续补全

spring-boot motan 整合的项目，可通过application.properties配置。

增加了自动调用心跳开关，注册到注册中心

[使用demo](https://github.com/chenxing2/spring-boot-motan-demo)

[其他参考](http://www.jianshu.com/notebooks/6195896/latest)
