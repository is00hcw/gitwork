package org.atsmart.charger.dataaccess.mapper;

import org.atsmart.charger.dataaccess.model.Country;
import tk.mybatis.mapper.common.Mapper;

public interface CountryMapper extends Mapper<Country> {
}