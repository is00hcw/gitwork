
微信认证服务接口地址: http://localhost:8080/wx/main

基于springboot weixin-java-tools
