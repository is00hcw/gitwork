package com.tuicr.webchat.server.config;

import com.tuicr.webchat.message.FocusMeMessage;
import com.tuicr.webchat.server.properties.WechatMpProperties;
import com.tuicr.webchat.util.WxMpUtil;
import lombok.extern.slf4j.Slf4j;
import me.chanjar.weixin.common.api.WxConsts;
import me.chanjar.weixin.mp.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author ylxia
 * @version 1.0
 * @package com.woawi.server.config
 * @date 15/11/21
 */
@Slf4j
@Configuration
@ConditionalOnClass(WxMpService.class)
@EnableConfigurationProperties(WechatMpProperties.class)
public class WechatMpConfiguration {
    @Autowired
    private WechatMpProperties properties;

    @Bean
    @ConditionalOnMissingBean
    public WxMpConfigStorage configStorage() {
        WxMpInMemoryConfigStorage configStorage = new WxMpInMemoryConfigStorage();
        configStorage.setAppId(this.properties.getAppId()); // 设置微信公众号的appid
        configStorage.setSecret(this.properties.getSecret()); // 设置微信公众号的app corpSecret
        configStorage.setToken(this.properties.getToken());  // 设置微信公众号的token
        configStorage.setAesKey(this.properties.getAesKey());  // 设置微信公众号的EncodingAESKey
        configStorage.setPartnerId(this.properties.getPartnerId());
        configStorage.setPartnerKey(this.properties.getPartnerKey());
        return configStorage;
    }

    @Bean
    @ConditionalOnMissingBean
    public WxMpService wxMpService(WxMpConfigStorage configStorage) {
        WxMpService wxMpService = new WxMpServiceImpl();
        wxMpService.setWxMpConfigStorage(configStorage);
        return wxMpService;
    }

    @Bean
    public WxMpMessageRouter wxMpMessageRouter(WxMpService wxMpService) {
        WxMpMessageRouter wxMpMessageRouter = new WxMpMessageRouter(wxMpService);

        WxMpUtil.text(wxMpMessageRouter, false, "test", "This is a test !!!");
        wxMpMessageRouter.rule()
                // .msgType(WxConsts.XML_MSG_TEXT)
                .async(false)
                .event(WxConsts.EVT_UNSUBSCRIBE)
                // .eventKey("EVENT_KEY")
                .handler(new FocusMeMessage())
                .end()
                .rule()
                .async(false)
                .event(WxConsts.EVT_SUBSCRIBE)
                .handler(new FocusMeMessage())
                .end();
        // wxMpMessageRouter.rule().handler(new NoMessage()).end();
        return wxMpMessageRouter;
    }
}