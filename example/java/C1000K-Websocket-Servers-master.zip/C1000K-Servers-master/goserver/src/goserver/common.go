package goserver


type Configuration struct {
	Port int
	Delay string
	Interval string
	TotalSize int
	OnlyTestConnect bool
}