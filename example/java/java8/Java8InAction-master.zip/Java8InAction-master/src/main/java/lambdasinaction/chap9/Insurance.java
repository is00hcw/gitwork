package lambdasinaction.chap9;

public class Insurance {

    private String name;

    public String getName() {
        return name;
    }
}
