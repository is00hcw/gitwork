package lambdasinaction.chap7;

public class Utils{
    public static void process(BasicList<String> list){
        int s = list.size();
        //TODO: uncomment, read the README for instructions
        //list.forEach(System.out::println);
    }


}
