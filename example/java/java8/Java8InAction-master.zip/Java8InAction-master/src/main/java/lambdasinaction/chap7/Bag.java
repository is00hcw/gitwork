package lambdasinaction.chap7;
import java.util.Iterator;
public class Bag<T> implements Foreachable<T>, Removeable<T>{
 
    public Iterator<T> iterator(){
       // TODO
       return null;
    }

    // ...
}

