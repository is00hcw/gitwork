package org.atsmart.charger.card.service;

import junit.framework.Assert;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.subject.Subject;
import org.apache.shiro.util.Factory;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.config.IniSecurityManagerFactory;
import org.apache.shiro.mgt.SecurityManager;
import org.junit.Test;

public class TestHelloShiro {

        public static final String DEFAULT_INI_RESOURCE_PATH = "classpath:shiro.ini";

	@Test
	public void TestShiroFirst() {
		// 使用ini文件方式实例化shiro IniSecurityManagerFactory.
		IniSecurityManagerFactory securityManagerFactory = new IniSecurityManagerFactory(DEFAULT_INI_RESOURCE_PATH);
		
		// 得到SecurityManager实例 并绑定给SecurityUtils
		SecurityManager securityManager = securityManagerFactory.getInstance();
		SecurityUtils.setSecurityManager(securityManager);

		//得到Subject
		Subject shiroSubject = SecurityUtils.getSubject();
		//创建用户名/密码身份验证Token（即用户身份/凭证）
		UsernamePasswordToken normalToken = new UsernamePasswordToken("credo", "123");

		try {
			//登录,进行身份验证
			shiroSubject.login(normalToken);
		} catch (Exception e) {
			//登录失败,打印出错误信息,可自定义
			System.out.println(e.getMessage());
		}
		//断言登录成功
		Assert.assertEquals(true, shiroSubject.isAuthenticated());
		//登出
		shiroSubject.logout();
	}
}