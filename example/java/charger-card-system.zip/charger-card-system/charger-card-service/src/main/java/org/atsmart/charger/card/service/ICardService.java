package org.atsmart.charger.card.service;

import org.atsmart.charger.card.model.Country;

/**
 * Created by Administrator on 2016/4/8.
 */
public interface ICardService {
    public void createCountry(Country c);

    public int count();
}
