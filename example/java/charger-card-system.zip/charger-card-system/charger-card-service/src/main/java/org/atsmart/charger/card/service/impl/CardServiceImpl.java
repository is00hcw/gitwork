package org.atsmart.charger.card.service.impl;

import org.apache.shiro.authz.annotation.RequiresRoles;
import org.atsmart.charger.card.mapper.CountryMapper;
import org.atsmart.charger.card.model.Country;
import org.atsmart.charger.card.service.ICardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by Administrator on 2016/4/8.
 */
@Service
public class CardServiceImpl implements ICardService {
    @Autowired
    protected CountryMapper cmapper;

    public void createCountry(Country c) {
        cmapper.insert(c);
    }

    @RequiresRoles("index")
    public int count(){
        return 1;
    }
}
