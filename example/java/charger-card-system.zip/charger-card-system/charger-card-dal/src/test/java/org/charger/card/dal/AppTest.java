package org.charger.card.dal;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.atsmart.charger.card.mapper.CountryMapper;
import org.atsmart.charger.card.model.Country;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;

import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:spring/applicationContext.xml"})
@TransactionConfiguration(defaultRollback = false)
public class AppTest {
    @Autowired
    protected CountryMapper cmapper;

    @org.junit.Test
    public void testCountry(){
        Country c1 = new Country();
        c1.setCountrycode("c1");
        c1.setCountryname("n1");
        cmapper.insert(c1);

        List<Country> list = cmapper.selectAll();
        System.out.println(list.size());
    }

}
