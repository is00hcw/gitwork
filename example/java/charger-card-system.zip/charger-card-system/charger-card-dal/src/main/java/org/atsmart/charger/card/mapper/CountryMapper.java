package org.atsmart.charger.card.mapper;

import org.atsmart.charger.card.IMapper;
import org.atsmart.charger.card.model.Country;

public interface CountryMapper extends IMapper<Country> {
}