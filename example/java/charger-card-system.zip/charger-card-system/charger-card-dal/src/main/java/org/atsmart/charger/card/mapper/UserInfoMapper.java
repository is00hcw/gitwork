package org.atsmart.charger.card.mapper;

import org.atsmart.charger.card.IMapper;
import org.atsmart.charger.card.model.UserInfo;

public interface UserInfoMapper extends IMapper<UserInfo> {
}