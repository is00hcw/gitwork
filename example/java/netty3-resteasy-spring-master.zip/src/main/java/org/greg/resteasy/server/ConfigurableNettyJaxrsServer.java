package org.greg.resteasy.server;
//
//import java.net.InetSocketAddress;
//import java.util.Collections;
//import java.util.List;
//import java.util.Map;
//import java.util.concurrent.Executors;
//
//import javax.net.ssl.SSLContext;
//
//import org.jboss.netty.bootstrap.Bootstrap;
//import org.jboss.netty.bootstrap.ServerBootstrap;
//import org.jboss.netty.channel.ChannelHandler;
//import org.jboss.netty.channel.ChannelPipelineFactory;
//import org.jboss.netty.channel.group.ChannelGroup;
//import org.jboss.netty.channel.group.DefaultChannelGroup;
//import org.jboss.netty.channel.socket.nio.NioServerSocketChannelFactory;
//import org.jboss.resteasy.core.SynchronousDispatcher;
//import org.jboss.resteasy.plugins.server.netty.HttpServerPipelineFactory;
//import org.jboss.resteasy.plugins.server.netty.HttpsServerPipelineFactory;
//import org.jboss.resteasy.plugins.server.netty.NettyJaxrsServer;
//import org.jboss.resteasy.plugins.server.netty.RequestDispatcher;
//
///**
// * exposing bootstrap config
// *
// * @author Gregory
// *
// */
//public class ConfigurableNettyJaxrsServer extends NettyJaxrsServer {
//
//	private final int			ioWorkerCount		= Runtime.getRuntime().availableProcessors() * 2;
//	private final int			executorThreadCount	= 16;
//	private SSLContext			sslContext;
//	private final int			maxRequestSize		= 1024 * 1024 * 10;
//	static final ChannelGroup	allChannels			= new DefaultChannelGroup("NettyJaxrsServer");
//	private boolean isKeepAlive = true;
//	private List<ChannelHandler> channelHandlers = Collections.emptyList();
//	private Map<String, Object> channelOptions = Collections.emptyMap();
//
//	public void setKeepAlive(boolean isKeepAlive)
//	{
//		this.isKeepAlive = isKeepAlive;
//	}
//
//	/**
//	 * Add additional {@link org.jboss.netty.channel.ChannelHandler}s to the {@link org.jboss.netty.bootstrap.ServerBootstrap}.
//	 * <p>The additional channel handlers are being added <em>before</em> the HTTP handling.</p>
//	 *
//	 * @param channelHandlers the additional {@link org.jboss.netty.channel.ChannelHandler}s.
//	 */
//	public void setChannelHandlers(final List<ChannelHandler> channelHandlers) {
//		this.channelHandlers = channelHandlers == null ? Collections.<ChannelHandler>emptyList() : channelHandlers;
//	}
//
//	/**
//	 * Add channel options to Netty {@link org.jboss.netty.bootstrap.ServerBootstrap}.
//	 *
//	 * @param channelOptions a {@link java.util.Map} containing the Netty bootstrap options.
//	 * @see org.jboss.netty.bootstrap.ServerBootstrap#setOptions(java.util.Map)
//	 */
//	public void setChannelOptions(final Map<String, Object> channelOptions) {
//		this.channelOptions = channelOptions == null ? Collections.<String, Object>emptyMap() : channelOptions;
//	}
//
//
//	/**
//	 * expose bootstrap to be able to config
//	 *
//	 * @return
//	 */
//	public Bootstrap initBootstrap() {
//		this.bootstrap = new ServerBootstrap(
//				new NioServerSocketChannelFactory(
//						Executors.newCachedThreadPool(),
//						Executors.newCachedThreadPool(),
//						ioWorkerCount));
//		return bootstrap;
//	}
//
//	public void setBootstrap(ServerBootstrap bootstrap) {
//		this.bootstrap = bootstrap;
//	}
//
//	@Override
//	public void start()
//	{
//		deployment.start();
//		RequestDispatcher dispatcher = new RequestDispatcher(
//				(SynchronousDispatcher) deployment.getDispatcher(),
//				deployment.getProviderFactory(), domain);
//
//		// Configure the server.
//		if (bootstrap == null) {
//			initBootstrap();
//		}
//
//		ChannelPipelineFactory factory;
//
//		if (sslContext == null) {
//			factory = new HttpServerPipelineFactory(dispatcher, root, executorThreadCount, maxRequestSize, isKeepAlive, channelHandlers);
//		} else {
//			factory = new HttpsServerPipelineFactory(dispatcher, root, executorThreadCount, maxRequestSize, isKeepAlive, channelHandlers, sslContext);
//		}
//		// Set up the event pipeline factory.
//		bootstrap.setPipelineFactory(factory);
//		// Add custom bootstrap options
//		bootstrap.setOptions(channelOptions);
//
//		// Bind and start to accept incoming connections.
//		final InetSocketAddress socketAddress;
//		if(null == hostname || hostname.isEmpty()) {
//			socketAddress = new InetSocketAddress(port);
//		} else {
//			socketAddress = new InetSocketAddress(hostname, port);
//		}
//
//		channel = bootstrap.bind(socketAddress);
//		allChannels.add(channel);
//	}
//
//}
