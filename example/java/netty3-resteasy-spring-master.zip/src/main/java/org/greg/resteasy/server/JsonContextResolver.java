package org.greg.resteasy.server;

import javax.ws.rs.ext.ContextResolver;
import javax.ws.rs.ext.Provider;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
@Provider
public class JsonContextResolver implements ContextResolver<ObjectMapper> {

	final ObjectMapper	mapper	= (new ObjectMapper())
										.configure(
												DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
												false).setPropertyNamingStrategy(PropertyNamingStrategy.CAMEL_CASE_TO_LOWER_CASE_WITH_UNDERSCORES);

	@Override
	public ObjectMapper getContext(Class<?> type) {
		return mapper;
	}
}

/*
// /META-INF/services/javax.ws.rs.ext.Providers  �ļ���д��
@Provider
@Consumes({ MediaType.APPLICATION_JSON, "text/json" })
@Produces({ MediaType.APPLICATION_JSON, "text/json" })
public class JacksonConfig extends ResteasyJackson2Provider {
    private final ObjectMapper objectMapper;

    public JacksonConfig() {
        this.objectMapper = new ObjectMapper();
        this.objectMapper.setPropertyNamingStrategy(PropertyNamingStrategy.CAMEL_CASE_TO_LOWER_CASE_WITH_UNDERSCORES);
        setMapper(objectMapper);
    }

}

 */