package org.greg.resteasy.request;

import org.springframework.stereotype.Component;

import java.io.IOException;
import java.io.OutputStream;
import java.util.zip.GZIPOutputStream;

import javax.annotation.Priority;
import javax.ws.rs.Priorities;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.ext.*;

@Component
@Provider
@Priority(Priorities.ENTITY_CODER)
public class TraceInterceptor implements ReaderInterceptor, WriterInterceptor {

	public Object aroundReadFrom(
			ReaderInterceptorContext readerInterceptorContext)
			throws IOException, WebApplicationException {
		System.out.println("--aroundReadFrom");
		return readerInterceptorContext.proceed();
	}

	public void aroundWriteTo(WriterInterceptorContext writerInterceptorContext)
			throws IOException, WebApplicationException {
		System.out.println("--aroundWriteTo");
		OutputStream outputStream = writerInterceptorContext.getOutputStream();
		//writerInterceptorContext.setOutputStream(new GZIPOutputStream(outputStream));
		writerInterceptorContext.proceed();

	}
}
