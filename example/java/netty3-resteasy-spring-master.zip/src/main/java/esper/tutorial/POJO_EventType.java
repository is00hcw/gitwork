package esper.tutorial;

import com.espertech.esper.client.*;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;


/**
 * Created by IntelliJ IDEA.
 * User: wei.Li
 * Date: 14-7-28
 * Time: 14:41
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Ŀ��1����Person���͵��¼���nameΪxiaohuluʱ��Esper�ܵõ���Ӧ��age,children��address
 * Ŀ��2����Person���͵��¼���nameΪxiaohuluʱ��Esper�ܵõ���Ӧ�ĵڶ�������,����ĵ绰�ͼ�ͥסַ������·��
 */
class Person {
    public static final String CLASSNAME = Person.class.getName();

    private String name;
    private int age;
    private List<Child> children;
    private Map<String, Integer> phones;
    private Address address;

    /**
     * @return �����ȡPerson ����
     */
    public static Person getRandomPerson() {
        Random random = new Random();
        String name = UUID.randomUUID().toString();
        int age = random.nextInt(100);
        List<Child> children = Child.getRandomChild(10);
        Map<String, Integer> phones = Maps.newHashMap();
        phones.put("home", 110);
        phones.put("iphone", 120);
        Address address = Address.getRandomAddress();
        return new Person(name, age, children, phones, address);
    }

    /**
     * @param name ����� name
     * @return �����ȡPerson ����
     */
    public static Person getRandomPerson(String name) {
        Person person = getRandomPerson();
        person.setName(name);
        return person;
    }

    Person(String name, int age, List<Child> children, Map<String, Integer> phones, Address address) {
        this.name = name;
        this.age = age;
        this.children = children;
        this.phones = phones;
        this.address = address;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public List<Child> getChildren() {
        return children;
    }

    public Child getChild(int index) {
        return children.get(index);
    }

    public int getPhones(String name) {
        return phones.get(name);
    }

    public Map<String, Integer> getPhones() {
        return phones;
    }

    public Address getAddress() {
        return address;
    }

    @Override
    public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", children=" + children +
                ", phones=" + phones +
                ", address=" + address +
                '}';
    }
}

class Address {
    private String road;
    private String street;
    private int houseNo;

    /**
     * @return �����ȡһ��Address ����
     */
    public static Address getRandomAddress() {

        return new Address(UUID.randomUUID().toString(), UUID.randomUUID().toString(), (int) (Math.random() * 1000));
    }

    Address(String road, String street, int houseNo) {
        this.road = road;
        this.street = street;
        this.houseNo = houseNo;
    }

    public String getRoad() {
        return road;
    }

    public String getStreet() {
        return street;
    }

    public int getHouseNo() {
        return houseNo;
    }

    @Override
    public String toString() {
        return "Address{" +
                "road='" + road + '\'' +
                ", street='" + street + '\'' +
                ", houseNo=" + houseNo +
                '}';
    }
}

class Child {
    private String name;
    private int sex;

    /**
     * @param num ��ȡ����ĸ���
     * @return �����ȡnum��Child ����
     */
    public static List<Child> getRandomChild(int num) {

        List<Child> childList = Lists.newArrayList();
        num = num < 1 ? 10 : num;
        for (int i = 0; i < num; i++) {
            childList.add(new Child("child" + i, i));
        }
        return childList;
    }

    Child(String name, int sex) {
        this.name = name;
        this.sex = sex;
    }

    public String getName() {
        return name;
    }

    public int getSex() {
        return sex;
    }

    @Override
    public String toString() {
        return "Child{" +
                "name='" + name + '\'' +
                ", sex=" + sex +
                '}';
    }
}


/**
 * ִ�в���
 */
public class POJO_EventType implements Runnable {

    private static final EPServiceProvider defaultProvider = EPServiceProviderManager.getDefaultProvider();
    private static final EPAdministrator epAdministrator = defaultProvider.getEPAdministrator();
    private static final EPRuntime epRuntime = defaultProvider.getEPRuntime();

    public static void main(String[] args) {


        POJO_EventType pojoEventType = new POJO_EventType();
        //��Person���͵��¼���nameΪxiaohuluʱ��Esper�ܵõ���Ӧ��age,children��address
        //pojoEventType.getFiledByName();

        //��Person���͵��¼���nameΪxiaohuluʱ��Esper�ܵõ���Ӧ�ĵڶ�������,����ĵ绰�ͼ�ͥסַ������·��
        pojoEventType.getFiledAndArrayIndexByName();

    }

    /**
     * ��Person���͵��¼���nameΪxiaohuluʱ��Esper�ܵõ���Ӧ��age,children��address
     * get...����������
     */
    private void getFiledByName() {

        final String epl = "select age,children,address from " + Person.CLASSNAME + " where name=\"xiaohulu\"";

        EPStatement epStatement = epAdministrator.createEPL(epl);
        //ע���޸��¼�����
       // epStatement.addListener((newEvents, oldEvents) -> {

        epStatement.addListener(
               new UpdateListener() {
            @Override
            public void update(EventBean[] newEvents, EventBean[] oldEvents) {
                if (newEvents != null) {
                    System.out.println("~~~~~~~~~~~~~newEvents write~~~~~~~~~~~~~~");
                    System.out.println("Person's age        is \t" + newEvents[0].get("age"));
                    System.out.println("Person's children   is \t" + newEvents[0].get("children"));
                    System.out.println("Person's address    is \t" + newEvents[0].get("address"));
                }

            }
        } );

        //Ĭ������2���¼�
        Person person = Person.getRandomPerson();
        epRuntime.sendEvent(person);

        Person randomPerson = Person.getRandomPerson("xiaohulu");
        epRuntime.sendEvent(randomPerson);
    }

    /**
     * ��Person���͵��¼���nameΪxiaohuluʱ��Esper�ܵõ���Ӧ�ĵڶ�������,����ĵ绰�ͼ�ͥסַ������·��
     * Person Ӧ�������·�����Ӧ
     * {@link Person#getChild(int)}     ��Ӧ�ĵڶ�������
     * {@link Person#getPhones(String)} ����ĵ绰
     */
    private void getFiledAndArrayIndexByName() {

        final String epl = "select children[1], phones('home'), address.road from " + Person.CLASSNAME + " where name=\"xiaohulu\"";

        EPStatement epStatement = epAdministrator.createEPL(epl);

        //ע����¼����� bean
        System.out.println("eventBean class");
        EventType[] eventBeans = epAdministrator.getConfiguration().getEventTypes();
        for (EventType eventBean : eventBeans) {
            System.out.println(eventBean.getName());
        }

        //ע���޸��¼�����
       // epStatement.addListener((newEvents, oldEvents) -> {
        epStatement.addListener(
                new UpdateListener() {
                    @Override
                    public void update(EventBean[] newEvents, EventBean[] oldEvents) {
                            if (newEvents != null) {
                                System.out.println("~~~~~~~~~~~~~newEvents write~~~~~~~~~~~~~~");
                                System.out.println("Person's children[1]        is \t" + newEvents[0].get("children[1]"));
                                System.out.println("Person's phones('home')     is \t" + newEvents[0].get("phones('home')"));
                                System.out.println("Person's address.road       is \t" + newEvents[0].get("address.road"));
                            }
                            if (oldEvents != null) {
                                System.out.println("~~~~~~~~~~~~~oldEvents write~~~~~~~~~~~~~~");
                                System.out.println("Person's children[1]        is \t" + oldEvents[0].get("children[1]"));
                                System.out.println("Person's phones('home')     is \t" + oldEvents[0].get("phones('home')"));
                                System.out.println("Person's address.road       is \t" + oldEvents[0].get("address.road"));
                            } else
                                System.out.println("~~~~~~~~~~~~~oldEvents not find ~~~~~~~~~~~~~~");
                    }
        });

        //�����߳������¼�
        new POJO_EventType().run();
    }

    @Override
    public void run() {
        int i = 0;
        while (i < 100) {
            i++;
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (i % 3 == 0)
                epRuntime.sendEvent(Person.getRandomPerson());
            else
                epRuntime.sendEvent(Person.getRandomPerson("xiaohulu"));
        }

    }
}