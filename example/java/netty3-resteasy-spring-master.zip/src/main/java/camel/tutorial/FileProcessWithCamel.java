package camel.tutorial;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class FileProcessWithCamel {
    public static void main(String args[]) throws Exception {
        CamelContext context = new DefaultCamelContext();
        context.addRoutes(new RouteBuilder() {

            public void configure() {
                FileConvertProcessor processor = new FileConvertProcessor();
                from("file:d:/temp/camel/inbox?noop=true").process(processor).to("file:d:/temp/camel/outbox");
            }
        });

        context.start();
        boolean loop = true;
        while (loop) {
            Thread.sleep(1000);
        }
        context.stop();
    }

    static class FileConvertProcessor implements Processor {
        @Override
        public void process(Exchange exchange) throws Exception {
            try {
                InputStream body = exchange.getIn().getBody(InputStream.class);
                BufferedReader in = new BufferedReader(new InputStreamReader(body));
                StringBuffer strbf = new StringBuffer("");
                String str = null;
                str = in.readLine();
                while (str != null) {
                    System.out.println(str);
                    strbf.append(str + " ");
                    str = in.readLine();
                }
                exchange.getOut().setHeader(Exchange.FILE_NAME, "converted.txt");
                // set the output to the file
                exchange.getOut().setBody(strbf.toString());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}