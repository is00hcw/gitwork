package com.atsmart.music;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.atsmart.music.jpa.PrivateRemarkRepository;
import com.atsmart.music.jpa.PrivateShareRepository;
import com.atsmart.music.jpa.PublicRemarkRepository;
import com.atsmart.music.jpa.PublicShareRepository;
import com.atsmart.music.jpa.SubscriptionRepository;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:root-context.xml")
public class AppTest {
	@Autowired
	SubscriptionRepository followRepo;

	@Autowired
	PrivateRemarkRepository privateRemarkRepo;

	@Autowired
	PublicRemarkRepository publicRemarkRepo;

	@Autowired
	PrivateShareRepository privateShareRepo;

	@Autowired
	PublicShareRepository publicShareRepo;
	
	@PersistenceContext 
	private EntityManager em;  
	
	@Test
	public void test() {
		try {
			System.out.println(em);
			System.out.println(publicRemarkRepo);
			System.out.println(publicShareRepo);
			List obj = publicShareRepo.findShareComment(111L);
			System.out.println(obj.getClass());
			System.out.println(obj.get(0));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
