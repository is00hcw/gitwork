package com.atsmart.music;

import okhttp3.*;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;
import retrofit2.http.Path;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

// http://blog.csdn.net/biezhihua/article/details/50603624
// http://allegro.tech/2016/04/meet-retrofit2.html
public class OkhttpTest {

    public static final String API_URL = "https://api.github.com";

    public static class Contributor {
        public final String login;
        public final int contributions;

        public Contributor(String login, int contributions) {
            this.login = login;
            this.contributions = contributions;
        }
    }

    public interface GitHub {
        @GET("/repos/{owner}/{repo}/contributors")
        Call<List<Contributor>> contributors(
                @Path("owner") String owner,
                @Path("repo") String repo);
    }

    public static void main(String... args) throws IOException {

        HttpLoggingInterceptor httpLoggingInterceptor = new HttpLoggingInterceptor();
        httpLoggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        int cacheSize = 10 * 1024 * 1024;
        Cache cache = new Cache(new File("bzh.tmp"), cacheSize);
        ConnectionPool connectionPool = new ConnectionPool(5, 60, TimeUnit.SECONDS);
        OkHttpClient client = new OkHttpClient().newBuilder()
                .addInterceptor(new Interceptor() {
                    @Override
                    public Response intercept(Chain chain) throws IOException {
                        Request request = chain.request()
                                .newBuilder()
//                                .addHeader("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
//                                .addHeader("Accept-Encoding", "gzip, deflate")
//                                .addHeader("Connection", "keep-alive")
//                                .addHeader("Accept", "*/*")
//                                .addHeader("Cookie", "add cookies here")
                                .build();
                        return chain.proceed(request);
                    }

                })
                .addInterceptor(new MyInterceptors())
                .addInterceptor(httpLoggingInterceptor)
                .retryOnConnectionFailure(true)
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS).writeTimeout(15, TimeUnit.SECONDS)
                .cache(cache)
                .connectionPool(connectionPool)
                        // 授权证书
                .authenticator(new Authenticator() {
                    @Override
                    public Request authenticate(Route route, Response response) throws IOException {
                        System.out.println("Authenticating for response: " + response);
                        System.out.println("Challenges: " + response.challenges());
                        String credential = Credentials.basic("jesse", "password1");
                        // HTTP授权的授权证书  Authorization: Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ==
                        return response
                                .request()
                                .newBuilder()
                                .header("Authorization", credential)
                                .build();
                    }
                })
                        .build();


        // Create a very simple REST adapter which points the GitHub API.
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(API_URL).client(client)
                //ProtoBuf converter
              //  .addConverterFactory(ProtoConverterFactory.create())
                //XML converter
                        //   .addConverterFactory(SimpleXmlConverterFactory.create())
                //Moshi converter
             //   .addConverterFactory(MoshiConverterFactory.create())
                //Scalar converter
            //    .addConverterFactory(ScalarsConverterFactory.create())
                //JSON converter
                .addConverterFactory(GsonConverterFactory.create())
               // .addConverterFactory(JacksonConverterFactory.create())
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .build();

        // Create an instance of our GitHub API interface.
        GitHub github = retrofit.create(GitHub.class);

        // Create a call instance for looking up Retrofit contributors.
        Call<List<Contributor>> call = github.contributors("square", "retrofit");

        // Fetch and print a list of the contributors to the library.
        List<Contributor> contributors = call.execute().body();
        for (Contributor contributor : contributors) {
            System.out.println(contributor.login + " (" + contributor.contributions + ")");
        }
    }


    public static class MyInterceptors implements Interceptor {
        @Override
        public Response intercept(Chain chain) throws IOException {

            //封装headers
            Request request = chain.request().newBuilder()
                    .addHeader("Content-Type", "application/json") //添加请求头信息
                    .build();
            Headers headers = request.headers();
            //打印
            System.out.println("Content-Type is : " + headers.get("Content-Type"));
            String requestUrl = request.url().toString(); //获取请求url地址
            String methodStr = request.method(); //获取请求方式
            RequestBody body = request.body(); //获取请求body
            String bodyStr = (body==null?"":body.toString());
            //打印Request数据
            System.out.println("Request Url is :" + requestUrl + "\nMethod is : " + methodStr + "\nRequest Body is :" + bodyStr + "\n");

            Response response = chain.proceed(request);
            if (response != null) {
                System.out.println("Response is not null");
            } else {
                System.out.println("Respong is null");
            }
            return response;

        }
    }
}