package com.atsmart.music.controller;

import java.util.List;
import java.util.Map;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;

import com.atsmart.music.domain.PrivateRemark;
import com.atsmart.music.domain.PrivateShare;
import com.atsmart.music.domain.PublicRemark;
import com.atsmart.music.domain.PublicShare;
import com.atsmart.music.service.FriendService;
import com.atsmart.music.service.ShareService;

@Controller
@Path("/api/v1/music")
public class ShareController {
  private final static Logger logger = LoggerFactory.getLogger(ShareController.class);

  @Autowired
  FriendService friendService;

  @Autowired
  ShareService shareService;

  // 添加朋友圈评论
  @POST
  @Path("/share/private/comments/add")
  @Produces("application/json")
  @Consumes("application/json")
  public Map<String, Object> addPrivateComment(@Context HttpHeaders headers,
      @QueryParam("share_id") long share_id,
      @QueryParam("publisher") String publisher, String content) throws Exception {
    System.out.println("content +++ " + content);
    PrivateRemark s = shareService.addPrivateComment(share_id, publisher, content);
    return ResponseBuilder.kvData("id", s.getId()).toResponse();
  }
  
  // 删除朋友圈评论
  @POST
  @Path("/share/private/comments/remove")
  @Produces("application/json")
  @Consumes("application/json")
  public Map<String, Object> removePrivateComment(@Context HttpHeaders headers,
      @QueryParam("id") long id,
      @QueryParam("publisher") String publisher) throws Exception {
    shareService.removePrivateComment(id, publisher);
    return ResponseBuilder.ok().toResponse();
  }
  
  @GET
  @Path("/share/private/comments/get")
  @Produces("application/json")
  @Consumes("application/json")
  public Map<String, Object> getPrivateComment(@Context HttpHeaders headers,
      @QueryParam("share_id") long share_id) throws Exception {
    List<PrivateRemark> list = shareService.findPrivateComments(share_id);
    return ResponseBuilder.data(list).toResponse();
  }
  
  @GET
  @Path("/share/public/comments/get")
  @Produces("application/json")
  @Consumes("application/json")
  public Map<String, Object> getPublicComment(@Context HttpHeaders headers,
      @QueryParam("share_id") long share_id) throws Exception {
    List<PublicRemark> list = shareService.findPublicComments(share_id);
    return ResponseBuilder.data(list).toResponse();
  }
  
  // 添加评论
  @POST
  @Path("/share/public/comments/add")
  @Produces("application/json")
  @Consumes("application/json")
  public Map<String, Object> addPublicComment(@Context HttpHeaders headers,
      @QueryParam("share_id") long share_id,
      @QueryParam("publisher") String publisher, String content) throws Exception {
    System.out.println("content +++ " + content);
    PublicRemark s = shareService.addPublicComment(share_id, publisher, content);
    return ResponseBuilder.kvData("id", s.getId()).toResponse();
  }
  
  // 删除朋友圈评论
  @POST
  @Path("/share/public/comments/remove")
  @Produces("application/json")
  @Consumes("application/json")
  public Map<String, Object> removePublicComment(@Context HttpHeaders headers,
      @QueryParam("id") long id,
      @QueryParam("publisher") String publisher) throws Exception {
    shareService.removePublicComment(id, publisher);
    return ResponseBuilder.ok().toResponse();
  }
  
  @POST
  @Path("/share/private/add")
  @Produces("application/json")
  @Consumes("application/json")
  public Map<String, Object> addPrivateShare(@Context HttpHeaders headers,
      @QueryParam("publisher") String publisher, String content) throws Exception {
    System.out.println("content +++ " + content);
    PrivateShare s = shareService.addPrivateShare(publisher, content);
    return ResponseBuilder.kvData("id", s.getId()).toResponse();
  }
  
  @POST
  @Path("/share/private/remove")
  @Produces("application/json")
  @Consumes("application/json")
  public Map<String, Object> removePrivateShare(@Context HttpHeaders headers,
      @QueryParam("id") long id) throws Exception {
    shareService.removePrivateShare(id);
    return ResponseBuilder.ok().toResponse();
  }
  
  @POST
  @Path("/share/public/add")
  @Produces("application/json")
  @Consumes("application/json")
  public Map<String, Object> addPublicShare(@Context HttpHeaders headers,
      @QueryParam("publisher") String publisher, String content) throws Exception {
    System.out.println("content +++ " + content);
    PublicShare s = shareService.addPublicShare(publisher, content);
    return ResponseBuilder.kvData("id", s.getId()).toResponse();
  }
  
  @POST
  @Path("/share/public/remove")
  @Produces("application/json")
  @Consumes("application/json")
  public Map<String, Object> removePublicShare(@Context HttpHeaders headers,
      @QueryParam("id") long id) throws Exception {
    shareService.removePublicShare(id);
    return ResponseBuilder.ok().toResponse();
  }
  
  @GET
  @Path("/share/public/latest")
  @Produces("application/json")
  @Consumes("application/json")
  public Map<String, Object> latestPublicShare(@Context HttpHeaders headers,
      @QueryParam("subscriber") String subscriber,
      @QueryParam("last_id") long lastId, @QueryParam("update_time") long updateTime
      //,@QueryParam("page") int page, @QueryParam("size") int size
      ) throws Exception {
    List<Long> list = shareService.findPublicShareAfter(subscriber, lastId, updateTime);
    System.out.println(list);
    return ResponseBuilder.data(list).toResponse();
  }
  
  @GET
  @Path("/share/public/detail")
  @Produces("application/json")
  @Consumes("application/json")
  public Map<String, Object> latestPublicShare(@Context HttpHeaders headers,
      @QueryParam("ids") String ids
      ) throws Exception {
    List<PublicShare> list = shareService.findPublicShareIn(ids);
    System.out.println(list);
    return ResponseBuilder.data(list).toResponse();
  }

  @GET
  @Path("/share/private/timeline")
  @Produces("application/json")
  @Consumes("application/json")
  public Map<String, Object> privateShareTimeline(@Context HttpHeaders headers,
      @QueryParam("publisher") String publisher, 
      @QueryParam("page") int page, @QueryParam("size") int size) throws Exception {
    Page<PrivateShare> list = shareService.findPrivateShareTimeline(publisher, page, size);
    System.out.println(list);
    return ResponseBuilder.data(list).toResponse();
  }
  
  @GET
  @Path("/share/private/latest")
  @Produces("application/json")
  @Consumes("application/json")
  public Map<String, Object> latestPrivateShare(@Context HttpHeaders headers,
      @QueryParam("subscriber") String subscriber,
      @QueryParam("last_id") long lastId, @QueryParam("update_time") long updateTime
      //,@QueryParam("page") int page, @QueryParam("size") int size
      ) throws Exception {
    List<Long> list = shareService.findPrivateShareAfter(subscriber, lastId, updateTime);
    System.out.println(list);
    return ResponseBuilder.data(list).toResponse();
  }
  
  @GET
  @Path("/share/private/detail")
  @Produces("application/json")
  @Consumes("application/json")
  public Map<String, Object> latestPrivateShare(@Context HttpHeaders headers,
      @QueryParam("ids") String ids
      //,@QueryParam("page") int page, @QueryParam("size") int size
      ) throws Exception {
    List<PrivateShare> list = shareService.findPrivateShareIn(ids);
    System.out.println(list);
    return ResponseBuilder.data(list).toResponse();
  }

  @GET
  @Path("/share/private/archive")
  @Produces("application/json")
  @Consumes("application/json")
  public Map<String, Object> archivePrivateShare(@Context HttpHeaders headers,
      @QueryParam("subscriber") String subscriber,
      @QueryParam("before_id") long beforeId
     // , @QueryParam("page") int page,   @QueryParam("size") int size
      ) throws Exception {
    List<Long> list = shareService.findPrivateShareBefore(subscriber, beforeId);
    System.out.println(list);
    return ResponseBuilder.data(list).toResponse();
  }

  @POST
  @Path("/subscription/add")
  @Produces("application/json")
  @Consumes("application/json")
  public Map<String, Object> addSubscription(@Context HttpHeaders headers,
      @QueryParam("subscriber") String subscriber, @QueryParam("publisher") String publisher)
      throws Exception {
    // Follow jsonObject = JSONObject.parseObject(content, Follow.class);
    System.out.println("-- " + subscriber + " , " + publisher);
    friendService.addSubscription(subscriber, publisher);
    return ResponseBuilder.ok().toResponse();
  }

  @POST
  @Path("/subscription/remove")
  @Produces("application/json")
  @Consumes("application/json")
  public Map<String, Object> removeSubscription(@Context HttpHeaders headers,
      @QueryParam("subscriber") String subscriber, @QueryParam("publisher") String publisher)
      throws Exception {
    // Follow jsonObject = JSONObject.parseObject(content, Follow.class);
    friendService.removeSubscription(subscriber, publisher);
    return ResponseBuilder.ok().toResponse();
  }

  // 查询订阅了当前用户的粉丝列表
  @GET
  @Path("/subscription/subscribers")
  @Produces("application/json")
  @Consumes("application/json")
  public Map<String, Object> getSubscribers(@Context HttpHeaders headers,
      @QueryParam("publisher") String publisher) throws Exception {
    // List<Subscription> list = friendService.findSubscriptionsByPublisher(publisher);
    List<String> list = friendService.findSubscribersByPublisher(publisher);
    return ResponseBuilder.data(list).toResponse();
  }

  // 查询订阅了当前用户的关注列表
  @GET
  @Path("/subscription/publishers")
  @Produces("application/json")
  @Consumes("application/json")
  public Map<String, Object> getPublishers(@Context HttpHeaders headers,
      @QueryParam("subscriber") String subscriber) throws Exception {
    List<String> list = friendService.findPublishersBySubscriber(subscriber);
    return ResponseBuilder.data(list).toResponse();
  }
}
