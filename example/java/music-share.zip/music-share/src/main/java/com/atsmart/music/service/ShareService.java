package com.atsmart.music.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.atsmart.music.domain.PrivateRemark;
import com.atsmart.music.domain.PrivateShare;
import com.atsmart.music.domain.PublicRemark;
import com.atsmart.music.domain.PublicShare;

public interface ShareService {

  PrivateShare addPrivateShare(String publisher, String content);

  void removePrivateShare(long id);

  // 最新的更新
  List<Long> findPrivateShareAfter(String subscriber, long lastId, long updateTime) ;
  //Page<PrivateShare> findPrivateShareAfter(String subscriber, long lastId, long updateTime, int page, int size);

  // 历史的
  //Page<PrivateShare> findPrivateShareBefore(String subscriber, long beforeId, int page, int size);
  List<Long> findPrivateShareBefore(String subscriber, long beforeId);
  
  // 个人发布的内容列表
  Page<PrivateShare> findPrivateShareTimeline(String publisher, int page, int size);

  List<PrivateShare> findPrivateShareIn(String ids);

  PublicShare addPublicShare(String publisher, String content);
  
  void removePublicShare(long id);

  List<PublicShare> findPublicShareIn(String ids);

  List<Long> findPublicShareAfter(String subscriber, long lastId, long updateTime);

  PrivateRemark addPrivateComment(Long share_id, String publisher, String content);

  void removePrivateComment(Long id, String publisher);
  
  PublicRemark addPublicComment(Long share_id, String publisher, String content) ;
  
  void removePublicComment(Long id, String publisher);

  List<PrivateRemark> findPrivateComments(long share_id);
  
  List<PublicRemark> findPublicComments(long share_id);
}
