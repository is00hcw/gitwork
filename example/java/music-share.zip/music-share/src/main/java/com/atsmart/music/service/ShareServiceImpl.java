package com.atsmart.music.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;
import org.springframework.stereotype.Component;

import com.atsmart.music.IdWorker;
import com.atsmart.music.domain.PrivateRemark;
import com.atsmart.music.domain.PrivateShare;
import com.atsmart.music.domain.PublicRemark;
import com.atsmart.music.domain.PublicShare;
import com.atsmart.music.jpa.PrivateRemarkRepository;
import com.atsmart.music.jpa.PrivateShareRepository;
import com.atsmart.music.jpa.PublicRemarkRepository;
import com.atsmart.music.jpa.PublicShareRepository;

@Component
public class ShareServiceImpl implements ShareService {
  private static final Sort ID_DESC = new Sort(new Order(Direction.DESC, "id"));
  private static final Sort ID_ASC = new Sort(new Order(Direction.ASC, "id"));
  
  private final static Logger logger = LoggerFactory.getLogger(ShareServiceImpl.class);

  private static final int MAX_SIZE = 50;

  @Autowired
  PrivateRemarkRepository privateRemarkRepo;
  
  @Autowired
  PublicRemarkRepository publicRemarkRepo;
  
  @Autowired
  PrivateShareRepository privateShareRepo;
  
  @Autowired
  PublicShareRepository publicShareRepo;
  
  IdWorker idGen = IdWorker.getInstance(1);
  
  @Override
  public PrivateShare addPrivateShare(String publisher, String content) {
    PrivateShare p = new PrivateShare();
    p.setId(idGen.nextId());
    p.setUserid(publisher);
    p.setCreateTime(System.currentTimeMillis());
    p.setContent(content);
    privateShareRepo.saveAndFlush(p);
    return p;
  }

  @Override
  public void removePrivateShare(long id) {
    privateShareRepo.delete(id);
  }

  public List<Long> findPrivateShareAfter(String subscriber, long lastId, long updateTime) {
    return privateShareRepo.findLatestForSubscriber(subscriber, lastId);
  }
  /*@Override
  public Page<PrivateShare> findPrivateShareAfter(String subscriber, long lastId, long updateTime, int page, int size) {
    PageRequest req = newPageRequest(page, size, ID_DESC); // 时间倒序，最新的排前面
    System.out.println("----page " + req);
    System.out.printf("----current time:%d  updateTime:%d  lastId:%d \n",System.currentTimeMillis(),updateTime, lastId );
//    return privateRepo.findByIdGreaterThan(lastId, req);
    return privateRepo.findLatestForSubscriber(subscriber, lastId, req);
  }*/

  private PageRequest newPageRequest(int page, int size, Sort sort) {
    if(page < 0)
      page = 0;
    if(size < 0 || size > MAX_SIZE)
      size = MAX_SIZE;
    return new PageRequest(page, size);
  }

//  @Override
//  public Page<PrivateShare> findPrivateShareBefore(String subscriber,long beforeId, int page, int size) {
//    PageRequest req = newPageRequest(page, size, ID_DESC); 
//    System.out.println("----page " + req);
//    return privateRepo.findByIdLessThan(beforeId, req);
//  }

  @Override
  public List<Long> findPrivateShareBefore(String subscriber, long beforeId) {
    return privateShareRepo.findArchiveForSubscriber(subscriber, beforeId);
  }

  @Override
  public Page<PrivateShare> findPrivateShareTimeline(String publisher, int page, int size) {
    PageRequest req = newPageRequest(page, size, ID_DESC); 
    return privateShareRepo.findByUserid(publisher, req);
  }

  @Override
  public List<PrivateShare> findPrivateShareIn(String ids) {
    return privateShareRepo.findByIdIn(toLongList(ids.split(",")));
  }

  private List<Long> toLongList(String[] data) {
    List<Long> list = new ArrayList<Long>(data.length);
    for(int i = 0; i < data.length; i ++)
      list.add(Long.parseLong(data[i].trim()));
    return list;
  }

  @Override
  public PublicShare addPublicShare(String publisher, String content) {
    PublicShare p = new PublicShare();
    p.setId(idGen.nextId());
    p.setUserid(publisher);
    p.setCreateTime(System.currentTimeMillis());
    p.setContent(content);
    publicShareRepo.saveAndFlush(p);
    return p;
  }

  @Override
  public void removePublicShare(long id) {
    publicShareRepo.delete(id);
  }

  @Override
  public List<PublicShare> findPublicShareIn(String ids) {
    return publicShareRepo.findByIdIn(toLongList(ids.split(",")));
  }

  @Override
  public List<Long> findPublicShareAfter(String subscriber, long lastId, long updateTime) {
    return publicShareRepo.findLatestForSubscriber(lastId);
  }

  @Override
  public PrivateRemark addPrivateComment(Long share_id, String publisher, String content) {
    PrivateRemark r = new PrivateRemark();
    r.setId(idGen.nextId());
    r.setShareId(share_id);
    r.setUserid(publisher);
    r.setCreateTime(System.currentTimeMillis());
    r.setComments(content);
    privateRemarkRepo.saveAndFlush(r);
    return r;
  }

  @Override
  public void removePrivateComment(Long id, String publisher) {
    privateRemarkRepo.delete(id);
  }
  
  public PublicRemark addPublicComment(Long share_id, String publisher, String content) {
    PublicRemark r = new PublicRemark();
    r.setId(idGen.nextId());
    r.setShareId(share_id);
    r.setUserid(publisher);
    r.setCreateTime(System.currentTimeMillis());
    r.setComments(content);
    publicRemarkRepo.saveAndFlush(r);
    return r;
  }
  
  @Override
  public void removePublicComment(Long id, String publisher) {
    publicRemarkRepo.delete(id);
  }

  @Override
  public List<PrivateRemark> findPrivateComments(long share_id) {
    return privateRemarkRepo.findByShareId(share_id);
  }

  @Override
  public List<PublicRemark> findPublicComments(long share_id) {
    return publicRemarkRepo.findByShareId(share_id);
  }

}
