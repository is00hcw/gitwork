package com.atsmart.music.jpa;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.atsmart.music.domain.PrivateShare;

public interface PrivateShareRepository extends JpaRepository<PrivateShare, Long>{

  //  Cannot use native queries with dynamic sorting and/or pagination
  @Query(value="SELECT id FROM private_shares WHERE id > ?2 AND userid IN (SELECT publisher FROM subscription WHERE subscriber=?1) ORDER BY id ASC LIMIT 0,100",nativeQuery=true)
  List<Long> findLatestForSubscriber(String subscriber, long lastId);
  
  @Query(value="SELECT id FROM private_shares WHERE id < ?2 AND userid IN (SELECT publisher FROM subscription WHERE subscriber=?1) ORDER BY id DESC LIMIT 0,100",nativeQuery=true)
  List<Long> findArchiveForSubscriber(String subscriber, long beforeId); 
  
//  Page<PrivateShare> findByIdGreaterThan(long lastId, Pageable page);
//
//  Page<PrivateShare> findByIdLessThan(long beforeId, Pageable page);

  Page<PrivateShare> findByUserid(String publisher, Pageable req);

  List<PrivateShare> findByIdIn(List<Long> ids);

 
}
