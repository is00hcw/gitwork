package com.atsmart.music.jpa;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.atsmart.music.domain.User;

@Deprecated
public interface UserRepository extends JpaRepository<User, String>{ 
     
   
//    @Query(value = "SELECT * FROM Customer WHERE username = ?1", nativeQuery = true)
//    Customer findByName1(String name);
    
//    @Modifying 
//    @Query("update Customer u set u.age = ?1 where u.id = ?2")
//    int update(int age1 , long id);
}