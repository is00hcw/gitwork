package com.atsmart.music.domain;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the subscribe database table.
 * 
 */
@Entity
@NamedQuery(name="Subscription.findAll", query="SELECT s FROM Subscription s")
public class Subscription implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;

	private String publisher;

	private String subscriber;

	public Subscription() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getPublisher() {
		return this.publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public String getSubscriber() {
		return this.subscriber;
	}

	public void setSubscriber(String subscriber) {
		this.subscriber = subscriber;
	}

  @Override
  public String toString() {
    return "Subscribe [id=" + id + ", publisher=" + publisher + ", subscriber=" + subscriber + "]";
  }

	
}