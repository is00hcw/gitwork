package com.atsmart.music.job;
import java.util.Date;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;

 
public class ClusterJobSample extends QuartzJobBean
{
//    @Autowired
//    private TestService testService;

    @Override
    protected void executeInternal(JobExecutionContext arg0)
        throws JobExecutionException
    {
        System.out.println(new Date() + "Hello Cluster Timer sample!");
    // try
    // {
    // testService.index("cluster");
    // }
    // catch (Exception e)
    // {
    // // TODO Auto-generated catch block
    // e.printStackTrace();
    // }
    }
    
}