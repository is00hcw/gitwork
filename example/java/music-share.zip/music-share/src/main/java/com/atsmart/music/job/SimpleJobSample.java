package com.atsmart.music.job;

import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@DisallowConcurrentExecution
public class SimpleJobSample {
//    @Autowired
//    private MyService myService;
 
    public void execute() {
        System.out.println("Message: " + System.currentTimeMillis());
    }
}