package com.atsmart.music.jpa;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.atsmart.music.domain.PublicShare;

public interface PublicShareRepository extends JpaRepository<PublicShare, Long>{ 
  List<PublicShare> findByIdIn(List<Long> ids);

  @Query(value="SELECT id FROM public_shares WHERE id > ?1 ORDER BY id ASC LIMIT 0,100",nativeQuery=true)
  List<Long> findLatestForSubscriber(long lastId);
  
  
 // @Transactional(readOnly = true)
  //@QueryHints({ @QueryHint(name = "org.hibernate.cacheable", value ="true") })  
  @Query(value="SELECT s.`id`,s.`content`,s.`userid`,r.`comments` FROM public_shares s , public_remarks r WHERE s.`id` = r.`share_id` AND s.`userid` = ?1",nativeQuery=true)
  List<Map> findShareComment(Long id);
}
