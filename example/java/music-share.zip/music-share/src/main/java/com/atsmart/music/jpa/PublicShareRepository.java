package com.atsmart.music.jpa;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.atsmart.music.domain.PublicShare;

public interface PublicShareRepository extends JpaRepository<PublicShare, Long>{ 
  List<PublicShare> findByIdIn(List<Long> ids);

  @Query(value="SELECT id FROM public_shares WHERE id > ?2 ORDER BY id ASC LIMIT 0,100",nativeQuery=true)
  List<Long> findLatestForSubscriber(long lastId);
}
