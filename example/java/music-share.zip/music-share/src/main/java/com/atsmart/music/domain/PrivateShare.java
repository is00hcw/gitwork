package com.atsmart.music.domain;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigInteger;


/**
 * The persistent class for the private_shares database table.
 * 
 */
@Entity
@Table(name="private_shares")
@NamedQuery(name="PrivateShare.findAll", query="SELECT p FROM PrivateShare p")
public class PrivateShare implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;

	private String content;

	@Column(name="create_time")
	private long createTime;

	@Column(name="praise_times")
	private int praiseTimes;

	private String userid;

	public PrivateShare() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public long getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(long createTime) {
		this.createTime = createTime;
	}

	public int getPraiseTimes() {
		return this.praiseTimes;
	}

	public void setPraiseTimes(int praiseTimes) {
		this.praiseTimes = praiseTimes;
	}

	public String getUserid() {
		return this.userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

}