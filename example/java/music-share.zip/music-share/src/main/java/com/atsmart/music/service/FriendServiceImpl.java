package com.atsmart.music.service;

import java.util.List;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Component;

import com.atsmart.music.IdWorker;
import com.atsmart.music.controller.ShareController;
import com.atsmart.music.domain.Subscription;
import com.atsmart.music.jpa.SubscriptionRepository;

@Component
public class FriendServiceImpl implements FriendService {
  private final static Logger logger = LoggerFactory.getLogger(FriendServiceImpl.class);

  @Autowired
  SubscriptionRepository followRepo;
  
  IdWorker idGen = IdWorker.getInstance(1);
  
  @Override
  public boolean addSubscription(String subscriber, String publisher) {
    Subscription f = new Subscription();
    f.setId(idGen.nextId());
    f.setSubscriber(subscriber);
    f.setPublisher(publisher);
    System.out.println("++++" + f);
    followRepo.saveAndFlush(f);
    return true;
  }

  @Transactional
  @Override
  public boolean removeSubscription(String subscriber, String publisher) {
    int ret = followRepo.cancelSubscription(subscriber, publisher);
    return ret == 1;
  }

  public List<Subscription> findSubscriptionsByPublisher(String publisher){
    return followRepo.findByPublisher(publisher);
  }
  
  public List<String> findSubscribersByPublisher(String publisher){
    return followRepo.findSubscribers(publisher);
  }

  @Override
  public List<String> findPublishersBySubscriber(String subscriber) {
    return followRepo.findPublishers(subscriber);
  }
}
