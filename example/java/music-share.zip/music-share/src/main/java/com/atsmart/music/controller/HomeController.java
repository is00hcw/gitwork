package com.atsmart.music.controller;

import java.util.List;

import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.NewCookie;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.SecurityContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.alibaba.fastjson.JSONObject;
import com.atsmart.music.jpa.UserRepository;

@Deprecated
@Controller
@Path("/hello")
public class HomeController {

  @Autowired(required = false)
  UserRepository userRepo;

  @GET
  @Path("/error")
  @Produces("application/json")
  public Response error() {
    if(true)
      throw new WebApplicationException(Response.Status.NOT_FOUND);
    return Response.ok().build();
  }
  
  @GET
  @Path("/cookie")
  @Produces("application/json")
  public Response cookie() {
    NewCookie c = new NewCookie("c22","val1","/","192.168.10.70",null,-1, false);
    ResponseBuilder builder = Response.ok("ok", "text/plain");
    return builder.cookie(c).build();
  }
  
  
  // @Autowired(required=false)
  // UserMapper userMapper;
  // // http://localhost:8082/hello/mybatis
  // @GET
  // @Path("/mybatis")
  // @Produces("application/json")
  // public String mybatis() throws Exception {
  // System.out.println(userMapper);
  // int count = userMapper.countByExample(new UserExample());
  // return new String("Welcome, Hello World " + count);
  // }

  // @GET
  // @Path("/world")
  // @Produces("application/json")
  // public Follow helloworld(@QueryParam("id") int id) throws Exception {
  // System.out.println(userRepo);
  // int count = (int) userRepo.count();
  // //return new String("Welcome, Hello World " + count);
  // System.out.println(Integer.MAX_VALUE);
  // return new Follow(id,"aa","bb");
  // }

  // @POST
  // @Path("/add_follow")
  // @Produces("application/json")
  // @Consumes("application/json")
  // public Follow add_follow(@Context HttpHeaders headers,String content)throws Exception {
  // Follow jsonObject = JSONObject.parseObject(content, Follow.class);
  // System.out.println(jsonObject);
  // return jsonObject;
  // }
}
