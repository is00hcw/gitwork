package com.atsmart.music.jpa;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.atsmart.music.domain.PublicRemark;

public interface PublicRemarkRepository extends JpaRepository<PublicRemark, Long>{

  List<PublicRemark> findByShareId(long share_id);

}
