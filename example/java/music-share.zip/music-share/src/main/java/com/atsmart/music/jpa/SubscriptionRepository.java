package com.atsmart.music.jpa;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.atsmart.music.domain.Subscription;


public interface SubscriptionRepository extends JpaRepository<Subscription, Long>{ 
  
  List<Subscription> findByPublisher(String publisher);
  
  List<Subscription> findBySubscriber(String subscriber);
  
  @Query(value="select subscriber from subscription where publisher=?1",nativeQuery=true)
  List<String> findSubscribers(String publisher);
  
  @Query(value="select publisher from subscription where subscriber=?1",nativeQuery=true)
  List<String> findPublishers(String subscriber);
  
  @Modifying
  @Query(value="delete from subscription where subscriber=?1 and publisher=?2",nativeQuery=true)
  int cancelSubscription(String subscriber,String publisher);
}
