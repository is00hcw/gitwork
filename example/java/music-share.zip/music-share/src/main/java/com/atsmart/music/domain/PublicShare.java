package com.atsmart.music.domain;

import java.io.Serializable;

import javax.persistence.*;

import java.math.BigInteger;


/**
 * The persistent class for the public_shares database table.
 * 
 */
@Entity
@Table(name="public_shares")
@NamedQuery(name="PublicShare.findAll", query="SELECT p FROM PublicShare p")
public class PublicShare implements Serializable {
	private static final long serialVersionUID = 1L;

	private String content;

	@Column(name="create_time")
	private long createTime;
	
	@Id
	private long id;

	@Column(name="praise_times")
	private int praiseTimes;

	private String userid;

	public PublicShare() {
	}

	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public long getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(long createTime) {
		this.createTime = createTime;
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getPraiseTimes() {
		return this.praiseTimes;
	}

	public void setPraiseTimes(int praiseTimes) {
		this.praiseTimes = praiseTimes;
	}

	public String getUserid() {
		return this.userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

}