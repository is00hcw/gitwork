package com.atsmart.music.controller;

import java.util.HashMap;
import java.util.Map;


public class ResponseBuilder {
  public static final int CODE_OK = 200;
  Map<String, Object> data = new HashMap<String, Object>();

  public static ResponseBuilder ok() {
    ResponseBuilder b = new ResponseBuilder();
    b.data.put("code", CODE_OK);
    return b;
  }

  public static ResponseBuilder data(Object obj) {
    ResponseBuilder b = new ResponseBuilder();
    b.data.put("code", CODE_OK);
    b.data.put("data", obj);
    return b;
  }
  
  public static ResponseBuilder kvData(String key, Object val){
    Map<String,Object> obj = new HashMap<String,Object>();
    obj.put(key, val);
    return data(obj);
}

  public ResponseBuilder append(String key, Object val) {
    this.data.put(key, val);
    return this;
  }

  public Map<String, Object> toResponse() {
    return this.data;
  }
}
