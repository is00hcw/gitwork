package com.atsmart.music.domain;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigInteger;


/**
 * The persistent class for the private_remarks database table.
 * 
 */
@Entity
@Table(name="private_remarks")
@NamedQuery(name="PrivateRemark.findAll", query="SELECT p FROM PrivateRemark p")
public class PrivateRemark implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long id;

	private String comments;

	@Column(name="create_time")
	private long createTime;

	@Column(name="share_id")
	private long shareId;

	private String userid;

	public PrivateRemark() {
	}

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getComments() {
		return this.comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public long getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(long createTime) {
		this.createTime = createTime;
	}

	public long getShareId() {
		return this.shareId;
	}

	public void setShareId(long shareId) {
		this.shareId = shareId;
	}

	public String getUserid() {
		return this.userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

}