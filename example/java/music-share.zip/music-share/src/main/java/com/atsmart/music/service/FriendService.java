package com.atsmart.music.service;

import java.util.List;

import com.atsmart.music.domain.Subscription;

public interface FriendService {

  boolean addSubscription(String subscriber, String publisher) ;

  boolean removeSubscription(String subscriber, String publisher);

  List<Subscription> findSubscriptionsByPublisher(String publisher);
  
  List<String> findSubscribersByPublisher(String publisher);
  
  List<String> findPublishersBySubscriber(String subscriber);
}
