package com.atsmart.music.domain;

import java.io.Serializable;

import javax.persistence.*;

import java.math.BigInteger;


/**
 * The persistent class for the public_remarks database table.
 * 
 */
@Entity
@Table(name="public_remarks")
@NamedQuery(name="PublicRemark.findAll", query="SELECT p FROM PublicRemark p")
public class PublicRemark implements Serializable {
	private static final long serialVersionUID = 1L;

	private String comments;

	@Column(name="create_time")
	private long createTime;

	@Id
	private long id;

	@Column(name="share_id")
	private long shareId;

	private String userid;

	public PublicRemark() {
	}

    public long getId() {
        return this.id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getComments() {
        return this.comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public long getCreateTime() {
        return this.createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    public long getShareId() {
        return this.shareId;
    }

    public void setShareId(long shareId) {
        this.shareId = shareId;
    }

    public String getUserid() {
        return this.userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

}