/*
SQLyog Trial v12.12 (64 bit)
MySQL - 5.5.18.1-log : Database - db05
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`db05` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `db05`;

/*Table structure for table `private_remarks` */

DROP TABLE IF EXISTS `private_remarks`;

CREATE TABLE `private_remarks` (
  `id` bigint(64) NOT NULL,
  `share_id` bigint(64) NOT NULL COMMENT '评论所在的分享内容',
  `comments` varchar(240) COLLATE utf8_unicode_ci NOT NULL COMMENT '评论内容',
  `userid` varchar(64) COLLATE utf8_unicode_ci NOT NULL COMMENT '发表评论的用户',
  `create_time` bigint(64) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `private_shares` */

DROP TABLE IF EXISTS `private_shares`;

CREATE TABLE `private_shares` (
  `id` bigint(64) NOT NULL,
  `userid` varchar(50) NOT NULL,
  `content` varchar(300) NOT NULL,
  `create_time` bigint(64) DEFAULT '0',
  `praise_times` int(32) DEFAULT '0' COMMENT '称赞次数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `public_remarks` */

DROP TABLE IF EXISTS `public_remarks`;

CREATE TABLE `public_remarks` (
  `id` bigint(64) NOT NULL,
  `share_id` bigint(64) NOT NULL COMMENT '评论所在的分享内容',
  `comments` varchar(240) COLLATE utf8_unicode_ci NOT NULL COMMENT '评论内容',
  `userid` varchar(64) COLLATE utf8_unicode_ci NOT NULL COMMENT '发表评论的用户',
  `create_time` bigint(64) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

/*Table structure for table `public_shares` */

DROP TABLE IF EXISTS `public_shares`;

CREATE TABLE `public_shares` (
  `id` bigint(64) NOT NULL,
  `userid` varchar(50) NOT NULL,
  `content` varchar(300) NOT NULL,
  `create_time` int(64) DEFAULT '0',
  `praise_times` int(32) DEFAULT '0' COMMENT '称赞次数'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Table structure for table `subscription` */

DROP TABLE IF EXISTS `subscription`;

CREATE TABLE `subscription` (
  `id` bigint(64) NOT NULL,
  `subscriber` varchar(50) NOT NULL,
  `publisher` varchar(50) NOT NULL,
  `create_time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
