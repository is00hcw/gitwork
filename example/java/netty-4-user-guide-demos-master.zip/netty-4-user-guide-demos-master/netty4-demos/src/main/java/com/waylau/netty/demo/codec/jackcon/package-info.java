/**
 * 
 */
/**
 * 说明：使用 Jackson json 来执行序列化
 * @author <a href="http://www.waylau.com">waylau.com</a>  2015年11月8日
 */
package com.waylau.netty.demo.codec.jackcon;