/**
 * 
 */
/**
 * 说明：工具包
 *
 * @author <a href="http://www.waylau.com">waylau.com</a> 2015年11月10日 
 */
package com.waylau.netty.util;