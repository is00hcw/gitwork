/**
 * 
 */
/**
 * 说明：本例子是一个心跳服务器程序。
 * 可以设置连接超时时间。如果连接超时，则服务器发送心跳消息给客户端。
 * 本例的客户端可以是 Telnet 程序。
 *
 * @author <a href="http://www.waylau.com">waylau.com</a> 2015年11月6日 
 */
package com.waylau.netty.demo.heartbeat;