/**
 * 说明：该包下的例子，主要是实现了自定义二进制协议
 *
 * @author <a href="http://www.waylau.com">waylau.com</a> 2015年11月4日 
 */
package com.waylau.netty.demo.protocol;
