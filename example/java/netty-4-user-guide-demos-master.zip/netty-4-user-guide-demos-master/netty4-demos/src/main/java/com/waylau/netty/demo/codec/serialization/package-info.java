/**
 * 
 */
/**
 * 说明：使用 Netty 自带的序列化工具对 Java 对象进行序列化
 *
 * @author <a href="http://www.waylau.com">waylau.com</a> 2015年11月7日 
 */
package com.waylau.netty.demo.codec.serialization;