package com.colobu.rest.springboot;


import org.springframework.boot.SpringApplication;

public class Main {
    public static void main(String[] args) throws Exception {
        SpringApplication.run(HelloController.class, args);
    }
}
