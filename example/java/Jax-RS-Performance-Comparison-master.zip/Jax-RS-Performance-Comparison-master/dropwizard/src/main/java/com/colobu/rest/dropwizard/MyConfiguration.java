package com.colobu.rest.dropwizard;


import io.dropwizard.Configuration;

// add configuration if necessary.
public class MyConfiguration extends Configuration {
}
