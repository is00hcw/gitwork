package com.colobu.rest.dropwizard;


public class Main {
    public static void main(String[] args) throws Exception {
        new MyApplication().run(args);
    }
}
