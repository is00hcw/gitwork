namespace java com.colobu.armeria.service.thrift.v1

service HelloService {
    string hello()
}