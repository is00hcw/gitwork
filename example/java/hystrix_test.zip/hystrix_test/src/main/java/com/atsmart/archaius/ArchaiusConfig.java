package com.atsmart.archaius;

import com.netflix.config.*;
import com.netflix.config.sources.JDBCConfigurationSource;
import com.netflix.config.sources.URLConfigurationSource;
import org.apache.commons.configuration.AbstractConfiguration;

import java.io.IOException;
import java.util.Collections;

/**
 * Hello world!
 *
 */
public class ArchaiusConfig
{

    public static String getStringProperty(String key, String defaultValue) {
        final DynamicStringProperty property = DynamicPropertyFactory.getInstance().getStringProperty(key,
                defaultValue);
        return property.get();
    }

    public static void main( String[] args )
    {
    /*
        By default, Archaius will look for a file named “config.properties” on the application’s classpath and read its content as configuration properties. The file can be also in a jar file’s root directory.
            In addition, you can define a system property “archaius.configurationSource.additionalUrls” that contains the URL path to a local configuration file.
        -Darchaius.configurationSource.additionalUrls=file:///apps/myapp/application.properties
      */

      //  System.setProperty("archaius.configurationSource.additionalUrls", "newconfig.properties");
        System.setProperty("archaius.configurationSource.defaultFileName", "newconfig.properties");
        try {
          //  ConfigurationManager.loadCascadedPropertiesFromResources("newconfig");  // "config"
            watchResources();
        } catch (Exception e) {
            e.printStackTrace();
        }

        while(true) {
            DynamicLongProperty timeToWait =
                    DynamicPropertyFactory.getInstance().getLongProperty("lock.waitTime", 1000);
            System.out.println(timeToWait.get());

            DynamicStringListProperty listProperty = new DynamicStringListProperty("listprop", Collections.<String>emptyList());
            System.out.println(listProperty.get());

            DynamicStringMapProperty mapProperty = new DynamicStringMapProperty("mapprop", Collections.<String, String>emptyMap());
            System.out.println(mapProperty.getMap());

            System.out.println(getStringProperty("newconf", ""));
        }
    }

    private static void watchResources() {
        if (!ConfigurationManager.isConfigurationInstalled())
        {
            try {
                AbstractPollingScheduler scheduler =  new FixedDelayPollingScheduler(0, 100, true); // or use your own scheduler
                PolledConfigurationSource source = new URLConfigurationSource(); // or use your own source
                scheduler.setIgnoreDeletesFromSource(true); // don't treat properties absent from the source as deletes

                DynamicConfiguration configuration = new DynamicConfiguration(source,scheduler );   //   scheduler.startPolling(source, myConfiguration);
                ConfigurationManager.install(configuration);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


}
