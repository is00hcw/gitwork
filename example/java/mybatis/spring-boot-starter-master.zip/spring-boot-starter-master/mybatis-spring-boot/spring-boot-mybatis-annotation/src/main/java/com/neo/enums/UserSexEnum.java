package com.neo.enums;

public enum UserSexEnum {
	MAN, WOMAN
}
