spring-boot-mybatis
===========

对Spring boot组合mybatis的学习，一个是注解版，一个是配置版


mybatis和spring结合大大的减少了使用mybatis的配置，主要是使用[mybatis-spring-boot-starter](https://github.com/mybatis/spring-boot-starter)


- [spring-boot-mybaits-annotation](https://github.com/ityouknow/spring-boot-starter/tree/master/mybatis-spring-boot/spring-boot-mybatis-annotation)：注解版本

- [spring-boot-mybaits-xml](https://github.com/ityouknow/spring-boot-starter/tree/master/mybatis-spring-boot/spring-boot-mybatis-xml)：xml配置版本

- users.sql ：示例中的表结构