package com.isea533.mybatis.controller.demo;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by Administrator on 2016/3/31.
 */
public class ResponseBuilder {
    Map<String,Object> data = new HashMap<String,Object>();
    HttpStatus statusCode = HttpStatus.OK;
    HttpHeaders headers = new HttpHeaders();

    public static ResponseBuilder data(Object obj){
        ResponseBuilder b = new ResponseBuilder();
        b.data.put("code",200);
        b.data.put("data",obj);
        return b;
    }

    public static ResponseBuilder error(int code, String message){
        return error(code, message, HttpStatus.BAD_REQUEST);
    }

    public static ResponseBuilder error(int code, String message, HttpStatus status) {
        ResponseBuilder b = new ResponseBuilder();
        b.data.put("code", code);
        b.data.put("error",message);
        b.statusCode = status;
        return b;
    }

    public ResponseBuilder setHeader(String name, String value){
        this.headers.set(name,value);
        return this;
    }


    public ResponseEntity<Map<String,Object>> toResponse(){
        return new ResponseEntity<Map<String,Object>>(data,headers,statusCode );
    }
}
