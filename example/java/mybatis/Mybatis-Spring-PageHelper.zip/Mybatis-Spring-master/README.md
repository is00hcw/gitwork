http://git.oschina.net/free/Mapper/blob/master/wiki/mapper3/7.UseMBG.md



#SSM集成的基础项目，项目使用Maven管理

#MyBatis3.3.0

#Spring[MVC]4.1.2.RELEASE

项目使用Spring4.1.2.RELEASE + SpringMVC4.1.2.RELEASE + Mybatis3.3.0

项目集成了Mybatis分页插件和通用Mapper插件

项目使用的mysql数据库，根据需要可以切换为其他数据库

##Spring Boot集成MyBatis的基础项目

###https://github.com/abel533/MyBatis-Spring-Boot

##MyBatis工具

###http://www.mybatis.tk

##推荐使用Mybatis通用Mapper3

###https://github.com/abel533/Mapper

##推荐使用Mybatis分页插件PageHelper

###https://github.com/pagehelper/Mybatis-PageHelper

##作者信息

- 作者博客：http://blog.csdn.net/isea533

- 作者邮箱：abel533@gmail.com

- Mybatis工具群： 211286137 (Mybatis相关工具插件等等)
