package org.atsmart.charger.web.rest.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import com.alibaba.dubbo.config.annotation.Reference;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.apache.shiro.authz.annotation.RequiresRoles;
import org.atsmart.charger.dataaccess.model.Country;
import org.atsmart.charger.service.api.CountryService;
import org.atsmart.charger.service.dubbo.hello.HelloService;
import org.atsmart.charger.service.dubbo.user.UserRestService;
import org.atsmart.charger.service.dubbo.user.UserService;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.servlet.ModelAndView;

import com.github.pagehelper.PageInfo;


@Controller
public class CountryController {

  @Autowired
  private CountryService countryService;

  private String page_list = "index";

  private String redirect_list = "redirect:list";

  @RequestMapping(value = {"list", "index", "index.html", ""})
  public ModelAndView getList(Country country,
      @RequestParam(required = false, defaultValue = "1") int page,
      @RequestParam(required = false, defaultValue = "10") int rows) {
    ModelAndView result = new ModelAndView(page_list);
    List<Country> countryList = countryService.selectByCountry(country, page, rows);
    result.addObject("pageInfo", new PageInfo<Country>(countryList));
    result.addObject("queryParam", country);
    result.addObject("page", page);
    result.addObject("rows", rows);
    return result;
  }

  @RequestMapping(value = "view", method = RequestMethod.GET)
  public ModelAndView view(Country country) {
    ModelAndView result = new ModelAndView();
    if (country.getId() != null) {
      country = countryService.selectByKey(country.getId());
    }
    result.addObject("country", country);
    return result;
  }

  @RequestMapping(value = "save", method = RequestMethod.POST)
  public ModelAndView save(Country country) {
    ModelAndView result = new ModelAndView(redirect_list);
    if (country.getId() != null) {
      countryService.updateAll(country);
    } else {
      countryService.save(country);
    }
    return result;
  }

  @RequestMapping("delete")
  public String delete(Integer id) {
    countryService.delete(id);
    return redirect_list;
  }

  @RequestMapping("ok")
  public ResponseEntity<Map<String, Object>> ok(Integer id,
      @CookieValue(value = "JSESSIONID", defaultValue = "") String sessionId) {
    System.out.println("---> " + sessionId);
    Country country = countryService.selectByKey(id);
    return ResponseBuilder.data(country).toResponse();
  }

  @RequestMapping("error")
  public ResponseEntity<Country> error(Integer id) throws ServletException {
    // Country country = countryService.selectByKey(id);
    // return new ResponseEntity<Country>( HttpStatus.BAD_REQUEST);
    throw new ForbiddenException("no right");
  }

  @RequestMapping("/hello1")
  public String hello1() {
    System.out.println(SecurityUtils.getSubject().getSession().getId());
    System.out.println(SecurityUtils.getSubject().getPrincipal());
    SecurityUtils.getSubject().checkRole("admin");
    return "success";
  }

  @RequiresRoles("admin")
  @RequestMapping("/hello2")
  public String hello2() {
    return "success";
  }



  @Autowired
  UserRestService restService;

  // @Reference(version="1.0.0" ,group="dev")
//  @Autowired (required = false)
//  UserService userService ;

  @Autowired
  HelloService helloService;

  @RequestMapping("/dubbo")
  public String dubbo(HttpServletRequest req) {
//  System.out.println("user -->" + userService.getUser(1L) );
 //   System.out.println("rest -->" + restService.getUser(1L) );

    System.out.println("rest -->" + restService);
    System.out.println("rest -->" + restService.getUser(1L) );
    System.out.println("hello -->" + helloService);

    // get the ApplicationContext which in web environment
    ApplicationContext ctx = WebApplicationContextUtils.getRequiredWebApplicationContext(req.getServletContext());
    try {
      System.out.println("hello -->" + helloService.hello("saaa"));
      System.out.println("hello -->" + helloService.getClass().getName());
      Class<?>[] faces = helloService.getClass().getInterfaces();
      for(Class clz : faces)
        System.out.println("hello interface -->" + clz.getClass().getName());
      System.out.println("hello -->" + ctx.containsBean("helloService"));
      System.out.println("hello -->" + ctx.getBean("helloService"));
    } catch (BeansException e) {
      System.out.println(e.getMessage());
    }
    return "success";
  }
}
