package org.atsmart.charger.service.impl.dubbo.user;

import org.atsmart.charger.service.dubbo.user.User;
import org.atsmart.charger.service.dubbo.user.UserService;

import java.util.concurrent.atomic.AtomicLong;


public class UserServiceImpl implements UserService {

    private final AtomicLong idGen = new AtomicLong();

    public User getUser(Long id) {
        return new User(id, "username" + id);
    }

//    public Long registerUser(User user) {
////        System.out.println("Username is " + user.getName());
//        return idGen.incrementAndGet();
//    }
}
