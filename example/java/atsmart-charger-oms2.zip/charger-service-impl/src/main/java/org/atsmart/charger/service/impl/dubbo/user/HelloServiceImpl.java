package org.atsmart.charger.service.impl.dubbo.user;

import org.atsmart.charger.service.dubbo.hello.HelloService;

/**
 * Created by Administrator on 2016/4/1.
 */
public class HelloServiceImpl implements HelloService{
    @Override
    public String hello(String name) {
        return "hello " + name;
    }
}
