package me.hao0.trace.core.util;


/**
 * Author: haolin
 * Email:  haolin.h0@gmail.com
 */
public class Times {

    public static long currentMicros(){
        return System.currentTimeMillis() * 1000;
    }
}
