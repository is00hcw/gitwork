#!/usr/bin/env bash
cd trace-demo/user
mvn exec:java -Dexec.mainClass="me.hao0.trace.user.BootStrap"