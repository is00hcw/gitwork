#!/usr/bin/env bash
cd trace-demo/web-api
mvn clean jetty:run -DskipTests