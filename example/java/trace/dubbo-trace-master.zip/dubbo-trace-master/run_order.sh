#!/usr/bin/env bash
cd trace-demo/order
mvn exec:java -Dexec.mainClass="me.hao0.trace.order.BootStrap"