
package com.mousycoder.server.url;


/**
 * <b>function:</b> 公共rest请求地址
 *
 * @author mousycoder
 * @createDate 2015年3月26日 上午9:29:03
 */
public interface RestUrl extends CommodityUrl{
	

}
