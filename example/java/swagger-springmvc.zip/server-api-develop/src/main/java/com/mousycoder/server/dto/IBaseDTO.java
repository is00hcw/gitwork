package com.mousycoder.server.dto;



/**
 * <b>function:</b> 所有DTO的父接口(过滤掉为null的序列化)
 *
 * @author mousycoder
 * @createDate 2015年3月26日 下午1:44:51
 */
public interface IBaseDTO{

}
