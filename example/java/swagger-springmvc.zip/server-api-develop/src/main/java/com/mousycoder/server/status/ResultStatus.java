
package com.mousycoder.server.status;
/**
 * <b>function:</b> 返回状态
 *
 * @author mousycoder
 * @createDate 2015年4月3日 下午2:45:14
 */
public interface ResultStatus {
	
	int FAIL = 0;
	
	int SUCCESS = 1;

}
