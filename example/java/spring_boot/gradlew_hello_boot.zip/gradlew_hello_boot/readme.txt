先执行：
gradlew build
然后执行：
gradlew bootRun
打开URL：
http://localhost:8080/