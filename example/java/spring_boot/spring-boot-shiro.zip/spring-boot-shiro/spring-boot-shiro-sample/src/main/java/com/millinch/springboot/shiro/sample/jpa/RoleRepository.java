package com.millinch.springboot.shiro.sample.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by Chuwei on 2016/12/29.
 */
public interface RoleRepository extends JpaRepository<Role, Long> {
    Role findByName(String name);

//    User findByNameAndAge(String name, Integer age);
//
//    @Query("from User u where u.name=:name")
//    User findUser(@Param("name") String name);
}