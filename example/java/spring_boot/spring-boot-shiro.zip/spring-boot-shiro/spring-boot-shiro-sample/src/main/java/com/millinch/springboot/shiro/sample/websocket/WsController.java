package com.millinch.springboot.shiro.sample.websocket;

import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Controller;

import javax.annotation.Resource;

// http://www.dengshenyu.com/%E5%90%8E%E7%AB%AF%E6%8A%80%E6%9C%AF/2016/05/24/websocket.html
// https://github.com/wiselyman/study/blob/master/Spring/%E7%82%B9%E7%9D%9BSpring%20Boot/06%E7%82%B9%E7%9D%9BSpring%20Boot-WebSocket.md
//Spring支持将STOMP信息路由到@Controller
//
@Controller
public class WsController {
    @Resource
    private SimpMessagingTemplate simpMessagingTemplate;

    @Scheduled(fixedDelay = 20000L)
    @SendTo("/topic/getResponse")
    public void sendPong() {
        simpMessagingTemplate.convertAndSend("/topic/getResponse", "pong (periodic)");
    }

    @MessageMapping("/greeting")
    public void greeting(String value){
        System.out.println("---> greeting: " + value);
        this.simpMessagingTemplate.convertAndSend("/topic/getResponse", value);
    }

    @MessageMapping("/welcome") //前台发送STOMP信息被say方法处理,类似于@RequestMapping
    @SendTo("/topic/getResponse") //返回信息广播到所有订阅了/topic/getResponse的浏览器页面
    public WiselyResponse say(WiselyMessage message) throws Exception {
        Thread.sleep(3000); // 模仿做过一些业务处理
        System.out.println("--> say: " + message);
        return new WiselyResponse("Welcome, " + message.getName() + "!");
    }
}