package com.millinch.springboot.shiro.sample.websocket;

public class WiselyMessage {
    private String name;

    public String getName(){
        return name;
    }
}