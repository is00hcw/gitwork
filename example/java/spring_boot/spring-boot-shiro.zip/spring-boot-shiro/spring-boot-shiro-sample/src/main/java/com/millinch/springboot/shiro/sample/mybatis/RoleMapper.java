package com.millinch.springboot.shiro.sample.mybatis;

import com.millinch.springboot.shiro.sample.jpa.Role;
//import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * http://blog.didispace.com/mybatisinfo/
 * Created by Chuwei on 2016/12/29.
 */
//@Mapper
public interface RoleMapper {
    @Select("SELECT * FROM sys_role WHERE name = #{name}")
    Role findByName(@Param("name") String name);

//    @Insert("INSERT INTO USER(NAME, AGE) VALUES(#{name,jdbcType=VARCHAR}, #{age,jdbcType=INTEGER})")
//    int insertByMap(Map<String, Object> map);

//    @Insert("INSERT INTO USER(NAME, AGE) VALUES(#{name}, #{age})")
//    int insert(@Param("name") String name, @Param("age") Integer age);
}
