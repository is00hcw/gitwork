package com.millinch.springboot.shiro.sample.websocket;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.web.socket.*;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;
import org.springframework.web.socket.handler.TextWebSocketHandler;
import org.springframework.web.socket.server.HandshakeInterceptor;
import org.springframework.web.socket.server.standard.ServletServerContainerFactoryBean;
import org.springframework.web.socket.server.support.HttpSessionHandshakeInterceptor;

import java.io.IOException;
import java.util.Map;

@Configuration
@EnableWebSocket
public class WebSocketConfig implements WebSocketConfigurer {

    @Bean
    public ServletServerContainerFactoryBean createWebSocketContainer() {
        ServletServerContainerFactoryBean container = new ServletServerContainerFactoryBean();
        container.setMaxTextMessageBufferSize(8192);
        container.setMaxBinaryMessageBufferSize(8192);
        return container;
    }

/*
ws = new WebSocket ('ws://localhost:7788/myHandler');
ws.onmessage = function(data){console.log(data)}
ws.send("tttt")
 */
    @Override
    public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
        registry.addHandler(myHandler(), "/myHandler").addInterceptors(myInterceptors()).setAllowedOrigins("*");
        registry.addHandler(myHandler(), "/sockjs/myHandler").addInterceptors(myInterceptors()).withSockJS();  //http://host:port/myApp/myEndpoint/{server-id}/{session-id}/{transport}
    }

    @Bean
    public HandshakeInterceptor myInterceptors() {
        return new MyHandshakeInterceptor();
    }

    class MyHandshakeInterceptor extends HttpSessionHandshakeInterceptor {

        @Override
        public boolean beforeHandshake(ServerHttpRequest request,
                                       ServerHttpResponse response, WebSocketHandler wsHandler,
                                       Map<String, Object> attributes) throws Exception {
            System.out.println("GOMA ===> Before Handshake");
            return super.beforeHandshake(request, response, wsHandler, attributes);
        }

        @Override
        public void afterHandshake(ServerHttpRequest request,
                                   ServerHttpResponse response, WebSocketHandler wsHandler,
                                   Exception ex) {
            System.out.println("GOMA ===> After Handshake");
            super.afterHandshake(request, response, wsHandler, ex);
        }
    }


    @Bean
    public WebSocketHandler myHandler() {
        return new MyHandler();
    }

    class MyHandler extends TextWebSocketHandler {

        @Override
        public void handleTextMessage(WebSocketSession session, TextMessage message) {
            // ...
            System.out.println("input: " + message);
            try {
                session.sendMessage(new TextMessage("Hello " + message.getPayload() + " !"));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    class MessageWebSocketHandler implements WebSocketHandler {
        @Override
        public void afterConnectionEstablished(WebSocketSession session) {
        }

        @Override
        public void handleMessage(WebSocketSession session, WebSocketMessage<?> message) throws Exception {

        }

        @Override
        public void handleTransportError(WebSocketSession session, Throwable exception) {
        }


        @Override
        public void afterConnectionClosed(WebSocketSession session, CloseStatus closeStatus) {
        }

        @Override
        public boolean supportsPartialMessages() {
            return false;
        }
    }

    class MessageWebSocketInterceptor implements HandshakeInterceptor {
        @Override
        public boolean beforeHandshake(ServerHttpRequest request, ServerHttpResponse response, WebSocketHandler wsHandler, Map<String, Object> attributes) throws Exception {
            if (request instanceof ServletServerHttpRequest) {
                ServletServerHttpRequest servletRequest = (ServletServerHttpRequest) request;
                String siteId = servletRequest.getServletRequest().getParameter("siteId");
                String userId = servletRequest.getServletRequest().getParameter("userId");
                if (siteId == null || userId == null) {
                    return false;
                }
                attributes.put("siteId", siteId);
                attributes.put("userId", userId);
            }
            return true;
        }
        @Override
        public void afterHandshake(ServerHttpRequest request, ServerHttpResponse response, WebSocketHandler wsHandler, Exception exception) {
        }
    }

}