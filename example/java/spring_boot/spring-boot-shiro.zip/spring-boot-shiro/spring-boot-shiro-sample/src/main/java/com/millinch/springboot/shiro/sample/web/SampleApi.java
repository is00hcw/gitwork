package com.millinch.springboot.shiro.sample.web;

import com.github.pagehelper.PageHelper;
import com.millinch.api.admin.entity.SysRole;
import com.millinch.api.admin.entity.SysRoleExample;
import com.millinch.service.admin.dal.mapper.SysRoleMapper;
import com.millinch.spring.boot.autoconfigure.shiro.annotation.SessionUser;
import com.millinch.springboot.shiro.sample.jpa.Role;
import com.millinch.springboot.shiro.sample.jpa.RoleRepository;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * This guy is lazy, nothing left.
 *
 * @author John Zhang
 */
@RestController
public class SampleApi {

    @Autowired(required = false)
//    private RedisTemplate<String, Object> redisTemplate;
    private StringRedisTemplate redisTemplate;

    @Autowired
    private RoleRepository roleRepository;

//    @Autowired
//    private RoleMapper roleMapper;  // mybatis-starter
    @Autowired
    private SysRoleMapper sysRoleMapper;

    @RequestMapping(value = "/jpa", method = RequestMethod.GET)
    @ResponseBody
    public String testJpa() {
        List<Role> roles = roleRepository.findAll();
        System.out.println(roles.size());
        return "jpa";
    }

    @RequestMapping(value = "/redis", method = RequestMethod.GET)
    @ResponseBody
    public String testRedis() {
        System.out.println("redisTemplate: " +redisTemplate);
        redisTemplate.opsForValue().set("aa","bb");
        System.out.println(redisTemplate.opsForValue().get("aa"));
        return "redis";
    }

    @RequestMapping(value = "/mybatis", method = RequestMethod.GET)
    @ResponseBody
    public String testMybatis() {
//        Role u = roleMapper.findByName("aaa");
//        System.out.println(u);
        PageHelper.startPage(1,2);
        List<SysRole> list = sysRoleMapper.selectByExample(new SysRoleExample());
        System.out.println(list);
        return "mybatis";
    }

    @RequestMapping(value = "/json_login", method = RequestMethod.POST, produces = "application/json; charset=UTF-8")
    public ApiResult<String> jsLogin() {

//        System.out.println("---> body: " + body);
        Subject subject = SecurityUtils.getSubject();
//        subject.login(new UsernamePasswordToken("admin","123456"));
        Session session = subject.getSession(false);
        if(session != null){
            Long loginTime = (Long) session.getAttribute("login_time" );
            System.out.println("---> session: " + loginTime);
        }

        ApiResult<String> res = new ApiResult<>();
        res.setSummary("summary");
        res.setCode("OK");
        res.setResult("abce");
        return res;
    }

    @RequestMapping("/role/config")
    public ResponseEntity roleConfig() {
        return ResponseEntity.ok("Here you are");
    }

    @RequestMapping("/user/addition")
 //   @RequiresPermissions("system:admin:create")
    public ResponseEntity userAddition(@SessionUser Object user) {
        System.out.println("@SessionUser:" + user);
        Subject subject = SecurityUtils.getSubject();
        boolean permitted = subject.isPermitted("system:admin:create");
        System.out.println("permitted = " + permitted);
        return ResponseEntity.ok("Here you are");
    }
}
