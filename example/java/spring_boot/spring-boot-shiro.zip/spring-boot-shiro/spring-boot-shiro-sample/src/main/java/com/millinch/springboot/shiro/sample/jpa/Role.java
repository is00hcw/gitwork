package com.millinch.springboot.shiro.sample.jpa;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * Created by Chuwei on 2016/12/29.
 */
@Entity(name="sys_role")
@Data
public class Role {
    @Id
    private Long id;

    @Column(nullable = false)
    private String name;
}
