package com.millinch.springboot.shiro.sample;

import com.millinch.springboot.shiro.sample.jpa.Role;
import com.millinch.springboot.shiro.sample.mybatis.RoleMapper;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by Chuwei on 2016/12/29.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = Bootstrap.class)
@Transactional
public class RoleMapperTest {
    @Autowired
    private RoleMapper roleMapper;

    @Test
//    @Rollback
    public void findByName() throws Exception {
        Role u = roleMapper.findByName("aaa");
        System.out.println(u);
        Assert.assertNotNull(u);
    }

}