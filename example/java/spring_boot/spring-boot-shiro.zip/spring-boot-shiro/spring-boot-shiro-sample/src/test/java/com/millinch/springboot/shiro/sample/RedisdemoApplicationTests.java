package com.millinch.springboot.shiro.sample;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import static org.junit.Assert.assertEquals;

// https://segmentfault.com/a/1190000004389938
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = Bootstrap.class)
@WebAppConfiguration
public class RedisdemoApplicationTests {

    @Autowired
    private StringRedisTemplate template;

//    @Autowired
//    private DemoService demoService;

    @Test
    public void set(){
        String key = "test-add";
        String value = "hello";
        template.opsForValue().set(key,value);
        assertEquals(value,template.opsForValue().get(key));
    }

    @Test
    public void incr(){
        String key = "test-incr";
        template.opsForValue().increment(key, 1);
        assertEquals(template.opsForValue().get(key),"1");
    }


}