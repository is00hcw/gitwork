package cc.lcsmart.common.mbg;

/**
 * @author wsp
 * @Description
 * @date 16/7/14 18:04
 * @company 深圳百乐润投资有限公司/深圳亿起融网络科技有限公司
 */
public class MapMode {
    private String id;
    private String className;
    private String daoName;
    private String reqName;
    private String entityName;
    private String fullName;
    private String pkg;
    private String path;
    private String mapFile;
    private String daoFile;
    private String tableName;

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getEntityName() {
        return entityName;
    }

    public void setEntityName(String entityName) {
        this.entityName = entityName;
    }

    public String getDaoFile() {
        return daoFile;
    }

    public void setDaoFile(String daoFile) {
        this.daoFile = daoFile;
    }

    public String getPkg() {
        return pkg;
    }

    public void setPkg(String pkg) {
        this.pkg = pkg;
    }

    public String getMapFile() {
        return mapFile;
    }

    public void setMapFile(String mapFile) {
        this.mapFile = mapFile;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getDaoName() {
        return daoName;
    }

    public void setDaoName(String daoName) {
        this.daoName = daoName;
    }

    public String getReqName() {
        return reqName;
    }

    public void setReqName(String reqName) {
        this.reqName = reqName;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
}
