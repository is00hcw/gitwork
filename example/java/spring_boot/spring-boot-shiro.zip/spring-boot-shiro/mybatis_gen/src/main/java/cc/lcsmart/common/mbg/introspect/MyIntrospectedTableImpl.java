package cc.lcsmart.common.mbg.introspect;

import org.mybatis.generator.codegen.mybatis3.IntrospectedTableMyBatis3Impl;

/**
 * Created by Administrator on 2016/7/25.
 */
public class MyIntrospectedTableImpl extends IntrospectedTableMyBatis3Impl {

    @Override
    public String getMyBatis3SqlMapNamespace() {
        String namespace = this.getMyBatis3JavaMapperType();
        if(namespace == null) {
            namespace = this.getMyBatis3FallbackSqlMapNamespace();
        }

        namespace += "Ext";
        return namespace;
    }
}
