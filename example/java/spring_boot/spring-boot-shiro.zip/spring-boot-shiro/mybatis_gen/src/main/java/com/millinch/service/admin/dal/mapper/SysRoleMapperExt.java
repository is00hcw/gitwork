package com.millinch.service.admin.dal.mapper;

import javax.annotation.Resource;

@Resource
public interface SysRoleMapperExt extends SysRoleMapper {
}