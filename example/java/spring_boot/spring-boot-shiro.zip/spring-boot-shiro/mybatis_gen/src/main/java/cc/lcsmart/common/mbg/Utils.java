package cc.lcsmart.common.mbg;

import java.io.File;

public class Utils {
    public static final String getId(String className) {
        return className.substring(0, 1).toLowerCase() + className.substring(1);
    }

    public static final String getIdByPackage(String pkg) {
        return getId(getClassName(pkg));
    }

    public static final String getClassName(String pkg) {
        return pkg.substring(pkg.lastIndexOf("."));
    }

    public static void main(String[] args) {
        System.out.printf(getClassName("cn.pelerin.auth.api.CustBll"), new Object[0]);
    }

    public static boolean isExists(String name){
        String bn = System.getProperty("user.dir");
        String n =  bn+File.separator+name;
        System.out.println(n);
        File f = new File(n);
        return f.exists();
    }


}