package cc.lcsmart.common.mbg;

import org.mybatis.generator.api.GeneratedXmlFile;
import org.mybatis.generator.api.IntrospectedTable;
import org.mybatis.generator.api.PluginAdapter;

import java.util.ArrayList;
import java.util.List;

import static org.mybatis.generator.internal.util.StringUtility.stringHasValue;
import static org.mybatis.generator.internal.util.messages.Messages.getString;

/**
 * @author wsp
 * @Description
 * @date 16/7/7 19:34
 * @company 深圳百乐润投资有限公司/深圳亿起融网络科技有限公司
 */
public class BasePlugin extends PluginAdapter {

    protected List<MapMode> items = new ArrayList<>();

    public boolean validate(List<String> warnings) {
        boolean valid = true;
        //stringHasValue方法是通过静态引入工具类org.mybatis.generator.internal.util.StringUtility的；
        //该方法用于判断传入的参数中是否含有targetProject这个参数；
        //这里要注意两个点，第一，我们在扩展或者使用别人的框架的时候，比如stringHasValue这种方法，我们完全可以自己写一个hasLength方法，
        //但是，使用框架中已经存在的API来完成这些功能，是一个扩展框架的一个良好的实践，这可以保证框架在API级别的一致性；
        //第二，properties属性是Plugin在创建的时候，通过setProperties方法传入的，是一个Properties类型数据；
        if (!stringHasValue(properties
                .getProperty("targetProject"))) { //$NON-NLS-1$
            //如果没有传入必填的参数，就把警告信息添加到传入的warnings列表中，该列表的内容会在MBG运行过程中统一日志；
            //这里需要注意的是getString方法，该方法是通过静态引入org.mybatis.generator.internal.util.messages.Messages
            //这个Messages类是MBG对国际化消息的一个封装，在后面扩展时候会讲到MBG的代码结构；
            warnings.add(getString("ValidationError.18", //$NON-NLS-1$
                    "MapperConfigPlugin", //$NON-NLS-1$
                    "targetProject")); //$NON-NLS-1$
            valid = false;
        }
        //同理，判断是否传入了targetPackage参数
        if (!stringHasValue(properties
                .getProperty("targetPackage"))) { //$NON-NLS-1$
            warnings.add(getString("ValidationError.18", //$NON-NLS-1$
                    "MapperConfigPlugin", //$NON-NLS-1$
                    "targetPackage")); //$NON-NLS-1$
            valid = false;
        }
        return valid;
    }



    /**
     * sqlMapGenerated方法，是在本次context中，生成每一个（注意是每一个）mapper.xml文件之后都会回调的方法；
     * 第一个参数GeneratedXmlFile即本次生成的mapper.xml文件对应的XML文件封装对象；
     */
    @Override
    public boolean sqlMapGenerated(GeneratedXmlFile sqlMap,
                                   IntrospectedTable introspectedTable) {
        MapMode mm = new MapMode();
        String fn = sqlMap.getFileName();
        String tn = introspectedTable.getFullyQualifiedTableNameAtRuntime();
        mm.setTableName(tn);
        //System.out.println("---" + sqlMap.getFileName());
        String cn = fn.replace(".xml","");
        String id = cn.substring(0,1).toLowerCase() + cn.substring(1);
        String fullName = sqlMap.getTargetPackage();
        String path = fullName.replace(".","/");
        mm.setClassName(cn);
        mm.setId(id);
        mm.setPkg(sqlMap.getTargetPackage());
        mm.setPath(path+"/");
        mm.setMapFile(path + "/" + cn + ".xml");
        mm.setMapFile(path + "/" + cn + ".java");
        mm.setFullName(fullName);
        String mn = cn.replaceAll("Mapper","");
        mm.setReqName(mn+"Req");
        mm.setEntityName(mn);
        mm.setDaoName(cn);
        //添加一个.然后把所有的.替换成/，就变成了mapper.xml文件的目录（原来并没有方法直接得到，还是要自己通过package去替换）
        //接着拼上xml文件的文件名（还记得文件名是包含了后缀的吧），就创建好了这个mapper.xml文件的路径了
        //再添加到mapperFiles中
        items.add(mm);
        return true;
    }
}
