package cc.lcsmart.common.mbg;

import org.mybatis.generator.api.GeneratedXmlFile;
import org.mybatis.generator.api.dom.xml.Attribute;
import org.mybatis.generator.api.dom.xml.Document;
import org.mybatis.generator.api.dom.xml.TextElement;
import org.mybatis.generator.api.dom.xml.XmlElement;

import java.util.ArrayList;
import java.util.List;

public class DaoConfigPlugin extends BasePlugin {

    public List<GeneratedXmlFile> contextGenerateAdditionalXmlFiles() {
        Document document = new Document();

        /**
         <beans xmlns="http://www.springframework.org/schema/beans"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans-3.0.xsd">
         */
        XmlElement root = new XmlElement("beans");
        root.addAttribute(new Attribute("xmlns","http://www.springframework.org/schema/beans"));
        root.addAttribute(new Attribute("xmlns:xsi","http://www.w3.org/2001/XMLSchema-instance"));
        root.addAttribute(new Attribute("xsi:schemaLocation","http://www.springframework.org/schema/beans http://www.springframework.org/schema/beans/spring-beans-3.0.xsd"));
        document.setRootElement(root);

        /**
         *
         <bean id="custPersonInfoMapper" class="org.mybatis.spring.mapper.MapperFactoryBean">
         <property name="mapperInterface" value="cn.pelerin.auth.app.cust.mapper.CustPersonInfoMapper"></property>
         <property name="sqlSessionFactory" ref="session_auth"></property>
         </bean>
         */
        //准备根据搜集到的本次生成的mapper.xml文件，为mappers生成mapper子元素
        XmlElement mapper;
        //为每一个mapper.xml文件生成一个对应的mapper子元素；从这里就可以明确的看出，在mapperFiles集合中保存的确实是mapper.xml文件的路径；
        for (MapMode mm : items) {
            String name = mm.getClassName();
            String pkg = mm.getFullName();

            //创建mappers节点；
            XmlElement bean = new XmlElement("bean");

            bean.addAttribute(new Attribute("id",name));
            bean.addAttribute(new Attribute("class","org.mybatis.spring.mapper.MapperFactoryBean"));

            XmlElement bp = new XmlElement("property");
            bp.addAttribute(new Attribute("name","mapperInterface"));
            bp.addAttribute(new Attribute("value",pkg));

            XmlElement bp1 = new XmlElement("property");
            bp1.addAttribute(new Attribute("name","sqlSessionFactory"));
            bp1.addAttribute(new Attribute("ref",properties.getProperty("sqlSession")));

            bean.addElement(bp);
            bean.addElement(bp1);
            root.addElement(new TextElement(""));
            root.addElement(bean);
        }

        //信息量非常大的一句代码，通过这句代码可以看出：
        //1，MBG使用GeneratedXmlFile对象来包装一个要生成的XML文件的所有相关内容；
        //2，该对象的构造方法包含了所有需要的信息
        //3，第一个参数，是该XML文件的内容，即Document；
        //4，第二个参数，是该XML文件的文件名，可以很清楚的看到，先得到fileName参数，否则使用默认的MapperConfig.xml命名（所以，后缀名是要自己传给MBG的）
        //5，第三个参数和第四个参数，分别是生成XML文件的targetPackage和targetProject；所以，可以看到MBG把文件的具体生成过程完全包装，只需要我们提供package和project即可；
        //6，第四个参数代表是否合并，
        //7，最后一个参数是提供一个XML文件格式化工具，直接使用上下文的xmlFormatter即可（这个是可以在<context>元素中配置的哦~~）
        GeneratedXmlFile gxf = new GeneratedXmlFile(document, properties
                .getProperty("fileName", "dao.xml"), //$NON-NLS-1$ //$NON-NLS-2$
                properties.getProperty("targetPackage"), //$NON-NLS-1$
                properties.getProperty("targetProject"), //$NON-NLS-1$
                false, context.getXmlFormatter());

        //最后返回要生成的这个文件，交给MBG去生成；
        List<GeneratedXmlFile> answer = new ArrayList<GeneratedXmlFile>(1);
        answer.add(gxf);

        return answer;
    }

}

