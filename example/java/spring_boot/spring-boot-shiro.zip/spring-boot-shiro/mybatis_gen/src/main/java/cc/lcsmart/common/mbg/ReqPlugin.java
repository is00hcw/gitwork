package cc.lcsmart.common.mbg;

import org.mybatis.generator.api.GeneratedJavaFile;
import org.mybatis.generator.api.dom.java.JavaVisibility;
import org.mybatis.generator.api.dom.java.TopLevelClass;

import java.util.ArrayList;
import java.util.List;

/**
 * @author wsp
 * @Description
 * @date 16/7/14 18:04
 * @company 深圳百乐润投资有限公司/深圳亿起融网络科技有限公司
 */
public class ReqPlugin extends BasePlugin{


    public List<GeneratedJavaFile> contextGenerateAdditionalJavaFiles() {

        //最后返回要生成的这个文件，交给MBG去生成；
        List<GeneratedJavaFile> answer = new ArrayList();

        String pkg = properties.getProperty("targetPackage");
        String entityPackage = properties.getProperty("entityPackage");
        String importPackage = properties.getProperty("importPackage");
        String [] imports = null;
        if(importPackage!=null && !"".equals(importPackage)) {
            imports = importPackage.split(",");
        }

        for(MapMode mm:items){
            TopLevelClass tc = new TopLevelClass(pkg + "." + mm.getReqName());
            tc.addImportedType(entityPackage + "." + mm.getEntityName());
            tc.setSuperClass(mm.getEntityName());

            if(imports!=null){
                for(int i=0;i<imports.length;i++){
                    tc.addImportedType(imports[i]);
                }
            }

            tc.setVisibility(JavaVisibility.PUBLIC);

            //GeneratedXmlFile gxf = new GeneratedXmlFile(document, properties
            GeneratedJavaFile jf = new GeneratedJavaFile(tc,
                    properties.getProperty("targetProject"), //$NON-NLS-1$
                    context.getJavaFormatter());

            answer.add(jf);
        }

        return answer;
    }
}
