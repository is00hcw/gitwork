package cc.lcsmart.common.mbg;

import org.mybatis.generator.api.GeneratedJavaFile;
import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
import org.mybatis.generator.api.dom.java.Interface;
import org.mybatis.generator.api.dom.java.JavaVisibility;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * @author wsp
 * @Description
 * @date 16/7/19 16:34
 * @company 深圳百乐润投资有限公司/深圳亿起融网络科技有限公司
 */
public class MapperExtPlug extends BasePlugin {
    public List<GeneratedJavaFile> contextGenerateAdditionalJavaFiles() {

        //最后返回要生成的这个文件，交给MBG去生成；
        List<GeneratedJavaFile> answer = new ArrayList();

        for(MapMode mm:items){


            String fn  = mm.getDaoName() + "Ext.java";
            String pfn = properties.getProperty("targetProject") + File.separator + mm.getPath() + fn;
            if(Utils.isExists(pfn)){
                continue;
            }


            Interface face = new Interface(mm.getPkg() + "." + mm.getDaoName() + "Ext");
            //face.addImportedType(mm.getFullName());
            face.addSuperInterface(new FullyQualifiedJavaType(mm.getPkg() + "." + mm.getDaoName()));
            face.setVisibility(JavaVisibility.PUBLIC);
            face.addAnnotation("@Resource");
            face.addImportedType(new FullyQualifiedJavaType("javax.annotation.Resource"));

            //GeneratedXmlFile gxf = new GeneratedXmlFile(document, properties
            GeneratedJavaFile jf = new GeneratedJavaFile(face,
                    properties.getProperty("targetProject"), //$NON-NLS-1$
                    context.getJavaFormatter());

            answer.add(jf);
        }

        return answer;
    }
}
