package com.millinch.api.admin.req;

import com.millinch.api.admin.entity.SysRole;

public class SysRoleReq extends SysRole {
}