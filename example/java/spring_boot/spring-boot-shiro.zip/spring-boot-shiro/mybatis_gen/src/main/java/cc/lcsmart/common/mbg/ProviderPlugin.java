package cc.lcsmart.common.mbg;

import org.mybatis.generator.api.GeneratedJavaFile;
import org.mybatis.generator.api.dom.java.JavaVisibility;
import org.mybatis.generator.api.dom.java.TopLevelClass;

import java.util.ArrayList;
import java.util.List;

/**
 * @author wsp
 * @Description
 * @date 16/7/7 19:31
 * @company 深圳百乐润投资有限公司/深圳亿起融网络科技有限公司
 */
public class ProviderPlugin extends BasePlugin {
    public List<GeneratedJavaFile> contextGenerateAdditionalJavaFiles() {

        //最后返回要生成的这个文件，交给MBG去生成；
        List<GeneratedJavaFile> answer = new ArrayList();

        for (MapMode mm : items) {
            TopLevelClass tc = new TopLevelClass(mm.getPkg() + "." + mm.getReqName());
            tc.addImportedType(mm.getFullName());
            tc.setSuperClass(mm.getClassName());
            tc.setVisibility(JavaVisibility.PUBLIC);

            //GeneratedXmlFile gxf = new GeneratedXmlFile(document, properties
            GeneratedJavaFile jf = new GeneratedJavaFile(tc,
                    properties.getProperty("targetProject"), //$NON-NLS-1$
                    context.getJavaFormatter());

            answer.add(jf);
        }

        return answer;
    }
}
