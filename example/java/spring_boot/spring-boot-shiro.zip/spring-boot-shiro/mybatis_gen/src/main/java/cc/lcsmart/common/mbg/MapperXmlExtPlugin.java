package cc.lcsmart.common.mbg;

import org.mybatis.generator.api.GeneratedXmlFile;
import org.mybatis.generator.api.dom.xml.Attribute;
import org.mybatis.generator.api.dom.xml.Document;
import org.mybatis.generator.api.dom.xml.XmlElement;
import org.mybatis.generator.codegen.XmlConstants;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MapperXmlExtPlugin extends BasePlugin {

    public List<GeneratedXmlFile> contextGenerateAdditionalXmlFiles() {
        //最后返回要生成的这个文件，交给MBG去生成；
        List<GeneratedXmlFile> answer = new ArrayList();

        for (MapMode mm : items) {
             String daoExt =  mm.getPkg()+ "." + mm.getDaoName()+"Ext";
             String fn  = mm.getDaoName() + "Ext.xml";
             String pfn = properties.getProperty("targetProject") + File.separator + mm.getPath() + fn;
             if(Utils.isExists(pfn)){
                 continue;
             }

            /**
             * < ?xml version="1.0" encoding="UTF-8" ?>
             < !DOCTYPE mapper PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN" "http://mybatis.org/dtd/mybatis-3-mapper.dtd" >
             <mapper namespace="com.alibaba.happytrip.dal.hotel.mapper.HotelDoMapperExt" >
             */
            Document document = new Document(
                    XmlConstants.MYBATIS3_MAPPER_PUBLIC_ID,
                    XmlConstants.MYBATIS3_MAPPER_SYSTEM_ID);

            /**
             <mapper namespace="com.alibaba.happytrip.dal.hotel.mapper.HotelDoMapperExt" >
             */
            XmlElement root = new XmlElement("mapper");
            root.addAttribute(new Attribute("namespace", daoExt));
            //root.addElement(new TextElement("<!--   ....   -->")); //$NON-NLS-1$
            document.setRootElement(root);

            GeneratedXmlFile gxf = new GeneratedXmlFile(document,
                    fn,
                    properties.getProperty("targetPackage"), //$NON-NLS-1$
                    properties.getProperty("targetProject"), //$NON-NLS-1$
                    false, context.getXmlFormatter());


            answer.add(gxf);
        }
        return answer;

    }
}

