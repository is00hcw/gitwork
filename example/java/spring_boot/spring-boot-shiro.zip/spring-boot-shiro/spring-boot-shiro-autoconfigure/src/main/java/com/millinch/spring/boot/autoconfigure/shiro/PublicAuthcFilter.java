package com.millinch.spring.boot.autoconfigure.shiro;


import com.millinch.spring.boot.autoconfigure.shiro.stateless.BaseAuthcFilter;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * Created by Chuwei on 2016/10/19.
 * 类似匿名访问,但是回继承父类的方法处理请求参数
 */
public class PublicAuthcFilter extends BaseAuthcFilter {
    @Override
    protected boolean isAccessAllowed(ServletRequest request, ServletResponse response, Object mappedValue) throws Exception {
        return true;
    }

    @Override
    protected boolean onAccessDenied(ServletRequest request, ServletResponse response) throws Exception {
        return true;
    }
}
