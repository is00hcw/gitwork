package com.millinch.spring.boot.autoconfigure.shiro.stateless;


public class Constants {
    public static final String PAY_HEADER = "LC-PAY";  //  支付方式
    public static final String USE_PAY_PASS = "1";  //  使用支付密码
    public static final String TOKEN_HEADER = "LC-TOKEN";  // 访问api的令牌
    public static final String SIGN_HEADER = "LC-SIGN";  // 签名
    public static final String SESSION_HEADER = "LC-SID";  // 会话id
    public static final String API_PREFIX = "/api/v1";

}
