package com.millinch.spring.boot.autoconfigure.shiro.stateless;

import com.alibaba.fastjson.JSON;
import com.millinch.spring.boot.autoconfigure.shiro.core.BaseResp;
import com.millinch.spring.boot.autoconfigure.shiro.core.ResultCode;
import org.apache.shiro.web.filter.AccessControlFilter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Created by Chuwei on 2016/8/30.
 */
public abstract class BaseAuthcFilter extends AccessControlFilter {
    private final static Logger LOG = LoggerFactory.getLogger(BaseAuthcFilter.class);
    static final boolean devMode = true;


    /**
     * 获取Ip地址，先取X-Forwarded-For地址，如果为空， <br>
     * 取Proxy-Client-IP，如果为空，再取<br>
     * WL-Proxy-Client-IP，如果为空，再取request.getRemoteAddr() <br>
     * 注意：如果以上任何一种方式获取到的ip中有, 逗号分隔出的多个IP地址，则取第一个合法的IP地址（非unknown的地址)
     *
     * @param request
     * @return
     */
    public static String getIpAddr(HttpServletRequest request) {
        String ip = request.getHeader("X-Forwarded-For");
        if (ip == null || "".equals(ip) || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || "".equals(ip) || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || "".equals(ip) || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        if (ip != null && !"".equals(ip)) {
            String[] ips = ip.split(",");
            for (int i = 0; i < ips.length; i++) {
                if (ips[i] != null && !"".equals(ips[i])
                        && !"unknown".equalsIgnoreCase(ips[i])) {
                    ip = ips[i];
                    break;
                }

            }
        }
        return ip;
    }

    protected void writeErrorResponse(HttpServletResponse httpResp, ResultCode code) {
        BaseResp resp = new BaseResp();
        resp.setCode(code);
        try {
            httpResp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            httpResp.setContentType("application/json;charset=UTF-8");
            httpResp.setHeader("Cache-Control", "no-store");
            httpResp.setHeader("Pragrma", "no-cache");
            httpResp.setDateHeader("Expires", 0);
            httpResp.getWriter().println(JSON.toJSONString(resp));
            httpResp.flushBuffer();
        } catch (IOException e) {
            LOG.error("cmd=TokenAuthcFilter:writeResponse_err | msg:{}", e.getMessage());
        }
    }

    @Override
    protected boolean preHandle(ServletRequest request, ServletResponse response) throws Exception {

        return super.preHandle(request, response);
    }

    @Override
    public void afterCompletion(ServletRequest request, ServletResponse response, Exception exception) throws Exception {

    }


}
