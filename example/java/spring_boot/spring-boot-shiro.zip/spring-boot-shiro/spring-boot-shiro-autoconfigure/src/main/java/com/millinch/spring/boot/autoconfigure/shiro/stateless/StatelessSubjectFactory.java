package com.millinch.spring.boot.autoconfigure.shiro.stateless;
import org.apache.shiro.subject.Subject;
import org.apache.shiro.subject.SubjectContext;
import org.apache.shiro.web.mgt.DefaultWebSubjectFactory;
import org.apache.shiro.web.subject.WebSubjectContext;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import java.io.Serializable;

/**
 * <p>User: Zhang Kaitao
 * <p>Date: 14-2-26
 * <p>Version: 1.0
 */
public class StatelessSubjectFactory extends DefaultWebSubjectFactory {

    public static final String STATELESS_PATH = "/api/";

    @Override
    public Subject createSubject(SubjectContext context) {
        if (!(context instanceof WebSubjectContext)) {
            return super.createSubject(context);
        }

        if(isStatelessPath((WebSubjectContext) context)) {
            context.setSessionCreationEnabled(false);   //不创建session
//            System.out.println("---> setSessionCreationEnabled(false)");
        }

        Subject subject = super.createSubject(context);
        Serializable sessionId = context.getSessionId();
//        System.out.println("----> after createSubject: " + sessionId);
        System.out.println("subject principal : " + subject.getPrincipal());

        return subject;
    }

    protected boolean isStatelessPath(WebSubjectContext wsc) {
        ServletRequest request = wsc.resolveServletRequest();
        if(request instanceof HttpServletRequest){
            HttpServletRequest httpReq = (HttpServletRequest) request;
            String uri = httpReq.getRequestURI();
            if(uri != null && uri.indexOf(STATELESS_PATH) > -1){
                return true;
            }
        }
        return false;
    }
}
