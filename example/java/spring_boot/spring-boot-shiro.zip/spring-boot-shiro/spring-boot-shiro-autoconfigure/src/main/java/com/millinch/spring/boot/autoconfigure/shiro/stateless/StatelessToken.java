package com.millinch.spring.boot.autoconfigure.shiro.stateless;

import org.apache.shiro.authc.AuthenticationToken;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

/**
 * <p>User: Zhang Kaitao
 * <p>Date: 14-2-26
 * <p>Version: 1.0
 */
public class StatelessToken implements AuthenticationToken {

    private final String method;
    private final String path;
    private final String body;
    private final HttpServletRequest httpReq;
    private String sessionId;
    private Map<String, String[]> params;
    private String clientDigest;
    private boolean isPay;

    public StatelessToken(HttpServletRequest httpReq, String sessionId, String method, String path, Map<String, String[]> params, String body, String clientDigest) {
        this.method = method;
        this.path = path;
        this.sessionId = sessionId;
        this.params = params;
        this.body = body;
        this.clientDigest = clientDigest;
        this.isPay = false;
        this.httpReq = httpReq;
    }

    public HttpServletRequest getHttpReq() {
        return httpReq;
    }

    public boolean isPay() {
        return isPay;
    }

    public void setPay(boolean pay) {
        isPay = pay;
    }

    public String getMethod() {
        return method;
    }

    public String getPath() {
        return path;
    }

    public String getSessionId() {
        return sessionId;
    }

    public  Map<String,String[]> getParams() {
        return params;
    }

    public void setParams( Map<String, String[]> params) {
        this.params = params;
    }

    public String getClientDigest() {
        return clientDigest;
    }

    public void setClientDigest(String clientDigest) {
        this.clientDigest = clientDigest;
    }

    @Override
    public Object getPrincipal() {
       return sessionId;
    }

    @Override
    public Object getCredentials() {
        return clientDigest;
    }

    public String getBody() {
        return body;
    }

}
