package com.millinch.spring.boot.autoconfigure.shiro;

import org.apache.shiro.ShiroException;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.pam.ModularRealmAuthenticator;
import org.apache.shiro.realm.Realm;
import org.apache.shiro.util.CollectionUtils;

import java.util.Collection;
import java.util.Map;

public class DefaultModularRealm extends ModularRealmAuthenticator {
    private Map<String, Object> realmsMap;
  
    /** 
     * 多个realm实现 
     */  
    @Override  
    protected AuthenticationInfo doMultiRealmAuthentication(
            Collection<Realm> realms, AuthenticationToken token) {
        return super.doMultiRealmAuthentication(realms, token);  
    }  
  
    /** 
     * 调用单个realm执行操作 
     */  
    @Override  
    protected AuthenticationInfo doSingleRealmAuthentication(Realm realm,  
            AuthenticationToken token) {  
  
        // 如果该realms不支持(不能验证)当前token  
        if (!realm.supports(token)) {  
            throw new ShiroException("不支持token类型:" + token.getClass().getName() );
        }  
        AuthenticationInfo info = null;  
        try {  
            info = realm.getAuthenticationInfo(token);  
  
            if (info == null) {  
                throw new ShiroException("token不存在!");  
            }  
        } catch (Throwable e) {
            e.printStackTrace();
            throw new ShiroException("用户名或者密码错误!");  
        }  
        return info;  
    }  
  
    /** 
     * 判断登录类型执行操作 
     */  
    @Override  
    protected AuthenticationInfo doAuthenticate(  
            AuthenticationToken authenticationToken)  
            throws AuthenticationException {
        this.assertRealmsConfigured();  
  
        Realm realm = null;
        String simpleName = authenticationToken.getClass().getSimpleName();
        realm = (Realm) realmsMap.get(simpleName);
        System.out.println("---> doAuthenticate : " + simpleName + "  realm: " + realm);
        if (realm == null) {  
            return null;  
        }  
  
        return this.doSingleRealmAuthentication(realm, authenticationToken);  
    }  
  
    /** 
     * 判断realm是否为空 
     */  
    @Override  
    protected void assertRealmsConfigured() throws IllegalStateException {
        if (CollectionUtils.isEmpty(this.realmsMap)) {
            throw new ShiroException("初始化错误, realmsMap为空!");
        }  
    }

    public Map<String, Object> getRealmsMap() {
        return realmsMap;
    }

    public void setRealmsMap(Map<String, Object> realmsMap) {
        this.realmsMap = realmsMap;
    }
}