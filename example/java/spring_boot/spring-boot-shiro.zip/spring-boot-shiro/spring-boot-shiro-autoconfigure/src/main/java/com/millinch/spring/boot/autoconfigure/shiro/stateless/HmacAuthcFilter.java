package com.millinch.spring.boot.autoconfigure.shiro.stateless;


import com.alibaba.fastjson.JSON;
import com.millinch.spring.boot.autoconfigure.shiro.ShiroUtil;
import com.millinch.spring.boot.autoconfigure.shiro.core.BaseResp;
import com.millinch.spring.boot.autoconfigure.shiro.core.ResultCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 */
public class HmacAuthcFilter extends BaseAuthcFilter {
    private final static Logger LOG = LoggerFactory.getLogger(HmacAuthcFilter.class);

    @Override
    protected boolean isAccessAllowed(ServletRequest request, ServletResponse response, Object mappedValue) throws Exception {
        return false;
    }

    @Override
    protected boolean onAccessDenied(ServletRequest request, ServletResponse response) throws Exception {
        System.out.println("------HmacAuthcFilter");

        if(request instanceof HttpServletRequest){
            HttpServletRequest httpReq = (HttpServletRequest) request;
            String accessToken  = httpReq.getHeader(Constants.TOKEN_HEADER);
            String sign = httpReq.getHeader(Constants.SIGN_HEADER);
            String sessionId = httpReq.getHeader(Constants.SESSION_HEADER);
            if(StringUtils.isEmpty(accessToken) == true || StringUtils.isEmpty(sign) == true || StringUtils.isEmpty(sessionId) == true){
                LOG.error("cmd=HmacAuthcFilter:isAccessAllowed_err | ip={} | accessToken={} | sign={} | sessionId={}" , getIpAddr(httpReq), accessToken, sign, sessionId);
                ShiroUtil.onLoginFail(response);
                return false;
            }

           // 客户端请求的参数列表
            Map<String, String[]> params = new HashMap<String, String[]>(request.getParameterMap());
            String method = httpReq.getMethod().toLowerCase();
            String path = httpReq.getRequestURI().toLowerCase();
            if(path == null)
                path = "/";
            int pos = path.indexOf(Constants.API_PREFIX);
            if(pos > -1)
                path = path.substring(pos);

//            String body = ContextUtil.getContextParam().getData();
//            debug("",method, path, params, body);
            String body = ShiroUtil.getRequestPostStr(httpReq);

            //生成无状态Token
            StatelessToken token = createStatelessToken(httpReq, sign, sessionId, params, method, path, body);

            try {
                //委托给Realm进行登录
                getSubject(request, response).login(token);
            } catch (Exception e) {
                e.printStackTrace();
                ShiroUtil.onLoginFail(response); //登录失败
                return false;
            }
            return true;
        }
        return false;
    }

    protected StatelessToken createStatelessToken(HttpServletRequest httpReq, String sign, String sessionId, Map<String, String[]> params, String method, String path, String body) {
        return new StatelessToken(httpReq, sessionId, method, path, params, body, sign);
    }


//    public String debug(String passHash, String method, String path, Map<String, String[]> params, String body) {
//        StringBuilder sb = new StringBuilder();
//        sb.append(method).append("|").append(path).append("|");
//        Map<String, String> newMap = new HashMap<String, String>();
//        List<String> keys = new ArrayList<String>(params.size());
//        for (Iterator it = params.entrySet().iterator(); it.hasNext(); ) {
//            Map.Entry<String, String[]> entry = (Map.Entry<String, String[]>) it.next();
//            String key = entry.getKey(); //.toLowerCase();
//            keys.add(key);
//            String[] values = entry.getValue();
//            newMap.put(key, (values == null || values.length == 0) ? "" : values[0]);  // 注意假设没有多个值得情况，默认只取出第一个值
//        }
//        Collections.sort(keys);
//        for (int i = 0; i < keys.size(); i++) {
//            String key = keys.get(i);
//            String val = newMap.get(key); //.toLowerCase();
//            if (i > 0)
//                sb.append(',');
//            sb.append(key).append('=').append(val);
//        }
//        if(body != null && body.length() > 0)
//            sb.append("|").append(body);
//        String stringToSign = sb.toString();
//        return stringToSign;
//    }
}
