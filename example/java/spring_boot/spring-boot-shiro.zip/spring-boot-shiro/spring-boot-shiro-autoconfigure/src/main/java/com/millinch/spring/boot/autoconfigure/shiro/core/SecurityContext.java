package com.millinch.spring.boot.autoconfigure.shiro.core;

import java.util.Map;

/**
 * Created by Chuwei on 2016/9/5.
 */
public class SecurityContext {

    private static final ThreadLocal<Map<String,String>> sessionInfoHolder = new ThreadLocal<Map<String,String>>();
    private static final ThreadLocal<Map<String,String>> tokenInfoHolder = new ThreadLocal<Map<String,String>>();

    public static Map<String,String> getSessionInfo() {
        return sessionInfoHolder.get();
    }

    public static Map<String,String> getInfo() {
        return tokenInfoHolder.get();
    }

    public static void setSessionInfo(Map<String,String> info){
        sessionInfoHolder.set(info);
    }

    public static void setTokenInfo(Map<String,String> info){
        tokenInfoHolder.set(info);
    }

    public static void clear(){
        sessionInfoHolder.remove();
        tokenInfoHolder.remove();
    }



}