package com.millinch.spring.boot.autoconfigure.shiro;

import org.apache.shiro.crypto.hash.Sha256Hash;
import org.apache.shiro.util.SimpleByteSource;

import java.math.BigInteger;
import java.security.SecureRandom;
 
/**
 * http://www.yasith.me/2016/04/securing-restful-api-using-apache-shiro.html
 * The Class HashGenerator.
 * @author Yasith Lokuge
 */
public class HashGenerator{

    /**
     * Generate salt.
     *
     * @return the string
     */
    public String generateSalt() {
        return new BigInteger(250, new SecureRandom()).toString(32);
    }    
    
    /**
     * Generate hash.
     *
     * @param password the password
     * @return the string
     */
    public String generateHash(String password){
        Sha256Hash hash = new Sha256Hash(password);
        return hash.toHex();
    }
    
    /**
     * Salt hash password.
     *
     * @param password the password
     * @param salt the salt
     * @return the string
     */
    public String saltHashPassword(String password, String salt) {        
        Sha256Hash hash = new Sha256Hash(password, (new SimpleByteSource(salt)).getBytes());        
        return hash.toHex();
    }

    public static void main(String[] args) {
        HashGenerator hashGenerator = new HashGenerator();

        String password = "1qaz2wsx#";
        String salt = hashGenerator.generateSalt();
        String saltedPass = hashGenerator.saltHashPassword(password, salt);

        System.out.println("password        : " + password);
        System.out.println("random salt     : " + salt);
        System.out.println("salted password : " + saltedPass);
    }
    
}