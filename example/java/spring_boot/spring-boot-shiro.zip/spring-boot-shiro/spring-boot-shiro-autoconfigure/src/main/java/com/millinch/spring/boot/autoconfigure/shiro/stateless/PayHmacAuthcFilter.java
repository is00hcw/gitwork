package com.millinch.spring.boot.autoconfigure.shiro.stateless;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;
import java.util.Objects;

/**
 * Created by Chuwei on 2016/9/17.
 */
public class PayHmacAuthcFilter extends HmacAuthcFilter {
    @Override
    protected StatelessToken createStatelessToken(HttpServletRequest httpReq, String sign, String sessionId, Map<String, String[]> params, String method, String path, String body) {
        StatelessToken token = super.createStatelessToken(httpReq, sign, sessionId, params, method, path, body);
        String pay = token.getHttpReq().getHeader(Constants.PAY_HEADER);
        if (Objects.equals(pay,Constants.USE_PAY_PASS))
            token.setPay(true);  //使用支付密码
        return token;
    }
}
