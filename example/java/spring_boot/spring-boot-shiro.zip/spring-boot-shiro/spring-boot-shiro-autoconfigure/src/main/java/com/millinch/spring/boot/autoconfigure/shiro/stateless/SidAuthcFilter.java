package com.millinch.spring.boot.autoconfigure.shiro.stateless;


import com.millinch.spring.boot.autoconfigure.shiro.core.ResultCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by Chuwei on 2016/9/5.
 */
public class SidAuthcFilter extends TokenAuthcFilter {
    private final static Logger LOG = LoggerFactory.getLogger(SidAuthcFilter.class);

    @Override
    protected boolean isAccessAllowed(ServletRequest request, ServletResponse response, Object mappedValue) throws Exception {
        boolean res = super.isAccessAllowed(request, response, mappedValue);
        if(res){
            System.out.println("------SidAuthcFilter");
            if(request instanceof HttpServletRequest) {
                HttpServletRequest httpReq = (HttpServletRequest) request;
                HttpServletResponse httpResp = (HttpServletResponse) response;
//                if(devMode && isDebugReq(httpReq))  // TODO delete on release
//                    return true;

                String sessionId = httpReq.getHeader(Constants.SESSION_HEADER);
                if(sessionId == null || sessionId.length() == 0) {
                    LOG.error("cmd=SidAuthcFilter:isAccessAllowed_err | sessionId=null | ip={}" , getIpAddr(httpReq));
                    writeErrorResponse(httpResp, ResultCode.SESSION_INVALID);
                    return false;
                }

//                Map<String,String> sessionInfo = redisService.getSessionInfo(sessionId);
//                if(sessionInfo == null || sessionInfo.size() == 0) {
//                    LOG.error("cmd=SidAuthcFilter:isAccessAllowed_err | sessionId={} | ip={}" , sessionId, getIpAddr(httpReq));
//                    writeErrorResponse(httpResp, ResultCode.SESSION_INVALID);
//                    return false;
//                }
//                SecurityContext.setSessionInfo(sessionInfo);
                res = true;
            }
        }
        return res;
    }
}
