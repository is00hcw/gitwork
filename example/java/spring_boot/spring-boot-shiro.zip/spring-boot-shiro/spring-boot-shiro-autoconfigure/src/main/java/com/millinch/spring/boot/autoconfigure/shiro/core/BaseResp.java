package com.millinch.spring.boot.autoconfigure.shiro.core;



import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class BaseResp implements Serializable {
    private static final long serialVersionUID = -2533700802618371102L;
//    private boolean isOk;        // S_OK表示成功，其它表示操作失败
//    private long id;             // 操作成功时,返回操作的id
    private String code;        // 错误码
    private Object data;        // 响应数据,可以是实体对象类,可以是列表
    private String summary;        // 错误描述信息




    /**
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * @param code the code to set
     */
    public BaseResp setCode(String code) {
        this.code = code;
        return this;
    }

    public BaseResp setCode(ResultCode code) {
        this.code = code.name();
        this.summary = code.value();
        return this;
    }

    public String getSummary() {
        return summary;
    }

    public Object getData() {
        return data;
    }

    public BaseResp setData(Object data) {
        this.data = data;
//        if(data instanceof com.github.pagehelper.Page ){
//            com.github.pagehelper.Page info = (com.github.pagehelper.Page) data;
//            this.pageInfo = new Page(info.getPageNum(), info.getPageSize(), (int)info.getTotal());
//        }
        return this;
    }
//
//    public Page getPageInfo() {
//        return pageInfo;
//    }
//
//    public BaseResp setPageInfo(Page pageInfo) {
//        this.pageInfo = pageInfo;
//        return this;
//    }
//
//    public BaseResp setPageInfo(List data) {
//        if(data instanceof com.github.pagehelper.Page ){
//            com.github.pagehelper.Page info = (com.github.pagehelper.Page) data;
//            this.pageInfo = new Page(info.getPageNum(), info.getPageSize(), (int)info.getTotal());
//        }
//        return this;
//    }

    public BaseResp setKvData(String key, Object val) {
        Map<String, Object> data = new HashMap<String, Object>();
        data.put(key,val);
        this.data = data;
        return this;
    }

    public BaseResp setSummary(String summary) {
        this.summary = summary;
        return this;
    }
}
