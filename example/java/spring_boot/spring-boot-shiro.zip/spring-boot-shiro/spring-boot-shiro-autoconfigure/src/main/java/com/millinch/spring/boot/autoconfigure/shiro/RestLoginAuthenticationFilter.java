package com.millinch.spring.boot.autoconfigure.shiro;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;
import org.apache.shiro.web.filter.authc.AuthenticatingFilter;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

/**
 * Created by Chuwei on 2016/12/28.
 */
public class RestLoginAuthenticationFilter extends AuthenticatingFilter {


//    protected boolean onAccessDenied(ServletRequest request, ServletResponse response) throws Exception {
//        if (isLoginRequest(request, response)) {
//            return true;
//        } else {
////            saveRequestAndRedirectToLogin(request, response);
//            return false;
//        }
//    }


    @Override
    protected boolean preHandle(ServletRequest request, ServletResponse response) throws Exception {
        return super.preHandle(request, response);
    }

    @Override
    protected boolean isAccessAllowed(ServletRequest request, ServletResponse response, Object mappedValue) {
        return super.isAccessAllowed(request, response, mappedValue);
    }

    protected boolean onAccessDenied(ServletRequest request, ServletResponse response) throws Exception {
        boolean loggedIn = false; //false by default or we wouldn't be in this method
        System.out.println("--> executeLogin");
        try {
            loggedIn = executeLogin(request, response);

            Subject subject = SecurityUtils.getSubject();
            Session session = subject.getSession(false);
            if(session != null){
                session.setAttribute("login_time" , System.currentTimeMillis());
            }
        } catch (Exception e) {
            e.printStackTrace();
            ShiroUtil.onLoginFail(response); //登录失败
            return false;
        }

        return loggedIn;
    }

    @Override
    protected AuthenticationToken createToken(ServletRequest request, ServletResponse response) throws Exception {
        String body = ShiroUtil.getRequestPostStr((HttpServletRequest) request);
        System.out.println("--> " +body);
        JSONObject obj = JSON.parseObject(body);
        String username = obj.getString("username");
        String signature = obj.getString("signature");

        return new UsernamePasswordToken(username,signature);
    }
}
