package com.millinch.spring.boot.autoconfigure.shiro.stateless;


import com.millinch.spring.boot.autoconfigure.shiro.core.ResultCode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by Administrator on 2016/8/26.
 */
public class TokenAuthcFilter extends BaseAuthcFilter {
    private final static Logger LOG = LoggerFactory.getLogger(TokenAuthcFilter.class);

//    @Autowired
//    protected RedisTemplate<String, String> redisTemplate;
//
//    @Autowired
//    protected RedisService redisService;

    @Override
    protected boolean isAccessAllowed(ServletRequest request, ServletResponse response, Object mappedValue) throws Exception {
        System.out.println("------TokenAuthcFilter");
        if(request instanceof HttpServletRequest){
            HttpServletRequest httpReq = (HttpServletRequest) request;
            HttpServletResponse httpResp = (HttpServletResponse) response;
            String token = httpReq.getHeader(Constants.TOKEN_HEADER);
            if(token == null || token.length() == 0) {
                LOG.error("cmd=TokenAuthcFilter:isAccessAllowed_err | accessToken=null | ip={}" , getIpAddr(httpReq));
                writeErrorResponse(httpResp, ResultCode.ACCESS_TOKEN_IS_NULL);
                return false;
            }

//            if(devMode && isDebugReq(httpReq))  // TODO delete on release
//                return true;

            // 检查token合法性，确认在redis中存在
//            if( redisService.existsAccessToken(token) == false){
//                LOG.error("cmd=TokenAuthcFilter:isAccessAllowed_err | invalidAccessToken={} | ip={}", token, NetHelper.getIpAddr(httpReq));
//                writeErrorResponse(httpResp, ResultCode.ACCESS_TOKEN_INVALID);
//                return false;
//            }
//
//            SecurityContext.setTokenInfo( redisService.getAccessTokenInfo(token) );

            return true;
        }
        return false;
    }


    protected boolean onAccessDenied(ServletRequest request, ServletResponse response) throws Exception {
        return false;
    }
}
