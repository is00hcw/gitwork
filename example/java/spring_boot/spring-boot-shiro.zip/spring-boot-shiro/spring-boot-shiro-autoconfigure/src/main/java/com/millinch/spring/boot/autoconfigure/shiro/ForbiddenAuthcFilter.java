package com.millinch.spring.boot.autoconfigure.shiro;

import org.apache.shiro.web.filter.PathMatchingFilter;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * Created by Chuwei on 2016/10/25.
 * 禁止访问,用于屏蔽url
 */
public class ForbiddenAuthcFilter extends PathMatchingFilter {

    @Override
    protected boolean onPreHandle(ServletRequest request, ServletResponse response, Object mappedValue) {
        // Always return false
        System.out.println("---> ForbiddenAuthcFilter");
        return false;
    }

}

