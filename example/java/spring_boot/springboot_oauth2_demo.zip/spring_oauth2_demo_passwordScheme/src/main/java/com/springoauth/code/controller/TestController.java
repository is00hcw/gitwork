package com.springoauth.code.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.oauth2.client.OAuth2ClientContext;
import org.springframework.security.oauth2.client.OAuth2RestOperations;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.security.oauth2.client.resource.OAuth2ProtectedResourceDetails;
import org.springframework.security.oauth2.client.token.grant.client.ClientCredentialsResourceDetails;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableOAuth2Client;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;

/**
 * Created by wuhuachuan on 16/5/11.
 */
@EnableOAuth2Client
@RestController
public class TestController {
    @Autowired
    OAuth2RestOperations restOperations;

    @RequestMapping(value = "/test")
    public String test(){
        System.out.println("test!");
        return "hello";
    }

    @RequestMapping(value = "/client")
    public String client() {
        System.out.println("client");
//        String token = restOperations.getForObject("http://localhost:8080/oauth/token", String.class);
        String res =  restOperations.getForObject("http://localhost:8080/test", String.class);
        System.out.println(restOperations.getAccessToken());
        System.out.println("----");
        return res;
    }


    @Bean
    public OAuth2RestOperations restTemplate(OAuth2ClientContext oauth2ClientContext) {
        return new OAuth2RestTemplate(resource(), oauth2ClientContext);
    }


    private OAuth2ProtectedResourceDetails resource() {
        ClientCredentialsResourceDetails resource = new ClientCredentialsResourceDetails();  // AuthorizationCodeResourceDetails
        resource.setClientId("whc_client_id");
        resource.setClientSecret("whc_client_secret");
        resource.setAccessTokenUri("http://localhost:8080/oauth/token");
//        resource.setUserAuthorizationUri("http://localhost:8080/oauth/authorize");
        resource.setScope(Arrays.asList("whc"));

        return resource;
    }
}
