package org.haycco.spring.infrastructure.externalwebservice;

public class ExternalWebServiceStub {

    public String getSomeStuff() {
        return "From external WebService";
    }
}
