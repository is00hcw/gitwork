package com.wanke;

import com.wanke.data.jpa.UserRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class StockAppApplicationTests {
	@Autowired
	private UserRepository userRepository;

	@Before
	public void before() {
		//userRepository.save(new User("AAA", 10));
	}

	@Test
	public void test() throws Exception {
		int size = userRepository.findAll().size();
		System.out.println("第一次查询：" + size);
		size = userRepository.findAll().size();
		System.out.println("第二次查询：" + size);
	}

	@Test
	public void contextLoads() {
	}

}
