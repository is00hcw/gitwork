package com.wanke.web.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.Locale;

@Controller
public class UploadingController {
    @Autowired
    private MessageSource messageSource;

    public static final String uploadingdir = System.getProperty("java.io.tmpdir") + "/uploadingdir/";

    public UploadingController(){
        System.out.println("---> " + UploadingController.uploadingdir);
        new File(UploadingController.uploadingdir).mkdirs();
    }
    @RequestMapping("/file")
    public String uploading(Model model) {
        System.out.println(uploadingdir);
        File file = new File(uploadingdir);
        model.addAttribute("files", file.listFiles());
        return "uploading";
    }

    @RequestMapping(value = "/file", method = RequestMethod.POST)
    public String uploadingPost(@RequestParam("uploadingFiles") MultipartFile[] uploadingFiles) throws IOException {
        for(MultipartFile uploadedFile : uploadingFiles) {
            File file = new File(uploadingdir + uploadedFile.getOriginalFilename());
            uploadedFile.transferTo(file);
        }

        return "redirect:/file";
    }

    @RequestMapping(value = "/ajax_upload", method = RequestMethod.POST)
    @ResponseBody
    public String ajaxUploadingPost(@RequestParam("uploadingFiles") MultipartFile[] uploadingFiles) throws IOException {
        for(MultipartFile uploadedFile : uploadingFiles) {
            System.out.println("upload file: " + uploadedFile.getOriginalFilename());
            File file = new File(uploadingdir + uploadedFile.getOriginalFilename());
            System.out.println("--> " +file.getAbsolutePath());
            uploadedFile.transferTo(file);
        }

        Locale locale = LocaleContextHolder.getLocale();
//        Locale locale1= RequestContextUtils.getLocale(request);
        String msg = messageSource.getMessage("project.name", null,locale);
        System.out.println(locale);
        System.out.println(msg);
        return "ok";
    }
}