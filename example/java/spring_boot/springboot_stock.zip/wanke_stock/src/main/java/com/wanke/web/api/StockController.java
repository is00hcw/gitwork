package com.wanke.web.api;

/**
 * Created by Chuwei on 2017/1/7.
 */

import com.github.pagehelper.PageHelper;
import com.wanke.data.entity.SysRole;
import com.wanke.data.entity.SysRoleExample;
import com.wanke.data.jpa.SysUser;
import com.wanke.data.jpa.UserRepository;
import com.wanke.data.mapper.SysRoleMapperExt;
import com.wanke.service.GreetingRemoteService;
import com.wanke.service.StockService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.batch.core.*;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/api/stock")
public class StockController {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private SysRoleMapperExt sysRoleMapper;

    @Autowired
    private StockService stockService;

    @Autowired
    private GreetingRemoteService greetingClient;


    @Autowired
    JobLauncher jobLauncher;

    @Autowired
    Job importJob;


    @RequestMapping("/csv")
    @ResponseBody
    public String importCsv()  {
        String path = "people.csv";
        JobParameters jobParameters = new JobParametersBuilder()
                .addLong("time", System.currentTimeMillis())
                .addString("input.file.name", path)
                .addLong("chunk.size", 100L)
                .toJobParameters();

        try {
            JobExecution exec = jobLauncher.run(importJob, jobParameters);
            System.out.println(exec.getExitStatus());
        } catch (JobExecutionAlreadyRunningException e) {
            e.printStackTrace();
        } catch (JobRestartException e) {
            e.printStackTrace();
        } catch (JobInstanceAlreadyCompleteException e) {
            e.printStackTrace();
        } catch (JobParametersInvalidException e) {
            e.printStackTrace();
        }

        return "ok";
    }

    @RequestMapping("/greeting/{username}")
    @ResponseBody
    public String greet(@PathVariable("username") String username) {
        String res1 = stockService.getGreeting(username);
        System.out.println(res1);
        String res2 = greetingClient.greeting(username);
        System.out.println(res2);
        return res1 + "," + res2;
    }

    @RequestMapping(value = "/jpa", method = RequestMethod.GET)
    @ResponseBody
    public String testJpa() {
        List<SysUser> users = userRepository.findAll();
        System.out.println("users: " + users.size());
        SysUser u = userRepository.findByUserName("admin");
        System.out.println(u);
        return "jpa";
    }


    @RequestMapping(value = "/mybatis", method = RequestMethod.GET)
    @ResponseBody
    public String testMybatis() {
//        Role u = roleMapper.findByName("aaa");
//        System.out.println(u);
        PageHelper.startPage(1,2);
        List<SysRole> list = sysRoleMapper.selectByExample(new SysRoleExample());
        System.out.println(list);
        return "mybatis";
    }

    @ResponseBody
    @RequestMapping(value = "/show", method = RequestMethod.POST)
// 这里指定RequestMethod，如果不指定Swagger会把所有RequestMethod都输出，在实际应用中，具体指定请求类型也使接口更为严谨。
    @ApiOperation(value = "测试接口", notes = "测试接口详细描述")
    public String show(
            @ApiParam(required = true, name = "name", value = "姓名")
            @RequestParam(name = "name") String name) {
        return "success";
    }


}
