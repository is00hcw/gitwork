package com.wanke.service.impl;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import com.wanke.service.StockService;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

/**
 * Created by Chuwei on 2017/1/7.
 */
@Service
public class StockServiceImpl implements StockService {

    @HystrixCommand(fallbackMethod = "defaultGreeting", commandProperties = {
            @HystrixProperty(name="execution.isolation.strategy", value="SEMAPHORE")
    })
    public String getGreeting(String username) {
        return new RestTemplate()
                .getForObject("http://localhost:9090/greeting/{username}",
                        String.class, username);
    }

    private String defaultGreeting(String username) {
        return "Hello fail!";
    }
}
