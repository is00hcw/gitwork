package com.wanke.data.entity;


import com.wanke.data.BaseEntity;

import java.util.Date;

public class SysRole extends BaseEntity {
    /**
     * <pre>
     * 
     * 表字段 : sys_role.id
     * </pre>
     */
    private Long id;

    /**
     * <pre>
     * 
     * 表字段 : sys_role.name
     * </pre>
     */
    private String name;

    /**
     * <pre>
     * 
     * 表字段 : sys_role.code
     * </pre>
     */
    private String code;

    /**
     * <pre>
     * 
     * 表字段 : sys_role.remark
     * </pre>
     */
    private String remark;

    /**
     * <pre>
     * 
     * 表字段 : sys_role.status
     * </pre>
     */
    private Boolean status;

    /**
     * <pre>
     * 
     * 表字段 : sys_role.parent_id
     * </pre>
     */
    private Long parentId;

    /**
     * <pre>
     * 
     * 表字段 : sys_role.create_by
     * </pre>
     */
    private Long createBy;

    /**
     * <pre>
     * 
     * 表字段 : sys_role.create_at
     * </pre>
     */
    private Date createAt;

    /**
     * <pre>
     * 
     * 表字段 : sys_role.update_by
     * </pre>
     */
    private Long updateBy;

    /**
     * <pre>
     * 
     * 表字段 : sys_role.update_at
     * </pre>
     */
    private Date updateAt;

    /**
     * <pre>
     * 获取：
     * 表字段：sys_role.id
     * </pre>
     *
     * @return sys_role.id：
     */
    public Long getId() {
        return id;
    }

    /**
     * <pre>
     * 设置：
     * 表字段：sys_role.id
     * </pre>
     *
     * @param id
     *            sys_role.id：
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * <pre>
     * 获取：
     * 表字段：sys_role.name
     * </pre>
     *
     * @return sys_role.name：
     */
    public String getName() {
        return name;
    }

    /**
     * <pre>
     * 设置：
     * 表字段：sys_role.name
     * </pre>
     *
     * @param name
     *            sys_role.name：
     */
    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    /**
     * <pre>
     * 获取：
     * 表字段：sys_role.code
     * </pre>
     *
     * @return sys_role.code：
     */
    public String getCode() {
        return code;
    }

    /**
     * <pre>
     * 设置：
     * 表字段：sys_role.code
     * </pre>
     *
     * @param code
     *            sys_role.code：
     */
    public void setCode(String code) {
        this.code = code == null ? null : code.trim();
    }

    /**
     * <pre>
     * 获取：
     * 表字段：sys_role.remark
     * </pre>
     *
     * @return sys_role.remark：
     */
    public String getRemark() {
        return remark;
    }

    /**
     * <pre>
     * 设置：
     * 表字段：sys_role.remark
     * </pre>
     *
     * @param remark
     *            sys_role.remark：
     */
    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }

    /**
     * <pre>
     * 获取：
     * 表字段：sys_role.status
     * </pre>
     *
     * @return sys_role.status：
     */
    public Boolean getStatus() {
        return status;
    }

    /**
     * <pre>
     * 设置：
     * 表字段：sys_role.status
     * </pre>
     *
     * @param status
     *            sys_role.status：
     */
    public void setStatus(Boolean status) {
        this.status = status;
    }

    /**
     * <pre>
     * 获取：
     * 表字段：sys_role.parent_id
     * </pre>
     *
     * @return sys_role.parent_id：
     */
    public Long getParentId() {
        return parentId;
    }

    /**
     * <pre>
     * 设置：
     * 表字段：sys_role.parent_id
     * </pre>
     *
     * @param parentId
     *            sys_role.parent_id：
     */
    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }

    /**
     * <pre>
     * 获取：
     * 表字段：sys_role.create_by
     * </pre>
     *
     * @return sys_role.create_by：
     */
    public Long getCreateBy() {
        return createBy;
    }

    /**
     * <pre>
     * 设置：
     * 表字段：sys_role.create_by
     * </pre>
     *
     * @param createBy
     *            sys_role.create_by：
     */
    public void setCreateBy(Long createBy) {
        this.createBy = createBy;
    }

    /**
     * <pre>
     * 获取：
     * 表字段：sys_role.create_at
     * </pre>
     *
     * @return sys_role.create_at：
     */
    public Date getCreateAt() {
        return createAt;
    }

    /**
     * <pre>
     * 设置：
     * 表字段：sys_role.create_at
     * </pre>
     *
     * @param createAt
     *            sys_role.create_at：
     */
    public void setCreateAt(Date createAt) {
        this.createAt = createAt;
    }

    /**
     * <pre>
     * 获取：
     * 表字段：sys_role.update_by
     * </pre>
     *
     * @return sys_role.update_by：
     */
    public Long getUpdateBy() {
        return updateBy;
    }

    /**
     * <pre>
     * 设置：
     * 表字段：sys_role.update_by
     * </pre>
     *
     * @param updateBy
     *            sys_role.update_by：
     */
    public void setUpdateBy(Long updateBy) {
        this.updateBy = updateBy;
    }

    /**
     * <pre>
     * 获取：
     * 表字段：sys_role.update_at
     * </pre>
     *
     * @return sys_role.update_at：
     */
    public Date getUpdateAt() {
        return updateAt;
    }

    /**
     * <pre>
     * 设置：
     * 表字段：sys_role.update_at
     * </pre>
     *
     * @param updateAt
     *            sys_role.update_at：
     */
    public void setUpdateAt(Date updateAt) {
        this.updateAt = updateAt;
    }
}