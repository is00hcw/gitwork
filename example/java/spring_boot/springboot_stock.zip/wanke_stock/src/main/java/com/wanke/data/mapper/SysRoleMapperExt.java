package com.wanke.data.mapper;

import org.apache.ibatis.annotations.Mapper;

import javax.annotation.Resource;

@Resource
@Mapper
public interface SysRoleMapperExt extends SysRoleMapper {
}