package com.wanke.service;

/**
 * Created by Chuwei on 2017/1/7.
 */
public interface StockService {
    String getGreeting(String username);
}
