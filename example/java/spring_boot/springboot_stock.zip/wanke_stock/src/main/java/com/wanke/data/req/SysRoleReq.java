package com.wanke.data.req;


import com.wanke.data.entity.SysRole;

public class SysRoleReq extends SysRole {
}