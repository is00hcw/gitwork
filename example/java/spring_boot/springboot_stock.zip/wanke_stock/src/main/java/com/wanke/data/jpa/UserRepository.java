package com.wanke.data.jpa;

import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by Chuwei on 2017/1/3.
 */
@CacheConfig(cacheNames = "users")
public interface UserRepository extends JpaRepository<SysUser, Long > {
    @Cacheable
    SysUser findByUserName(String name);

}
