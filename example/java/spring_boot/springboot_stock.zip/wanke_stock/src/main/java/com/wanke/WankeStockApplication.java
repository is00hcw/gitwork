package com.wanke;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.cloud.netflix.hystrix.dashboard.EnableHystrixDashboard;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;

//@MapperScan(basePackages = "com.**.mapper", annotationClass=Resource.class)
@EnableTransactionManagement // 启注解事务管理，等同于xml配置方式的 <tx:annotation-driven />
@EnableCaching
@EnableScheduling
@EnableCircuitBreaker
@EnableFeignClients
@EnableHystrixDashboard   // http://localhost:8080/hystrix
//@EnableAdminServer
@SpringBootApplication
public class WankeStockApplication {

	public static void main(String[] args) {
		SpringApplication.run(WankeStockApplication.class, args);
	}
}
