package com.wanke.service;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;

@FeignClient(
  name = "rest-producer",
  url = "http://localhost:9090", 
  fallback = GreetingRemoteService.GreetingRemoteServiceFallback.class
)
public interface GreetingRemoteService {

    @RequestMapping("/get-greeting/{username}")
    String greeting(String username);

    @Component
    public static class GreetingRemoteServiceFallback implements GreetingRemoteService {
        @Override
        public String greeting(String username) {
            return "Hello feign!";
        }
    }
}