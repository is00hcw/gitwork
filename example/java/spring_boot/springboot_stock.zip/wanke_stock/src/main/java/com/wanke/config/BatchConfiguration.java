package com.wanke.config;


import com.wanke.batch.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.*;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.repository.support.JobRepositoryFactoryBean;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.batch.item.validator.Validator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.retry.backoff.ExponentialRandomBackOffPolicy;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;


@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

    private static final Logger LOGGER = LoggerFactory.getLogger(BatchConfiguration.class);

    //ItemReader定义

    @Bean
    @StepScope
    public FlatFileItemReader<Person> reader(@Value("#{jobParameters['input.file.name']}")
                                                     String pathToFile) throws Exception {
        System.out.println("init reader: ==> " + pathToFile);
        //使用FlatFileItemReader读取文件
        FlatFileItemReader<Person> reader = new FlatFileItemReader<Person>();
        //设置csv文件路径
        reader.setResource(new ClassPathResource(pathToFile));
//        new FileSystemResource(ResourceUtils.getFile(pathToFile))

//        reader.setLinesToSkip(1);  // 跳过第一行
        //对csv文件的数据和领域模型类做对应映射
//        reader.setLineMapper(new DefaultLineMapper<Person>(){{
//            setLineTokenizer(new DelimitedLineTokenizer(){{
//                setNames(new String[]{"name", "age", "nation", "address"});
//            }});
//            setFieldSetMapper(new BeanWrapperFieldSetMapper<Person>(){{
//                setTargetType(Person.class);
//            }});
//        }});
        reader.setLineMapper(lineMapper());
        return reader;
    }

    @Bean
    @StepScope
    public LineMapper<Person> lineMapper() {
        DefaultLineMapper<Person> lineMapper = new DefaultLineMapper<Person>();
        DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer();
        lineTokenizer.setDelimiter(",");
        lineTokenizer.setStrict(false);
        lineTokenizer.setNames(new String[]{"name", "age", "nation", "address"});

        BeanWrapperFieldSetMapper<Person> fieldSetMapper = new BeanWrapperFieldSetMapper<Person>();
        fieldSetMapper.setTargetType(Person.class);
        lineMapper.setLineTokenizer(lineTokenizer);
        lineMapper.setFieldSetMapper(fieldSetMapper);
        return lineMapper;
    }


    //ItemProcessor定义
    // PassThroughItemProcessor 不处理,直接将输入参数返回
    @Bean
    public ItemProcessor<Person, Person> processor() {
        //采用自定义的ItemProcessor的实现
        CsvItemProcessor processor = new CsvItemProcessor();
        //指定自定义检验器
        processor.setValidator(csvBeanValidator());
        return processor;
    }

    //ItemWriter定义
    @Bean
    public ItemWriter<Person> writer(DataSource dataSource) {//自动注入dataSource
        //使用jdbc批处理的JdbcBatchItemWriter写数据到数据库
        JdbcBatchItemWriter<Person> writer = new JdbcBatchItemWriter<Person>();
        writer.setItemSqlParameterSourceProvider(new
                BeanPropertyItemSqlParameterSourceProvider<Person>());
        //要执行批处理的sql语句
        String sql = "insert into PERSON " + "(name,age,nation,address) " +
                "values (:name, :age, :nation, :address)";
        writer.setSql(sql);
        writer.setDataSource(dataSource);
        return writer;
    }

    @Bean
    public JobRepository jobRepository(DataSource dataSource,
                                       PlatformTransactionManager transactionManager) throws Exception {
        JobRepositoryFactoryBean jobRepositoryFactoryBean = new
                JobRepositoryFactoryBean();
        jobRepositoryFactoryBean.setDataSource(dataSource);
        jobRepositoryFactoryBean.setTransactionManager(transactionManager);
        jobRepositoryFactoryBean.setDatabaseType("mysql");
        return jobRepositoryFactoryBean.getObject();
    }

    @Bean
    public SimpleJobLauncher jobLauncher(DataSource dataSource,
                                         PlatformTransactionManager transactionManager) throws Exception {
        SimpleJobLauncher jobLauncher = new SimpleJobLauncher();
        jobLauncher.setJobRepository(jobRepository(dataSource, transactionManager));
        return jobLauncher;
    }


    @Bean
    public Job importJob(JobBuilderFactory jobs, Step s1) {
        return jobs.get("importJob")
                .incrementer(new RunIdIncrementer())
                .flow(s1)
                .end()
                .listener(csvJobListener())
                .build();
    }

//    @Bean
//    public org.springframework.batch.core.scope.JobScope jobScope(){
//        return new org.springframework.batch.core.scope.JobScope();
//    }
//
//    @JobScope
    @Bean
    public Step step1(StepBuilderFactory stepBuilderFactory, ItemReader<Person> reader,
                      ItemWriter<Person> writer,
                      ItemProcessor<Person, Person> processor,PlatformTransactionManager transactionManager
                    // , @Value("#{jobParameters['chunk.size']:1}") long chunkSize
        ) {
//        System.out.println("==== chunk ==> " + chunkSize);
        return stepBuilderFactory
                .get("step1")
                .<Person, Person>chunk((int)3)//每次提交几条数据
                .reader(reader)
                .processor(processor)
                .writer(writer)
                .faultTolerant()
                .retry(Exception.class)   // 重试
                .noRetry(ParseException.class)
                .backOffPolicy(new ExponentialRandomBackOffPolicy())
                .retryLimit(3)         //每条记录重试3次
                .listener(new RetryFailuireItemListener())
//                .skip(Exception.class)
//                .skipLimit(500)         //一共允许跳过200次异常
////                .taskExecutor(new SimpleAsyncTaskExecutor()) //设置并发方式执行
//                .throttleLimit(10)        //并发任务数为 10,默认为4
                .transactionManager(transactionManager)
                .build();
    }

    @Bean
    public CsvJobListener csvJobListener() {
        return new CsvJobListener();
    }

    @Bean
    public Validator<Person> csvBeanValidator() {
        return new CsvBeanValidator<Person>();
    }

    @Bean
    @ConditionalOnBean
    public JdbcTemplate jdbcTemplate(DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }


//    @Bean
//    public ItemReader<RecordSO> reader(DataSource dataSource) {
//        JdbcCursorItemReader<RecordSO> reader = new JdbcCursorItemReader<>();
//        reader.setSql("select id, firstName, lastname, random_num from reader");
//        reader.setDataSource(dataSource);
//        reader.setRowMapper(
//                (ResultSet resultSet, int rowNum) -> {
//                    LOGGER.info("RowMapper resultset: {}", resultSet);
//                    if (!(resultSet.isAfterLast()) && !(resultSet.isBeforeFirst())) {
//                        RecordSO recordSO = new RecordSO();
//                        recordSO.setFirstName(resultSet.getString("firstName"));
//                        recordSO.setLastName(resultSet.getString("lastname"));
//                        recordSO.setId(resultSet.getInt("Id"));
//                        recordSO.setRandomNum(resultSet.getString("random_num"));
//
//                        LOGGER.info("RowMapper record : {}", recordSO);
//                        return recordSO;
//                    } else {
//                        LOGGER.info("Returning null from rowMapper");
//                        return null;
//                    }
//                });
//        return reader;
//    }
//
//    @Bean
//    public ItemProcessor<RecordSO, WriterSO> processor() {
//        return new RecordProcessor();
//    }
//
//    @Bean
//    public ItemWriter<WriterSO> writer(DataSource dataSource, ItemPreparedStatementSetter<WriterSO> setter) {
//        JdbcBatchItemWriter<WriterSO> writer = new JdbcBatchItemWriter<>();
//        writer.setItemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>());
//        writer.setItemPreparedStatementSetter(setter);
//        writer.setSql("insert into writer (id, full_name, random_num) values (?,?,?)");
//        writer.setDataSource(dataSource);
//        return writer;
//    }
//
//    @Bean
//    public ItemPreparedStatementSetter<WriterSO> setter() {
//        return (item, ps) -> {
//            ps.setLong(1, item.getId());
//            ps.setString(2, item.getFullName());
//            ps.setString(3, item.getRandomNum());
//        };
//    }
//
//    @Bean
//    public Job importUserJob(JobBuilderFactory jobs, Step s1, JobExecutionListener listener) {
//        return jobs.get("importUserJob")
//                .incrementer(new RunIdIncrementer())
//                .listener(listener)
//                .flow(s1)
//                .end()
//                .build();
//    }
//
//    @Bean
//    public Step step1(StepBuilderFactory stepBuilderFactory, ItemReader<RecordSO> reader,
//                      ItemWriter<WriterSO> writer, ItemProcessor<RecordSO, WriterSO> processor) {
//        return stepBuilderFactory.get("step1")
//                .<RecordSO, WriterSO>chunk(5)
//                .reader(reader)
//                .processor(processor)
//                .writer(writer)
//                .build();
//    }
//

}