package com.wanke.data;

import java.io.Serializable;

/**
 * Entity基类
 */
//@JsonIgnoreProperties(value = {"tid", "pageInfo"})
public abstract class BaseEntity implements Serializable {
//    @JSONField(serialize = false)
//    private String tid;
//    /**
//     * 分页对象
//     */
//    @JSONField(serialize = false)
//    private PageInfo pageInfo;
//
//
//    public String getTid() {
//        return tid;
//    }
//
//    public void setTid(String tid) {
//        this.tid = tid;
//    }
//
//    public PageInfo getPageInfo() {
//        if(pageInfo!=null){
//            return pageInfo;
//        }else{
//            this.pageInfo = new PageInfo();
//            return this.pageInfo;
//        }
//    }
//
//    public void setPageInfo(PageInfo page) {
//        this.pageInfo = page;
//    }

}
