package com.wanke.web;

import lombok.Data;


@Data
public class ApiResult<T> {


    /**
     * 状态码
     */
    private String code;


    /**
     * 数据结果
     */
    private T result;

    /**
     * 返回状态消息内容
     * 错误消息
     */
    private String summary;

    /**
     * 时间
     */
    private long timestamp = System.currentTimeMillis();
}