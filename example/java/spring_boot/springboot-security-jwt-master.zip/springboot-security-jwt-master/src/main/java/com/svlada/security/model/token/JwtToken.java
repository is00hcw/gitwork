package com.svlada.security.model.token;

public interface JwtToken {
    String getToken();
}
