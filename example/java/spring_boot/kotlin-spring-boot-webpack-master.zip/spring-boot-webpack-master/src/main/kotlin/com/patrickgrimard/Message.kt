package com.patrickgrimard

/**
 *
 *
 * Created on 2016-10-27
 *
 * @author Patrick
 */
data class Message constructor(val id: Long, val messageString: String)