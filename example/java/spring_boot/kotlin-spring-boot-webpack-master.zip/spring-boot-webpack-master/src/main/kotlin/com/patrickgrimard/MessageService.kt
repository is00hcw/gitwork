package com.patrickgrimard

/**
 *
 *
 * Created on 2016-03-24
 *
 * @author Patrick
 */
interface MessageService {
    fun getMessages(): Array<Message>
}