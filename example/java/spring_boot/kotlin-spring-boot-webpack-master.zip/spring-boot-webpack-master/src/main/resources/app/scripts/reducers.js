import {combineReducers} from 'redux';
import messages from 'components/message/MessageReducer';

export default combineReducers({messages});