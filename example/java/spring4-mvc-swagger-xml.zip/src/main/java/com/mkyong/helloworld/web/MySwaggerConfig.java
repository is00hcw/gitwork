package com.mkyong.helloworld.web;

import com.mangofactory.swagger.configuration.SpringSwaggerConfig;
import com.mangofactory.swagger.models.dto.ApiInfo;
import com.mangofactory.swagger.paths.SwaggerPathProvider;
import com.mangofactory.swagger.plugin.EnableSwagger;
import com.mangofactory.swagger.plugin.SwaggerSpringMvcPlugin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableSwagger //Loads the spring beans required by the framework
public class MySwaggerConfig {

   private SpringSwaggerConfig springSwaggerConfig;

   /**
    * Required to autowire SpringSwaggerConfig
    */
   @Autowired
   public void setSpringSwaggerConfig(SpringSwaggerConfig springSwaggerConfig) {
      this.springSwaggerConfig = springSwaggerConfig;
   }

   /**
    * Every SwaggerSpringMvcPlugin bean is picked up by the swagger-mvc framework - allowing for multiple
    * swagger groups i.e. same code base multiple swagger resource listings.
    */
   @Bean
//   public SwaggerSpringMvcPlugin customImplementation(){
//      return new SwaggerSpringMvcPlugin(this.springSwaggerConfig)
//              .includePatterns("com.mkyong.helloworld.web.*");
//   }
   public SwaggerSpringMvcPlugin customImplementation() {
      return new SwaggerSpringMvcPlugin(this.springSwaggerConfig)
              .apiInfo(apiInfo()).includePatterns(".*")
              .useDefaultResponseMessages(false)
                      //	.pathProvider(new GtPaths())
              .apiVersion("0.1").swaggerGroup("user");
   }


    private ApiInfo apiInfo() {
        ApiInfo apiInfo = new ApiInfo("后台API接口平台",
                "提供详细的后台所有restful接口", "http://huhao520.com",
                "mousycoder@foxmail.com", "mousycoder博客", "http://huhao520.com");
        return apiInfo;
    }


   class GtPaths extends SwaggerPathProvider {

      @Override
      protected String applicationPath() {
         return "/restapi";
      }

      @Override
      protected String getDocumentationPath() {
         return "/restapi";
      }
   }


}