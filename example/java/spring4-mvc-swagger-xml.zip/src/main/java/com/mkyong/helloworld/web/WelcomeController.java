package com.mkyong.helloworld.web;

import java.util.Map;

import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import com.mkyong.helloworld.service.HelloWorldService;

// http://localhost:8080/spring4/api-docs/user/welcome-controller
// http://localhost:8080/spring4/index.html#/

// https://github.com/rlogiacco/swagger-springmvc
// http://albertchen.top/2015/05/26/Spring-MVC-%E9%9B%86%E6%88%90-Swagger/
// http://blog.csdn.net/fengspg/article/details/43705537
@Controller
public class WelcomeController {

	private final Logger logger = LoggerFactory.getLogger(WelcomeController.class);
	private final HelloWorldService helloWorldService;

	@Autowired
	public WelcomeController(HelloWorldService helloWorldService) {
		this.helloWorldService = helloWorldService;
	}

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String index(Map<String, Object> model) {

		logger.debug("index() is executed!");

		model.put("title", helloWorldService.getTitle(""));
		model.put("msg", helloWorldService.getDesc());
		
		return "index";
	}

//	@RequestMapping(value = "/hello/{name:.+}", method = RequestMethod.GET)
//	public ModelAndView hello(@PathVariable("name") String name) {
//
//		logger.debug("hello() is executed - $name {}", name);
//
//		ModelAndView model = new ModelAndView();
//		model.setViewName("index");
//
//		model.addObject("title", helloWorldService.getTitle(name));
//		model.addObject("msg", helloWorldService.getDesc());
//
//		return model;
//
//	}
    @ApiOperation( value = "获得商品信息", notes = "获取商品信息(用于数据同步)",httpMethod = "POST",produces= MediaType.APPLICATION_JSON_VALUE)
    @ApiResponses(value={@ApiResponse(code=200,message="商品信息"),
            @ApiResponse(code=201,message="(token验证失败)",response=String.class),
            @ApiResponse(code=202,message="(系统错误)",response=String.class)})
    @RequestMapping(value = "/api", method = RequestMethod.POST)
    @ResponseBody
    public String getCommodity(@ApiParam(value="Json参数",required=true)@RequestBody String param) throws Exception {
        return param;
    }

	

}