# SpringCloudSleuth
SpringCloudSleuth DEMO

[SpringCloudSleuth blog](http://blog.spring-cloud.io/blog/sc-sleuth.html)

# alan-demo-sleuth

gateway、msa、msb、msc四个服务，需在IDE中用main方法启动

# alan-demo-sleuth-zipkin

ZipkinServer 简单的HTTP服务

# alan-demo-sleuth-zipkin-stream

ZipkinServer 可通过HTTP接口收集数据，并可以通过集成SpringCloudStream在kafka中收集数据，可将收集的数据持久化到MySql数据库。


