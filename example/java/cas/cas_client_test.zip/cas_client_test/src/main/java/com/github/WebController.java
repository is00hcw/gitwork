package com.github;

 
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.Cookie;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;  
import javax.servlet.http.HttpSession;  
import java.security.Principal;

@Controller
public class WebController {
    
    @RequestMapping("/index.do")
    public String showIndex(HttpServletRequest request, HttpServletResponse response) {
        Principal principal = request.getUserPrincipal();
        request.getSession().setAttribute("user", principal.getName());
        return "/index";  
     }
}
