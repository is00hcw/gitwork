package com.example;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.embedded.ServletRegistrationBean;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.session.data.redis.config.annotation.web.http.EnableRedisHttpSession;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;
import com.example.dao.*;
import com.example.model.*;

// @ImportResource({"classpath*:applicationContext.xml"})
// @MapperScan("com.example.dao")
//@Configuration
//@ComponentScan
//@EnableAutoConfiguration
//----------------

@ServletComponentScan
@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
        //  System.setProperty("spring.devtools.restart.enabled", "false");
        ApplicationContext ctx =  SpringApplication.run(DemoApplication.class, args);

        System.out.println("Let's inspect the beans provided by Spring Boot:");

        String[] beanNames = ctx.getBeanDefinitionNames();
        Arrays.sort(beanNames);
        for (String beanName : beanNames) {
            System.out.println(beanName);
        }
	}

//    @Bean
//    public ServletRegistrationBean servletRegistrationBean() {
//        return new ServletRegistrationBean(new ExampleServlet(), "/example/*");// ServletName默认值为首字母小写，即myServlet
//    }
}

@RestController
class GreetingController {

    @RequestMapping("/hello/{name}")
    String hello(@PathVariable String name) {
        return "Hello, " + name + "!";
    }
    
    @Autowired
	private UserMapper userMapper;

    @RequestMapping("/user/{id}")
    ResponseEntity user(@PathVariable Integer id) {
        ResponseEntity response = null;
        User userinfo = userMapper.selectByPrimaryKey(id);
        response = new ResponseEntity<User>(userinfo, HttpStatus.OK);
        return response;
    }
}