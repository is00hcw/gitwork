package com.example;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;

import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.web.SpringBootServletInitializer;

// @ServletComponentScan
// @SpringBootApplication
public class TomcatApplication extends SpringBootServletInitializer {

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(TomcatApplication.class);
    }

    // @Bean
    // public ServletRegistrationBean mainServlet(){
    //     ServletRegistrationBean servlet = new ServletRegistrationBean();
    //     servlet.setName("main");
    //     servlet.setServlet(new DispatcherServlet());
    /*--   servlet.addInitParameter("contextConfigLocation", "classpath:main-servlet.xml");   */
    //     servlet.addUrlMappings("*.html","*.htmlf","*.json", "/my/issue","/my/query","/my/adjust","/my/echo");
    //     return servlet;
    // }
    
    // @Bean
    // public FilterRegistrationBean sitemeshFilter(){
    //     FilterRegistrationBean filter = new FilterRegistrationBean();
    //     filter.setName("sitemesh");
    //     filter.setFilter(new SiteMeshFilter());
    //     filter.addUrlPatterns("*.html");
    //     return filter;
    // }
}
