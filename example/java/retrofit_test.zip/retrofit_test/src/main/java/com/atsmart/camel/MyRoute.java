package com.atsmart.camel;

//public class MyRoute extends RouteBuilder {
//    public void configure() throws Exception {
//        Endpoint newOrder = endpoint("activemq:queue:newOrder");
//        Predicate isWidget = xpath("/order/product = 'widget");
//        Endpoint widget = endpoint("activemq:queue:widget");
//        Endpoint gadget = endpoint("activemq:queue:gadget");
//        from(newOrder)
//                .choice()
//                .when(isWidget).to(widget)
//                .otherwise().to(gadget)
//                .end();
//    }
//}

import org.apache.camel.builder.RouteBuilder;
public class MyRoute extends RouteBuilder {
    public void configure() throws Exception {
        from("activemq:queue:newOrder")
                .choice()
                .when(xpath("/order/product = 'widget"))
                .to("activemq:queue:widget")
                .otherwise()
                .to("activemq:queue:gadget")
                .end();
    }
}
}