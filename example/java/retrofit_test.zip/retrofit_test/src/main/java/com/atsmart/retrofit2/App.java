package com.atsmart.retrofit2;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import java.io.IOException;

/**
 * Created by hcw on 2016/5/21.
 */
public class App {
    public static void main(String[] args) {

        Gson gson = new GsonBuilder()
                .setDateFormat("yyyy-MM-dd'T'HH:mm:ssZ")
                .create();
        String BASE_URL = "http://www.baidu.com";
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        ApiInterface apiService =
                retrofit.create(ApiInterface.class);

        Call<String> ret = apiService.getUser("");
        try {
            System.out.println(ret.execute().body());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
