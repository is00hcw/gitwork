package com.atsmart.camel.ext;

import java.io.File;
  
import org.apache.camel.Consumer;  
import org.apache.camel.Exchange;  
import org.apache.camel.Processor;  
import org.apache.camel.Producer;  
import org.apache.camel.component.file.FileComponent;  
import org.apache.camel.impl.DefaultEndpoint;  
import org.apache.camel.impl.DefaultExchange;  
  
public class MyFileEndpoint extends DefaultEndpoint {  
  
    public MyFileEndpoint(MyFileComponent component, String uri) {  
        super(uri, component);  
    }  
  
    @Override  
    public Producer createProducer() throws Exception {  
        return new MyFileProducer(this);  
    }  
  
    @Override  
    public Consumer createConsumer(Processor processor) throws Exception {  
        return new MyFileConsumer(this, processor);  
    }  
  
    @Override  
    public boolean isSingleton() {  
        return false;  
    }  
      
    public Exchange createExchange(File file) {  
        Exchange exchange = new DefaultExchange(getCamelContext());  
        exchange.setProperty(FileComponent.FILE_EXCHANGE_FILE, file);  
        exchange.getIn().setBody(file, File.class);  
        return exchange;  
    }  
}  