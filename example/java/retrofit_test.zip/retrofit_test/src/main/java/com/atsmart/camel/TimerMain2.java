package com.atsmart.camel;

import org.slf4j.*;
import org.apache.camel.builder.*;
import org.apache.camel.main.Main;


//  http://www.oschina.net/translate/getting-started-with-apache-camel-using
public class TimerMain2 extends Main {
    static Logger LOG = LoggerFactory.getLogger(TimerMain2.class);

    public static void main(String[] args) throws Exception {
        TimerMain2 main = new TimerMain2();
        main.enableHangupSupport();
        main.addRouteBuilder(createRouteBuilder());
        main.run(args);
    }

    static RouteBuilder createRouteBuilder() {
        return new TimerRouteBuilder();
    }
}