package com.atsmart.retrofit2;

import retrofit2.Call;
import retrofit2.http.*;

public interface ApiInterface {
    // Request method and URL specified in the annotation
    // Callback for the parsed response is the last parameter

    @Headers({"Cache-Control: max-age=640000", "User-Agent: My-App-Name"})
    @GET("/")
    Call<String> getUser(@Query("username") String username);


}