package com.atsmart.camel.ext;

import org.apache.camel.Endpoint;
import org.apache.camel.impl.DefaultComponent;

import java.util.Map;
  
public class MyFileComponent extends DefaultComponent {  
  
    @Override  
    protected Endpoint createEndpoint(String uri, String remaining, Map<String, Object> parameters) throws Exception {  
        return new MyFileEndpoint(this, uri);  
    }  
  
}  