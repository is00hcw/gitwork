package com.atsmart.camel.ext;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

import java.io.*;

public class MyComponentTest {

    /**
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        CamelContext camelContext = new DefaultCamelContext();
        //为了简单起见，用该方法替代了在类路径META-INF/services/org/apache/camel/component/下放置properties文件方式  
        camelContext.addComponent("myfile", new MyFileComponent());

        camelContext.addRoutes(new RouteBuilder() {

            @Override
            public void configure() throws Exception {
                this.from("myfile:d:/temp/camel/in").process(new Processor() {
                    @Override
                    public void process(Exchange exchange) throws Exception {
                        File file = exchange.getIn().getBody(File.class);
                        PrintStream ps = new PrintStream(System.out);
                        BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
                        String line = null;
                        while ((line = br.readLine()) != null) {
                            ps.println(line);
                        }

                        ps.close();
                        br.close();
                    }
                }).to("myfile:d:/temp/camel/ut");

            }
        });

        camelContext.start();

        Object object = new Object();
        synchronized (object) {
            object.wait();
        }
    }

}  
