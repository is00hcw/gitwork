package com.atsmart.retrofit2;

import com.google.gson.annotations.SerializedName;

public class User {

  @SerializedName("id")
  int mId;

  @SerializedName("name")
  String mName;

  public User(int id, String name ) {
    this.mId = id;
    this.mName = name;
  }
}