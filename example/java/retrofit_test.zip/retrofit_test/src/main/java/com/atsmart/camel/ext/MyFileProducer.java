package com.atsmart.camel.ext;

import org.apache.camel.Endpoint;
import org.apache.camel.Exchange;
import org.apache.camel.impl.DefaultProducer;
//import org.apache.commons.io.FileUtils;

import java.io.File;
  
public class MyFileProducer extends DefaultProducer {  
    private File outputDir;  
  
    public MyFileProducer(Endpoint endpoint) {  
        super(endpoint);
        System.out.println("MyFileProducer -- " + endpoint.getEndpointUri());
        this.outputDir = new File(endpoint.getEndpointUri().substring(endpoint.getEndpointUri().indexOf(":")+1));  
    }  
  
    @Override  
    public void process(Exchange exchange) throws Exception {  
        File file = exchange.getIn().getBody(File.class);  
        if(file!=null) {
            file.delete();
           // FileUtils.moveFileToDirectory(file, outputDir, true);
        }  
    }  
  
}  
