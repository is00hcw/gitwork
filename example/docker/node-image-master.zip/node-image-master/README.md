# Node.js Docker Image with Taobao NPM Mirror
================
This image is built from official Node.js Docker image with ```cnpm``` from [Taobao NPM mirror](http://npm.taobao.org/).

Contributors
-------------------
* Li Yi (denverdino@gmail.com)

