# python-mysql-sample
![python-mysql-sample](https://oversea-ci.daocloud.io/api/badge/build/daocloud/pYthon) ![python-mysql-sample](https://oversea-ci.daocloud.io/api/badge/test/daocloud/python) ![python-mysql-sample](https://oversea-ci.daocloud.io/api/badge/coverage/daocloud/python?branch=master&criteria=line-rate)

This sample demonstrates how to setup DaoCloud CI for a Python+MySQL project.
