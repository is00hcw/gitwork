# Nginx Docker Image for Aliyun Container Service 
================
This image is built from official nginx Docker image with [Aliyun mirror](http://mirrors.aliyun.com/).

And use ACS service discovery API to config nginx.

Contributors
-------------------
* Chang Hai Yan (danielyanch@hotmail.com)
