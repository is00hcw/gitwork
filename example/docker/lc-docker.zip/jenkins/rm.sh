#!/usr/bin/env bash

docker stop jenkins && docker rm jenkins