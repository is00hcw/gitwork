#!/usr/bin/env bash

mkdir -p /opt/mongodb/ && chmod -R 777 /opt/mongodb

docker run -d \
    --name mongodb \
    --restart=always \
    -p 27017:27017 \
    -v /opt/mongodb:/data/db \
    registry.aliyuncs.com/zuowenbo/mongodb