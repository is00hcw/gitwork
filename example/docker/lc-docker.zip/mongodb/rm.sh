#!/usr/bin/env bash
docker stop mongodb && docker rm mongodb