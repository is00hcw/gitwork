#!/usr/bin/env bash

docker stop redis && docker rm redis