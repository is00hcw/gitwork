#!/usr/bin/env bash

tar zcvf web.tar.gz public_html
 
scp web.tar.gz root@docker1:~/
scp web.tar.gz root@docker2:~/

tar zxvf web.tar.gz