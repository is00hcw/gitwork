#!/usr/bin/env bash

mkdir -p /opt/jar-runner

chmod -R 777 /opt/jar-runner

docker run -d \
    --name jar-runner \
    --restart=always \
    -v /opt/jar-runner:/usr/local/jar-runner \
    registry.aliyuncs.com/zuowenbo/jar-runner