#!/usr/bin/env bash

docker stop jar-runner && docker rm jar-runner