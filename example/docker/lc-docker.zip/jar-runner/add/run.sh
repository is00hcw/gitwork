#!/usr/bin/env bash
java -jar /usr/local/jar-runner/start.jar