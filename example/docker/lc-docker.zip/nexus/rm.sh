#!/usr/bin/env bash

docker stop nexus && docker rm nexus