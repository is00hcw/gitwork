#!/usr/bin/env bash

docker run -d \
    --name zookeeper \
    --restart=always \
    -p 3888:3888 \
    -p 2888:2888 \
    -p 2181:2181 \
    registry.aliyuncs.com/zuowenbo/zookeeper