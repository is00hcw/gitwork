#!/usr/bin/env bash

docker stop gitlab && docker rm gitlab