# docker-jenkins


Sample Jenkin Docker image with some enhancements to official one

* Sets proper permssion for local host volume
* Installs common plugins


