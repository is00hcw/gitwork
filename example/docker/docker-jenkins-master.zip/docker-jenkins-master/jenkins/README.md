# docker-jenkins


Sample Jenkin Docker Image which sets proper permssion for local host volume

