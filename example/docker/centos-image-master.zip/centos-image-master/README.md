# CentOS Docker Image with Aliyun Mirror
================
This Docker image is built from the official CentOS image with [Aliyun mirror](http://mirrors.aliyun.com/).

Contributors
-------------------
* Li Yi (denverdino@gmail.com)

