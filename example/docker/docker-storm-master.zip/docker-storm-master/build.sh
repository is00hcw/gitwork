#!/bin/bash

docker build -t registry.aliyuncs.com/denverdino/baqend-storm:1.0.0 storm
docker build -t registry.aliyuncs.com/denverdino/storm-starter:1.0.0 storm-starter
