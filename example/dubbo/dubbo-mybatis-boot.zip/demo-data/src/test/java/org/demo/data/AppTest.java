package org.demo.data;

import org.apache.ibatis.session.SqlSession;
import org.demo.data.dao.UserMapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:mybatis-context.xml")
 
public class AppTest {
  
  @Autowired
  private UserMapper userMapper;

  @Autowired
  private SqlSession sqlSession;

  @Test
  public void test() {
    System.out.println(sqlSession);
    System.out.println(userMapper);
  }

  
}
