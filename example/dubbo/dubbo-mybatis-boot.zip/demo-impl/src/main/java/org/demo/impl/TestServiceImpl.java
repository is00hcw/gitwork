package org.demo.impl;

import org.demo.api.TestService;
import org.demo.data.dao.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;

public class TestServiceImpl implements TestService {
	@Autowired
	UserMapper userMapper;
    /**
     * 服务提供方实现接口：(对服务消费方隐藏实现)
     */
    public String sayHello(String name) {
    	System.out.println(userMapper);
        System.out.println("调用provider服务***");
        return "hello "+name;
    }
}