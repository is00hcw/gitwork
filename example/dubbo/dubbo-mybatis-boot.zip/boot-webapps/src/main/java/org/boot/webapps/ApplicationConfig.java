package org.boot.webapps;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.embedded.ConfigurableEmbeddedServletContainer;
import org.springframework.boot.context.embedded.EmbeddedServletContainerCustomizer;
import org.springframework.boot.context.embedded.ErrorPage;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

// @ImportResource({"classpath*:applicationContext.xml"})
// @MapperScan("com.example.dao")
// @Configuration
// @ComponentScan
// @EnableAutoConfiguration
// ----------------

@ServletComponentScan
@EnableAsync
@SpringBootApplication
public class ApplicationConfig {

  @Bean
  public ThreadPoolTaskExecutor createThreadPoolTaskExecutor() {
    ThreadPoolTaskExecutor threadPoolTaskExecutor = new ThreadPoolTaskExecutor();
    threadPoolTaskExecutor.setCorePoolSize(10);
    threadPoolTaskExecutor.setMaxPoolSize(20);
    return threadPoolTaskExecutor;
  }

//  @Bean
//  public EmbeddedServletContainerCustomizer containerCustomizer() {
//    return new EmbeddedServletContainerCustomizer() {
//      @Override
//      public void customize(ConfigurableEmbeddedServletContainer container) {
//        container.addErrorPages(new ErrorPage(HttpStatus.INTERNAL_SERVER_ERROR, "/500"));
//        container.addErrorPages(new ErrorPage(HttpStatus.NOT_FOUND, "/404"));
//      }
//    };
//  }
}
