package org.boot.webapps;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

@ImportResource({"classpath:spring/dubbo-consumer.xml"})
@Configuration
public class DubboConfig {

}
