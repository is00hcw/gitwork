package org.demo.api;
public interface TestService {
    public String sayHello(String name);
}