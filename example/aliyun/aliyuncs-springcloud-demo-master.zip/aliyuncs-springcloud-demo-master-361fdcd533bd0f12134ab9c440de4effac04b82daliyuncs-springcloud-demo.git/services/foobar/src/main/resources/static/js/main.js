// $(document).ready(function() {
//     $.ajax({
//         url: "/f/message"
//     }).then(function(data) {
//         $('.service1-name').append(data.foo.name);
//         $('.service1-message').append(data.foo.message);
//         $('.service2').append(data.bar.message);
//     });
// });
