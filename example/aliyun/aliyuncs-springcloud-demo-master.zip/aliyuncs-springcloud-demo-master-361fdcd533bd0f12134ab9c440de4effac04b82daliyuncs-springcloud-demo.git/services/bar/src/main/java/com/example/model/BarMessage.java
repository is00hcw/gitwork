package com.example.model;

/**
 * Created by libin on 3/16/16.
 */
public class BarMessage {
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    private String message;
}
