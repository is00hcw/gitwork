# Vert.x Websocket Chat

Creating a websocket chat using a http server verticle and a websocket verticle.

Please feel free to have a look at my blog at [www.hascode.com] for more information.

----

**2013 Micha Kops / hasCode.com**

   [www.hascode.com]:http://www.hascode.com/
