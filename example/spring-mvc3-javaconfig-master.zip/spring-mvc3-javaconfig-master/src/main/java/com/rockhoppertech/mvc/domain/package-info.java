/**
 * The domain entity classes are in this package.
 */
package com.rockhoppertech.mvc.domain;

