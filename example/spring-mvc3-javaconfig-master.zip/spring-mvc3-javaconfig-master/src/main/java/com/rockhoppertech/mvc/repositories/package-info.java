/**
 * The Spring Data repository classes are in this package.
 */
package com.rockhoppertech.mvc.repositories;