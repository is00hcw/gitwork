/**
 * The Java configuration classes are in this package. This is how we avoid XML configuration.
 */
package com.rockhoppertech.mvc.web.config;