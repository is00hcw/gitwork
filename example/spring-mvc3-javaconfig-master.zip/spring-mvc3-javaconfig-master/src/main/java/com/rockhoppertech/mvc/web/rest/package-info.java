/**
 * The Spring MVC REST classes are in this package.
 */
package com.rockhoppertech.mvc.web.rest;