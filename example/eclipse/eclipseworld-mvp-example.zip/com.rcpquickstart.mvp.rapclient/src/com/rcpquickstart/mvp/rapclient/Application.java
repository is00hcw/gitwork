package com.rcpquickstart.mvp.rapclient;

import org.eclipse.rwt.lifecycle.IEntryPoint;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.PlatformUI;

/**
 * This class controls all aspects of the application's execution
 */
public class Application implements IEntryPoint {

	public Display createUI() {
		Display display = PlatformUI.createDisplay();
		PlatformUI.createAndRunWorkbench( display, new ApplicationWorkbenchAdvisor() );
		return display;
	}
}
