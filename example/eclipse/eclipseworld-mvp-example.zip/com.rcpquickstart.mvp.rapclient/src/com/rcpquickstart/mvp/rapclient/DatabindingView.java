package com.rcpquickstart.mvp.rapclient;

import org.eclipse.core.databinding.observable.value.IObservableValue;
import org.eclipse.jface.databinding.swt.SWTObservables;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.part.ViewPart;

import com.rcpquickstart.mvp.presentation.ExampleDatabindingPresenter;
import com.rcpquickstart.mvp.presentation.IDatabindingView;

public class DatabindingView extends ViewPart implements IDatabindingView {
	public static final String ID = "com.rcpquickstart.mvp.rapclient.view"; //$NON-NLS-1$
	private Text nameText;
	private Button okButton;
	private IObservableValue nameObservable;
	private IObservableValue okButtonEnabledObservable;
	private ExampleDatabindingPresenter presenter;

	/**
	 * This is a callback that will allow us to create the viewer and initialize
	 * it.
	 */
	public void createPartControl(Composite parent) {
		Composite form = new Composite(parent, SWT.NONE);
		GridLayout layout = new GridLayout();
		layout.numColumns = 3;
		form.setLayout(layout);

		Label nameLabel = new Label(form, SWT.NONE);
		nameLabel.setText("Name:"); //$NON-NLS-1$

		this.nameText = new Text(form, SWT.BORDER);
		this.nameObservable = SWTObservables.observeText(this.nameText,
				SWT.Modify);

		this.okButton = new Button(form, SWT.NONE);
		this.okButton.setText("&Ok"); //$NON-NLS-1$
		this.okButtonEnabledObservable = SWTObservables
				.observeEnabled(this.okButton);
		this.okButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				presenter.okPressed();
			}
		});

		this.presenter = new ExampleDatabindingPresenter(this);
	}

	@Override
	public void setFocus() {
		this.nameText.setFocus();
	}

	public IObservableValue getNameObservable() {
		return this.nameObservable;
	}

	public IObservableValue getOkButtonEnabledObservable() {
		return this.okButtonEnabledObservable;
	}
}