package com.rcpquickstart.mvp.presentation;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import org.eclipse.core.databinding.beans.BeansObservables;
import org.eclipse.core.databinding.observable.value.IObservableValue;

public class MockDatabindingView implements IDatabindingView {

	private PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(
			this);
	private String name;
	private boolean okButtonEnabled;
	private IObservableValue nameObservable;
	private IObservableValue okButtonEnabledObservable;

	public MockDatabindingView() {
		this.nameObservable = BeansObservables.observeValue(this, "name"); //$NON-NLS-1$
		this.okButtonEnabledObservable = BeansObservables.observeValue(this,
				"okButtonEnabled"); //$NON-NLS-1$
	}

	/* property accessors */

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.propertyChangeSupport.firePropertyChange("name", this.name, //$NON-NLS-1$
				this.name = name);
	}

	public void setOkButtonEnabled(boolean enabled) {
		this.propertyChangeSupport.firePropertyChange(
				"okButtonEnabled", this.okButtonEnabled, //$NON-NLS-1$
				this.okButtonEnabled = enabled);
	}

	public boolean getOkButtonEnabled() {
		return this.okButtonEnabled;
	}

	/* observable accessors */

	public IObservableValue getNameObservable() {
		return this.nameObservable;
	}

	public IObservableValue getOkButtonEnabledObservable() {
		return this.okButtonEnabledObservable;
	}

	/* property change management */

	public void addPropertyChangeListener(String propertyName,
			PropertyChangeListener listener) {
		this.propertyChangeSupport.addPropertyChangeListener(propertyName,
				listener);
	}

	public void removePropertyChangeListener(String propertyName,
			PropertyChangeListener listener) {
		this.propertyChangeSupport.removePropertyChangeListener(propertyName,
				listener);
	}
}
