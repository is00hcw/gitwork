package com.rcpquickstart.mvp.presentation;

public class ExamplePresenter {

	private String name;

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean getOkButtonEnabled() {
		return this.name != null && !this.name.trim().equals(""); //$NON-NLS-1$
	}

	public void okPressed() {
		// save model
	}
}
