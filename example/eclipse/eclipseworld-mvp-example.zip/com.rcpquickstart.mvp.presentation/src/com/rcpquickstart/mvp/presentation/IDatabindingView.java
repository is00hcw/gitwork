package com.rcpquickstart.mvp.presentation;

import org.eclipse.core.databinding.observable.value.IObservableValue;

public interface IDatabindingView {

	IObservableValue getNameObservable();
	
	IObservableValue getOkButtonEnabledObservable();
}
