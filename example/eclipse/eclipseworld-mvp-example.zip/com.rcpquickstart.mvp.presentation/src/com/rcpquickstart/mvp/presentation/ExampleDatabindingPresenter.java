package com.rcpquickstart.mvp.presentation;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import org.eclipse.core.databinding.DataBindingContext;
import org.eclipse.core.databinding.beans.BeansObservables;

public class ExampleDatabindingPresenter {

	private PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(
			this);
	private String name;
	private boolean okButtonEnabled;
	private IDatabindingView view;

	public ExampleDatabindingPresenter(IDatabindingView view) {
		this.view = view;
		this.bind();
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.propertyChangeSupport.firePropertyChange("name", this.name, //$NON-NLS-1$
				this.name = name);
		this.setOkButtonEnabled(this.name != null
				&& !this.name.trim().equals("")); //$NON-NLS-1$
	}

	public void setOkButtonEnabled(boolean enabled) {
		this.propertyChangeSupport.firePropertyChange(
				"okButtonEnabled", this.okButtonEnabled, //$NON-NLS-1$
				this.okButtonEnabled = enabled);
	}

	public boolean getOkButtonEnabled() {
		return this.okButtonEnabled;
	}

	public void okPressed() {
		System.out.println("OK Pressed. Save model."); //$NON-NLS-1$
	}

	private void bind() {
		DataBindingContext dbc = new DataBindingContext();
		dbc.bindValue(this.view.getNameObservable(), BeansObservables.observeValue(this,
				"name"), null, null); //$NON-NLS-1$
		dbc.bindValue(this.view.getOkButtonEnabledObservable(), BeansObservables
				.observeValue(this, "okButtonEnabled"), null, null); //$NON-NLS-1$
	}

	/* property change management */
	
	public void addPropertyChangeListener(String propertyName,
			PropertyChangeListener listener) {
		this.propertyChangeSupport.addPropertyChangeListener(propertyName,
				listener);
	}

	public void removePropertyChangeListener(String propertyName,
			PropertyChangeListener listener) {
		this.propertyChangeSupport.removePropertyChangeListener(propertyName,
				listener);
	}
}
