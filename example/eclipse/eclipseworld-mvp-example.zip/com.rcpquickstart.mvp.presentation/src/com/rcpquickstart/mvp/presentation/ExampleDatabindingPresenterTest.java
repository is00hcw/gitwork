package com.rcpquickstart.mvp.presentation;

import junit.framework.TestCase;

public class ExampleDatabindingPresenterTest extends TestCase {

	private TestRealm realm;
	
	@Override
	protected void setUp() throws Exception {
		super.setUp();
		this.realm = new TestRealm();
	}
	
	@Override
	protected void tearDown() throws Exception {
		this.realm.dispose();
		super.tearDown();
	}
	
	public void testSetName() {
		MockDatabindingView view = new MockDatabindingView();
		new ExampleDatabindingPresenter(view);
		
		/* verify that ok button is enabled after name is set */
		assertFalse(view.getOkButtonEnabled());
		view.setName("Frank"); //$NON-NLS-1$
		assertTrue(view.getOkButtonEnabled());
	}
}
