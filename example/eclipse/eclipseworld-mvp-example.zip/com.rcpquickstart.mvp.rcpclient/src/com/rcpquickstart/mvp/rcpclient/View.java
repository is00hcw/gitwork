package com.rcpquickstart.mvp.rcpclient;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Text;
import org.eclipse.ui.part.ViewPart;

import com.rcpquickstart.mvp.presentation.ExamplePresenter;

public class View extends ViewPart {
	public static final String ID = "com.rcpquickstart.mvp.rcpclient.view"; //$NON-NLS-1$
	private Text nameText;
	private ExamplePresenter presenter;
	private Button okButton;

	/**
	 * This is a callback that will allow us to create the viewer and initialize
	 * it.
	 */
	public void createPartControl(Composite parent) {
		this.presenter = new ExamplePresenter();
		
		Composite form = new Composite(parent, SWT.NONE);
		GridLayout layout = new GridLayout();
		layout.numColumns = 3;
		form.setLayout(layout);

		Label nameLabel = new Label(form, SWT.NONE);
		nameLabel.setText("Name:"); //$NON-NLS-1$

		this.nameText = new Text(form, SWT.BORDER);
		this.nameText.addModifyListener(new ModifyListener() {
			public void modifyText(ModifyEvent e) {
				presenter.setName(nameText.getText());
				okButton.setEnabled(presenter.getOkButtonEnabled());
			}
		});
		
		this.okButton = new Button(form, SWT.NONE);
		this.okButton.setText("&Ok"); //$NON-NLS-1$
		this.okButton.setEnabled(this.presenter.getOkButtonEnabled());
		this.okButton.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				super.widgetSelected(e);
				presenter.okPressed();
			}
		});
	}

	@Override
	public void setFocus() {
		this.nameText.setFocus();
	}
}