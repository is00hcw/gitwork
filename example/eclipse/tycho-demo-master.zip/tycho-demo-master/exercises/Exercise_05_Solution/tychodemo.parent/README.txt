Exercise 5: Build a product distribution
========================================

This folder contains the solution of exercise 5.
