package com.example.disconf;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.example.disconf.config.SimpleConfig;
import com.example.disconf.task.DisconfDemoTask;

//mvn exec:java -Dexec.mainClass=com.example.disconf.DisconfDemoMain
public class DisconfDemoMain {

    protected static final Logger LOGGER = LoggerFactory.getLogger(DisconfDemoMain.class);

    private static String[] fn = null;

    // 初始化spring文档
    private static void contextInitialized() {
        fn = new String[] {"disconf.xml"};
    }

    /**
     * @param args
     *
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {

        contextInitialized();
        ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext(fn);
        ctx.start();
        
        SimpleConfig simpleConfig = ctx.getBean( SimpleConfig.class);
        new Thread(new DisconfDemoTask(simpleConfig)).start();

        System.in.read();
    }
}
