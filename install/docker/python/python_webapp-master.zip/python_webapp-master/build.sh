#!/bin/bash -vxe

sudo docker build --rm -t mrmrcoleman/python_webapp .
