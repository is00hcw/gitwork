## Docker in Action - fitter, happier, more productive

Presented at [PyTennessee](https://www.pytennessee.org/) on February 8th, 2015.

1. View the slides >> http://realpython.github.io/fitter-happier-docker/
1. Check out the blog post >> https://realpython.com/blog/python/docker-in-action-fitter-happier-more-productive
